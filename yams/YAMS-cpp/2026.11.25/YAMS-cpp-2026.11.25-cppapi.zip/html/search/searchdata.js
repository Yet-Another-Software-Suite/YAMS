var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxyz~",
  1: "abdefgilmnprstuy",
  2: "y",
  3: "abdefglmnprsty",
  4: "abcdefghilmnoprstuvwyz~",
  5: "abcdeklmoprsv",
  6: "bcdfhlmrstwy",
  7: "bcdghlmpst",
  8: "abcdefghiklmnoprstvxy",
  9: "al",
  10: "abcdefgiklmnopqrstuvwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Pages"
};

