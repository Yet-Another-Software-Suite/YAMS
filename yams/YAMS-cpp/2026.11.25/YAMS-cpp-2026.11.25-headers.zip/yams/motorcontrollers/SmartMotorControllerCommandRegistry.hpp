// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once

#include <functional>
#include <string>
#include <unordered_map>
#include <vector>
#include <wpi/commands2/CommandPtr.hpp>
#include <wpi/commands2/SubsystemBase.hpp>

namespace yams::motorcontrollers {

/**
 * Registry that aggregates per-subsystem commands from multiple SmartMotorControllers.
 *
 * When multiple SmartMotorControllers belong to the same subsystem (e.g. a dual-motor arm),
 * each one registers its live-tuning callback here.  The registry creates a single combined
 * command per subsystem that runs all registered callbacks on every periodic loop.
 *
 * The published SmartDashboard path is: Mechanisms/Commands/%SubsystemName%/%CommandName%
 */
class SmartMotorControllerCommandRegistry {
 public:
  /**
   * Register a callback for a command on a subsystem.
   *
   * If no command with this name exists for the subsystem yet, a new one is created and
   * published to SmartDashboard.  If one already exists, the callback is appended to it.
   *
   * @param cmdName   Display name for the command (e.g. "Live Tuning").
   * @param subsystem Subsystem that owns the command (used for requirement and naming).
   * @param callback  Runnable invoked each loop while the command is running.
   */
  static void AddCommand(const std::string& cmdName, wpi::cmd::SubsystemBase* subsystem,
                         std::function<void()> callback);

  /**
   * Register a callback for a command on a subsystem, with a callback run when the command ends.
   *
   * @param cmdName   Display name for the command (e.g. "Live Tuning").
   * @param subsystem Subsystem that owns the command (used for requirement and naming).
   * @param callback  Runnable invoked each loop while the command is running.
   * @param onEnd     Runnable invoked when the command ends.
   */
  static void AddCommand(const std::string& cmdName, wpi::cmd::SubsystemBase* subsystem,
                         std::function<void()> callback, std::function<void()> onEnd);

  /**
   * Get a registered command, such as the "Live Tuning" command, to schedule it from code.
   *
   * @param cmdName   Command name.
   * @param subsystem Subsystem the command was registered for.
   * @return The command, or nullptr if none is registered under cmdName.
   */
  static wpi::cmd::Command* GetCommand(const std::string& cmdName,
                                       wpi::cmd::SubsystemBase* subsystem);

  /**
   * Check whether a command with the given name already exists for a subsystem.
   *
   * @param cmdName   Command name.
   * @param subsystem Subsystem.
   * @return true if the command is already registered.
   */
  static bool CommandExists(const std::string& cmdName, wpi::cmd::SubsystemBase* subsystem);

  /**
   * Remove all commands registered for a specific subsystem instance, and unpublish them from
   * the Tuning tunables.
   *
   * Call this when a subsystem is being torn down (e.g. between tests) so
   * that a new instance with the same name can register without triggering
   * the conflict check.
   *
   * @param subsystem Subsystem whose commands should be removed.
   */
  static void RemoveCommands(wpi::cmd::SubsystemBase* subsystem);

  /**
   * Destroy all registered commands and callbacks, and unpublish them from the Tuning tunables.
   *
   * Must be called before program exit while WPILib's SendableRegistry is
   * still alive, otherwise the CommandPtr destructors will attempt to lock an
   * already-destroyed mutex and crash (SIGSEGV/exit 139).
   */
  static void Clear();

 private:
  static std::unordered_map<std::string, wpi::cmd::CommandPtr> s_commands;
  static std::unordered_map<std::string, std::vector<std::function<void()>>> s_callbacks;
  static std::unordered_map<std::string, std::vector<std::function<void()>>> s_endCallbacks;
  static std::unordered_map<std::string, wpi::cmd::SubsystemBase*> s_owners;

  static std::string MakeKey(const std::string& cmdName, wpi::cmd::SubsystemBase* subsystem);
  static void PublishToNT(const std::string& cmdName, wpi::cmd::SubsystemBase* subsystem);
};

}  // namespace yams::motorcontrollers
