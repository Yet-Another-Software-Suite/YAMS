// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once

#include <functional>
#include <optional>
#include <string>
#include <vector>
#include <wpi/commands2/SubsystemBase.hpp>
#include <wpi/math/controller/AntiTipping.hpp>
#include <wpi/math/controller/PIDController.hpp>
#include <wpi/math/geometry/Pose2d.hpp>
#include <wpi/math/geometry/Rotation2d.hpp>
#include <wpi/math/geometry/Rotation3d.hpp>
#include <wpi/math/geometry/Translation2d.hpp>
#include <wpi/math/kinematics/ChassisVelocities.hpp>
#include <wpi/units/angle.hpp>
#include <wpi/units/angular_velocity.hpp>
#include <wpi/units/length.hpp>
#include <wpi/units/time.hpp>
#include <wpi/units/velocity.hpp>
#include <wpi/util/Alert.hpp>

#include "yams/math/DerivativeTimeFilter.hpp"
#include "yams/mechanisms/config/GyroAxis.hpp"
#include "yams/mechanisms/swerve/SwerveModule.hpp"
#include "yams/motorcontrollers/SmartMotorControllerConfig.hpp"
#include "yams/telemetry/SwerveDriveTelemetryConfig.hpp"

namespace yams::mechanisms::swerve {

/**
 * Configuration for a SwerveDrive.
 *
 * Uses a fluent builder pattern; all With* methods return *this for chaining.
 */
class SwerveDriveConfig {
 public:
  using TelemetryVerbosity = motorcontrollers::SmartMotorControllerConfig::TelemetryVerbosity;

  SwerveDriveConfig() = default;

  // ---- Builder methods -------------------------------------------------------

  /**
   * Associate a command subsystem with this drive (used for command requirements).
   *
   * @param subsystem Pointer to the subsystem (must outlive this config).
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithSubsystem(wpi::cmd::SubsystemBase* subsystem);

  /**
   * Set the swerve modules (must match the NumModules template argument of SwerveDrive).
   *
   * @param modules Vector of module pointers (must outlive this config).
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithModules(std::vector<SwerveModule*> modules);

  /**
   * Supply the gyro's heading in degrees, for a gyro mounted flat.
   *
   * The attitude is taken to be this yaw with no roll or pitch, so anti-tipping does nothing and
   * WithGyroHeadingAxis has nothing to rotate. Use the Rotation3d overload for either.
   *
   * @param gyroSupplier Callable returning the current gyro angle.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithGyro(std::function<wpi::units::degree_t()> gyroSupplier);

  /**
   * Same as WithRotation: supply the gyro's full 3D attitude.
   *
   * @param gyroSupplier Callable returning the gyro's attitude.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithGyro(std::function<wpi::math::Rotation3d()> gyroSupplier);

  /**
   * Supply the robot's rotation from the gyro, as its full 3D attitude. See WithGyroHeadingAxis for
   * a gyro that is not mounted flat.
   *
   * @param rotationSupplier Callable returning the gyro's attitude.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithRotation(std::function<wpi::math::Rotation3d()> rotationSupplier);

  /**
   * Set which gyro axis points up through the robot, for a gyro mounted on its side. The attitude
   * from WithGyro is rotated into the robot's frame, so GetGyroRotation3d returns the robot's
   * heading as its yaw and the robot's tilt as its roll and pitch.
   *
   * @param axis The gyro axis that points up. GyroAxis::YAW, the default, is a gyro mounted flat.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithGyroHeadingAxis(config::GyroAxis axis);

  /**
   * Push back against tipping: when the robot leans by more than the threshold, a chassis velocity
   * is added in the direction it is leaning, so the drive base moves back under the robot. It needs
   * the gyro's full attitude, from the Rotation3d overload of WithGyro.
   *
   * @param kP Correction speed per radian of lean. Must be positive.
   * @param tippingThreshold Lean beyond which the correction applies. Between 0 and 90 degrees.
   * @param maxCorrectionSpeed The largest correction. Must be positive.
   * @return *this for chaining.
   * @throws std::invalid_argument if a value is out of range.
   */
  SwerveDriveConfig& WithAntiTipping(wpi::units::meters_per_second_t kP,
                                     wpi::units::degree_t tippingThreshold,
                                     wpi::units::meters_per_second_t maxCorrectionSpeed);

  /**
   * Push back against tipping with your own controller, or std::nullopt to turn it off.
   *
   * @param antiTipping The anti-tipping controller.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithAntiTipping(std::optional<wpi::math::AntiTipping> antiTipping);

  /**
   * Turn swerve module state optimization on or off for every module. It is applied to the modules
   * given so far, and to all of them when the SwerveDrive is created.
   *
   * @param enabled true to optimize module states.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithModuleStateOptimization(bool enabled);

  /**
   * Supply the gyro angular velocity in degrees per second.
   *
   * Required for angular-velocity skew correction.
   *
   * @param angularVelocitySupplier Callable returning the current gyro angular velocity.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithGyroVelocity(
      std::function<wpi::units::degrees_per_second_t()> angularVelocitySupplier);

  /**
   * Invert the gyro direction.
   *
   * @param inverted true to negate the raw gyro angle.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithGyroInverted(bool inverted);

  /**
   * Set the starting field pose of the robot.
   *
   * @param pose Starting Pose2d (field-relative, blue-origin).
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithStartingPose(wpi::math::Pose2d pose);

  /**
   * Set the maximum chassis linear and angular speeds for wheel speed desaturation.
   *
   * @param speed           Maximum chassis linear speed.
   * @param angularVelocity Maximum chassis angular speed.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithMaximumChassisSpeed(wpi::units::meters_per_second_t speed,
                                             wpi::units::degrees_per_second_t angularVelocity);

  /**
   * Set the maximum module linear speed for wheel speed desaturation.
   *
   * @param speed Maximum module speed.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithMaximumModuleSpeed(wpi::units::meters_per_second_t speed);

  /**
   * Override the chassis centre of rotation (default is the robot centre).
   *
   * @param center Translation2d in metres (X forward, Y left).
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithCenterOfRotation(wpi::math::Translation2d center);

  /**
   * Override the chassis centre of rotation via forward/left distances.
   *
   * @param forward Distance forward from the robot centre.
   * @param left    Distance left from the robot centre.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithCenterOfRotation(wpi::units::meter_t forward, wpi::units::meter_t left);

  /**
   * Set the discretization timestep used to compensate for ChassisSpeeds skew.
   *
   * @param dt Discretization period (typically one robot loop period).
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithDiscretizationTime(wpi::units::second_t dt);

  /**
   * Set the discretization timestep used during simulation.
   *
   * Falls back to WithDiscretizationTime if not set.
   *
   * @param dt Discretization period for simulation.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithSimDiscretizationTime(wpi::units::second_t dt);

  /**
   * Set the angular velocity scale factor for skew correction on the real robot.
   *
   * @param scaleFactor Scale applied to the gyro angular velocity [0, 1].
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithGyroAngularVelocityScaleFactor(double scaleFactor);

  /**
   * Set the angular velocity scale factor for skew correction in simulation.
   *
   * Falls back to WithGyroAngularVelocityScaleFactor if not set.
   *
   * @param scaleFactor Scale applied to the gyro angular velocity [0, 1].
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithSimGyroAngularVelocityScaleFactor(double scaleFactor);

  /**
   * Set the translation PID controller for DriveToPose (input units: metres).
   *
   * @param controller PIDController for X/Y translation.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithTranslationController(wpi::math::PIDController controller);

  /**
   * Set the rotation PID controller for DriveToPose (input units: radians).
   *
   * Continuous input over [-π, π] is enabled automatically.
   *
   * @param controller PIDController for heading.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithRotationController(wpi::math::PIDController controller);

  /**
   * Set the simulated translation PID controller for DriveToPose (input units: metres).
   *
   * Falls back to WithTranslationController if not set.
   *
   * @param controller PIDController for X/Y translation in simulation.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithSimTranslationController(wpi::math::PIDController controller);

  /**
   * Set the simulated rotation PID controller for DriveToPose (input units: radians).
   *
   * Falls back to WithRotationController if not set.  Continuous input is enabled automatically.
   *
   * @param controller PIDController for heading in simulation.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithSimRotationController(wpi::math::PIDController controller);

  /**
   * Set the telemetry name and verbosity for the drive.
   *
   * @param name Telemetry name (defaults to "swerve").
   * @param verbosity Amount of data to publish.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithTelemetry(const std::string& name, TelemetryVerbosity verbosity);

  /**
   * Configure telemetry for the drive with an explicit SwerveDriveTelemetryConfig, taking
   * precedence over WithTelemetry(name, TelemetryVerbosity).
   *
   * @param name Telemetry name (defaults to "swerve").
   * @param telemetryConfig Config that specifies what to log.
   * @return *this for chaining.
   */
  SwerveDriveConfig& WithTelemetry(const std::string& name,
                                   telemetry::SwerveDriveTelemetryConfig telemetryConfig);

  // ---- Getters ---------------------------------------------------------------

  /** Get the vector of module pointers. */
  const std::vector<SwerveModule*>& GetModules() const;

  /** Get the subsystem pointer. */
  wpi::cmd::SubsystemBase* GetSubsystem() const;

  /** Get the starting pose. */
  wpi::math::Pose2d GetInitialPose() const;

  /** @return Optional maximum chassis linear speed for wheel-speed desaturation. */
  std::optional<wpi::units::meters_per_second_t> GetMaximumChassisLinearVelocity() const;

  /** @return Optional maximum chassis angular speed for wheel-speed desaturation. */
  std::optional<wpi::units::degrees_per_second_t> GetMaximumChassisAngularVelocity() const;
  /** @return Optional maximum module linear speed for wheel-speed desaturation. */
  std::optional<wpi::units::meters_per_second_t> GetMaximumModuleLinearVelocity() const;
  /** @return Optional override centre of rotation (empty = robot centre). */
  std::optional<wpi::math::Translation2d> GetCenterOfRotation() const;
  /** @return Optional telemetry verbosity level. */
  std::optional<TelemetryVerbosity> GetTelemetryVerbosity() const;
  /** @return The telemetry name for the drive (defaults to "swerve"). */
  const std::string& GetTelemetryName() const;
  /**
   * Get the user-specified SwerveDriveTelemetryConfig, if configured via
   * WithTelemetry(name, SwerveDriveTelemetryConfig). Moves the config out of this
   * SwerveDriveConfig; intended to be called exactly once, when the owning SwerveDrive sets up its
   * telemetry.
   *
   * @return SwerveDriveTelemetryConfig if configured.
   */
  std::optional<telemetry::SwerveDriveTelemetryConfig> GetSwerveDriveTelemetryConfig();

  /**
   * Get the gyro angle with inversion applied.
   *
   * @throws std::runtime_error if no gyro supplier has been configured.
   */
  wpi::units::degree_t GetGyroAngle() const;

  /**
   * The robot's attitude: the gyro's attitude rotated into the robot's frame (see
   * WithGyroHeadingAxis), with the gyro inversion applied to its yaw. Its yaw is the
   * robot's heading, and its roll and pitch are the robot's tilt.
   *
   * @return The robot's attitude.
   * @throws std::runtime_error if no gyro supplier was set with WithGyro.
   */
  wpi::math::Rotation3d GetGyroRotation3d() const;

  /**
   * The anti-tipping correction for the current attitude, robot relative. Zero when anti-tipping
   * or the gyro is not configured.
   *
   * @return The chassis velocity to add.
   */
  wpi::math::ChassisVelocities GetAntiTippingCorrection() const;

  /**
   * The module state optimization setting from WithModuleStateOptimization, if it was set.
   *
   * @return true or false if set, or std::nullopt to leave each module's own setting.
   */
  std::optional<bool> GetModuleStateOptimization() const;

  /**
   * The discretization time in use: the simulation one in simulation, the real one otherwise.
   *
   * @return The discretization time, if set.
   */
  std::optional<wpi::units::second_t> GetDiscretization() const;

  /**
   * Apply angular-velocity skew correction and ChassisSpeeds discretization.
   *
   * @param speeds Raw robot-relative chassis speeds.
   * @return Optimized chassis speeds.
   */
  wpi::math::ChassisVelocities OptimizeRobotRelativeChassisSpeeds(
      wpi::math::ChassisVelocities speeds) const;

  /**
   * Get the active translation PID controller used for drive to pose (sim variant if in
   * simulation and configured).
   *
   * @return Reference to the translation PID controller, or empty when none is configured.
   */
  std::optional<std::reference_wrapper<wpi::math::PIDController>> GetTranslationPID();

  /**
   * Get the active rotation PID controller used for drive to pose and heading control (sim
   * variant if in simulation and configured).
   *
   * @return Reference to the rotation PID controller, or empty when none is configured.
   */
  std::optional<std::reference_wrapper<wpi::math::PIDController>> GetRotationPID();

  /** Cube the polar-coordinate magnitude of a Translation2d. */
  static wpi::math::Translation2d CubeTranslation(wpi::math::Translation2d translation);

  /** Scale the polar-coordinate magnitude of a Translation2d by a scalar. */
  static wpi::math::Translation2d ScaleTranslation(wpi::math::Translation2d translation,
                                                   double scalar);

 private:
  std::vector<SwerveModule*> m_modules;
  wpi::cmd::SubsystemBase* m_subsystem{nullptr};
  std::string m_telemetryName{"swerve"};
  std::optional<TelemetryVerbosity> m_telemetryVerbosity;
  std::optional<telemetry::SwerveDriveTelemetryConfig> m_specifiedTelemetryConfig;
  std::optional<std::function<wpi::math::Rotation3d()>> m_gyroSupplier;
  config::GyroAxis m_gyroHeadingAxis{config::GyroAxis::YAW};
  // Heading unwrapped across the half rotation boundary, for deriving the angular velocity.
  mutable double m_continuousHeadingRadians{0};
  mutable bool m_continuousHeadingRead{false};
  mutable math::DerivativeTimeFilter m_gyroAngularVelocityFilter{wpi::units::millisecond_t{20}};
  mutable std::optional<wpi::util::Alert> m_noGyroAngularVelocitySupplierAlert;
  std::optional<std::function<wpi::units::degrees_per_second_t()>> m_gyroAngularVelocitySupplier;
  bool m_gyroInverted{false};
  wpi::math::Pose2d m_initialPose;
  std::optional<wpi::units::meters_per_second_t> m_maximumChassisLinearVelocity;
  std::optional<wpi::units::degrees_per_second_t> m_maximumChassisAngularVelocity;
  std::optional<wpi::units::meters_per_second_t> m_maximumModuleLinearVelocity;
  std::optional<bool> m_moduleStateOptimization;
  std::optional<wpi::math::AntiTipping> m_antiTipping;
  std::optional<wpi::units::second_t> m_discretizationSeconds;
  std::optional<wpi::units::second_t> m_simDiscretizationSeconds;
  std::optional<double> m_angularVelocityScaleFactor;
  std::optional<double> m_simAngularVelocityScaleFactor;
  std::optional<wpi::math::Translation2d> m_centerOfRotation;
  std::optional<wpi::math::PIDController> m_translationController;
  std::optional<wpi::math::PIDController> m_rotationController;
  std::optional<wpi::math::PIDController> m_simTranslationController;
  std::optional<wpi::math::PIDController> m_simRotationController;

  wpi::math::ChassisVelocities AngularVelocitySkewCorrection(
      wpi::math::ChassisVelocities robotRelativeSpeeds) const;
};

}  // namespace yams::mechanisms::swerve
