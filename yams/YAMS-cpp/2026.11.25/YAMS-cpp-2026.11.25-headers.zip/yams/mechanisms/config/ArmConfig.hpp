// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once

#include <optional>
#include <string>
#include <wpi/units/angle.hpp>
#include <wpi/units/angular_velocity.hpp>
#include <wpi/units/length.hpp>
#include <wpi/units/moment_of_inertia.hpp>
#include <wpi/util/Color.hpp>
#include <wpi/util/Color8Bit.hpp>

#include "yams/mechanisms/config/MechanismPositionConfig.hpp"

namespace yams::mechanisms::config {

/**
 * Configuration class for an Arm mechanism.
 *
 * Uses a fluent builder pattern; all With* methods return *this for chaining.
 */
class ArmConfig {
 public:
  ArmConfig() = default;

  // ---- Builder methods -------------------------------------------------------

  /**
   * Set the NetworkTables / SmartDashboard name for telemetry.
   *
   * @param name Telemetry name string.
   * @return *this for chaining.
   */
  ArmConfig& WithTelemetryName(const std::string& name);

  /**
   * Set the minimum (lower hard) angle for simulation and soft-limit purposes.
   *
   * @param angle Minimum angle.
   * @return *this for chaining.
   */
  ArmConfig& WithMinAngle(wpi::units::degree_t angle);

  /**
   * Set the maximum (upper hard) angle for simulation and soft-limit purposes.
   *
   * @param angle Maximum angle.
   * @return *this for chaining.
   */
  ArmConfig& WithMaxAngle(wpi::units::degree_t angle);

  /**
   * Set the physical arm length for MOI estimation and visualisation.
   *
   * @param length Length of the arm.
   * @return *this for chaining.
   */
  ArmConfig& WithArmLength(wpi::units::meter_t length);

  /**
   * Set the Mechanism2d simulation colour for the arm ligament (default: aqua).
   *
   * @param color Desired colour.
   * @return *this for chaining.
   */
  ArmConfig& WithSimColor(const wpi::util::Color8Bit& color);

  /**
   * Set where the mechanism is on the robot, for GetPose3d(): where it is mounted, how it is turned
   * there, the plane it moves in, and the mechanism it is mounted on, if any.
   *
   * @param mechanismPositionConfig The mechanism's position.
   * @return *this for chaining.
   */
  ArmConfig& WithMechanismPositionConfig(const MechanismPositionConfig& mechanismPositionConfig) {
    m_mechanismPositionConfig = mechanismPositionConfig;
    return *this;
  }

  // ---- Getters ---------------------------------------------------------------

  /** Get the telemetry name. */
  std::string GetTelemetryName() const;

  /** Get the optional minimum (lower hard-limit) angle. */
  std::optional<wpi::units::degree_t> GetMinAngle() const;

  /** Get the optional maximum (upper hard-limit) angle. */
  std::optional<wpi::units::degree_t> GetMaxAngle() const;

  /** Get the optional arm length. */
  std::optional<wpi::units::meter_t> GetArmLength() const;

  /** Get the Mechanism2d simulation colour. */
  wpi::util::Color8Bit GetSimColor() const;

  /** Get where the mechanism is on the robot. */
  const MechanismPositionConfig& GetMechanismPositionConfig() const { return m_mechanismPositionConfig; }

 private:
  std::string m_telemetryName;
  std::optional<wpi::units::degree_t> m_minAngle;
  std::optional<wpi::units::degree_t> m_maxAngle;
  std::optional<wpi::units::meter_t> m_armLength;
  wpi::util::Color8Bit m_simColor{wpi::util::Color::AQUA};
  MechanismPositionConfig m_mechanismPositionConfig;
};

}  // namespace yams::mechanisms::config
