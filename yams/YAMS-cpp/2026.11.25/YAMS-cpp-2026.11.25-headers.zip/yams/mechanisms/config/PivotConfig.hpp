// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once

#include <optional>
#include <string>
#include <wpi/units/angle.hpp>
#include <wpi/units/angular_velocity.hpp>
#include <wpi/units/moment_of_inertia.hpp>
#include <wpi/util/Color.hpp>
#include <wpi/util/Color8Bit.hpp>

#include "yams/mechanisms/config/MechanismPositionConfig.hpp"

namespace yams::mechanisms::config {

/**
 * Configuration class for a Pivot mechanism.
 *
 * Pivots are similar to Arms but do not necessarily have a meaningful arm
 * length they typically rotate a mechanism around a fixed axis.  Uses a
 * fluent builder pattern; all With* methods return *this for chaining.
 */
class PivotConfig {
 public:
  PivotConfig() = default;

  // ---- Builder methods -------------------------------------------------------

  /**
   * Set the NetworkTables / SmartDashboard name for telemetry.
   *
   * @param name Telemetry name string.
   * @return *this for chaining.
   */
  PivotConfig& WithTelemetryName(const std::string& name);

  /**
   * Set the minimum (lower hard) angle for simulation and soft-limit purposes.
   *
   * @param angle Minimum angle.
   * @return *this for chaining.
   */
  PivotConfig& WithMinAngle(wpi::units::degree_t angle);

  /**
   * Set the maximum (upper hard) angle for simulation and soft-limit purposes.
   *
   * @param angle Maximum angle.
   * @return *this for chaining.
   */
  PivotConfig& WithMaxAngle(wpi::units::degree_t angle);

  /**
   * Set the Mechanism2d simulation colour for the pivot ligament (default: green).
   *
   * @param color Desired colour.
   * @return *this for chaining.
   */
  PivotConfig& WithSimColor(const wpi::util::Color8Bit& color);

  /**
   * Set where the mechanism is on the robot, for GetPose3d(): where it is mounted, how it is turned
   * there, the plane it moves in, and the mechanism it is mounted on, if any.
   *
   * @param mechanismPositionConfig The mechanism's position.
   * @return *this for chaining.
   */
  PivotConfig& WithMechanismPositionConfig(const MechanismPositionConfig& mechanismPositionConfig) {
    m_mechanismPositionConfig = mechanismPositionConfig;
    return *this;
  }

  // ---- Getters ---------------------------------------------------------------

  /** Get the telemetry name. */
  std::string GetTelemetryName() const;

  /** Get the optional minimum (lower hard-limit) angle. */
  std::optional<wpi::units::degree_t> GetMinAngle() const;

  /** Get the optional maximum (upper hard-limit) angle. */
  std::optional<wpi::units::degree_t> GetMaxAngle() const;

  /** Get the Mechanism2d simulation colour. */
  wpi::util::Color8Bit GetSimColor() const;

  /** Get where the mechanism is on the robot. */
  const MechanismPositionConfig& GetMechanismPositionConfig() const { return m_mechanismPositionConfig; }

 private:
  std::string m_telemetryName;
  std::optional<wpi::units::degree_t> m_minAngle;
  std::optional<wpi::units::degree_t> m_maxAngle;
  wpi::util::Color8Bit m_simColor{wpi::util::Color::GREEN};
  // A pivot, such as a turret, turns in the XY plane unless given a MechanismPositionConfig, as in
  // Java.
  MechanismPositionConfig m_mechanismPositionConfig{
      MechanismPositionConfig{}.WithMovementPlane(MechanismPositionConfig::Plane::XY)};
};

}  // namespace yams::mechanisms::config
