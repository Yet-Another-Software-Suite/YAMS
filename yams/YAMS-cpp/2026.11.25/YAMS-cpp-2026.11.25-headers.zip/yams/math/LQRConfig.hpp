// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once

#include <memory>
#include <optional>
#include <variant>
#include <vector>
#include <wpi/math/controller/LinearQuadraticRegulator.hpp>
#include <wpi/math/estimator/KalmanFilter.hpp>
#include <wpi/math/system/DCMotor.hpp>
#include <wpi/math/system/LinearSystem.hpp>
#include <wpi/math/system/LinearSystemLoop.hpp>
#include <wpi/math/system/Models.hpp>
#include <wpi/units/time.hpp>
#include <wpi/units/voltage.hpp>

namespace yams::math {

/**
 * Configuration for an LQR (Linear Quadratic Regulator) closed-loop controller.
 *
 * Uses a fluent builder pattern; all With* methods return *this for chaining.
 * After configuring the plant type, gains, and noise parameters call GetLoop() to obtain
 * the ready-to-use LinearSystemLoop, in a LoopBundle that owns everything it points to.
 */
class LQRConfig {
 public:
  /** Identifies which plant model the LQR is built for. */
  enum class LQRType {
    FLYWHEEL,  ///< Flywheel (1-state velocity model).
    ARM,       ///< Single-jointed arm (2-state position+velocity model).
    ELEVATOR,  ///< Elevator (2-state position+velocity model).
  };

  /** LinearSystemLoop type alias for 1-state plants (flywheel). */
  using Loop1 = wpi::math::LinearSystemLoop<1, 1, 1>;
  /** LinearSystemLoop type alias for 2-state plants (arm, elevator). */
  using Loop2 = wpi::math::LinearSystemLoop<2, 1, 1>;

  /**
   * A LinearSystemLoop with everything it points to. wpi::math::LinearSystemLoop keeps raw pointers to its LQR and
   * Kalman filter, and wpi::math::KalmanFilter keeps a raw pointer to its plant, so all four live together here, on
   * the heap, the plant first. Neither copyable nor movable, so the pointers never dangle.
   *
   * @tparam States Number of modeled states: 1 for a flywheel, 2 for an arm or elevator.
   */
  template <int States>
  struct LoopBundle {
    wpi::math::LinearSystem<States, 1, 1> plant;             ///< The plant the filter points to.
    wpi::math::LinearQuadraticRegulator<States, 1> controller;  ///< The LQR the loop points to.
    wpi::math::KalmanFilter<States, 1, 1> observer;          ///< The Kalman filter the loop points to.
    wpi::math::LinearSystemLoop<States, 1, 1> loop;          ///< The loop to run.

    /**
     * Build the loop.
     *
     * @param system       Plant.
     * @param qElems       State error tolerances.
     * @param rElems       Control effort tolerance.
     * @param stateStdDevs Model standard deviations.
     * @param measStdDevs  Encoder standard deviation.
     * @param maxV         Maximum output voltage.
     * @param dt           Loop period.
     */
    LoopBundle(const wpi::math::LinearSystem<States, 1, 1>& system, const wpi::util::array<double, States>& qElems,
               const wpi::util::array<double, 1>& rElems, const wpi::util::array<double, States>& stateStdDevs,
               const wpi::util::array<double, 1>& measStdDevs, wpi::units::volt_t maxV, wpi::units::second_t dt)
        : plant{system},
          controller{plant, qElems, rElems, dt},
          observer{plant, stateStdDevs, measStdDevs, dt},
          loop{plant, controller, observer, maxV, dt} {}

    LoopBundle(const LoopBundle&) = delete;
    LoopBundle& operator=(const LoopBundle&) = delete;
    LoopBundle(LoopBundle&&) = delete;
    LoopBundle& operator=(LoopBundle&&) = delete;
  };

  /**
   * Set the LQR plant type explicitly.
   *
   * @param type LQRType to use.
   * @return *this for chaining.
   */
  LQRConfig& WithType(LQRType type);

  /**
   * Configure a flywheel plant model.
   *
   * @param motor          DC motor model.
   * @param momentOfInertia Moment of inertia of the flywheel (kg·m²).
   * @param gearing        Gear reduction from motor to flywheel.
   * @return *this for chaining.
   */
  LQRConfig& WithFlywheelSystem(const wpi::math::DCMotor& motor, double momentOfInertia,
                                double gearing);

  /**
   * Configure a single-jointed arm plant model.
   *
   * @param motor          DC motor model.
   * @param momentOfInertia Moment of inertia of the arm (kg·m²).
   * @param gearing        Gear reduction from motor to arm joint.
   * @return *this for chaining.
   */
  LQRConfig& WithArmSystem(const wpi::math::DCMotor& motor, double momentOfInertia, double gearing);

  /**
   * Configure an elevator plant model.
   *
   * @param motor      DC motor model.
   * @param mass       Carriage mass (kg).
   * @param drumRadius Radius of the drum (m).
   * @param gearing    Gear reduction from motor to drum.
   * @return *this for chaining.
   */
  LQRConfig& WithElevatorSystem(const wpi::math::DCMotor& motor, double mass, double drumRadius,
                                double gearing);

  /**
   * Set the Q matrix diagonal elements (state error tolerances).
   *
   * Decrease values to more aggressively penalize state excursion.
   *
   * @param qElems Q-matrix diagonal entries (one per state).
   * @return *this for chaining.
   */
  LQRConfig& WithQElems(std::initializer_list<double> qElems);

  /**
   * Set the R matrix diagonal elements (control effort tolerances).
   *
   * Decrease values to more aggressively penalize control effort.
   * A good starting value is 12 (approximately the maximum battery voltage).
   *
   * @param rElems R-matrix diagonal entries (one per input).
   * @return *this for chaining.
   */
  LQRConfig& WithRElems(std::initializer_list<double> rElems);

  /**
   * Set the Kalman filter model standard deviations.
   *
   * @param stateStdDevs Standard deviations of the model states.
   * @return *this for chaining.
   */
  LQRConfig& WithStateStdDevs(std::initializer_list<double> stateStdDevs);

  /**
   * Set the Kalman filter measurement standard deviations.
   *
   * @param measStdDevs Standard deviations of the encoder measurements.
   * @return *this for chaining.
   */
  LQRConfig& WithMeasurementStdDevs(std::initializer_list<double> measStdDevs);

  /**
   * Set the maximum voltage output of the LinearSystemLoop.
   *
   * @param maxVoltage Maximum voltage (default 12 V).
   * @return *this for chaining.
   */
  LQRConfig& WithMaxVoltage(wpi::units::volt_t maxVoltage);

  /**
   * Set the loop period for the LQR.
   *
   * @param period Loop period (default 20 ms).
   * @return *this for chaining.
   */
  LQRConfig& WithPeriod(wpi::units::second_t period);

  /**
   * Get the configured LQR plant type.
   *
   * @return LQRType.
   */
  LQRType GetType() const;

  /**
   * Get the configured loop period.
   *
   * @return Loop period.
   */
  wpi::units::second_t GetPeriod() const;

  /**
   * Get the configured maximum voltage.
   *
   * @return Maximum voltage.
   */
  wpi::units::volt_t GetMaxVoltage() const;

  /**
   * Get the state error tolerances in use, in SI units: rad/s for a flywheel, rad and rad/s for an arm, m and m/s for
   * an elevator. Unset tolerances are the defaults the loop is built with.
   *
   * @return One tolerance per modeled state.
   */
  std::vector<double> GetQElems() const;

  /**
   * Get the control effort (voltage) tolerances in use, in volts.
   *
   * @return One tolerance per input.
   */
  std::vector<double> GetRElems() const;

  /**
   * Get the model's standard deviations in use, in the SI units of GetQElems().
   *
   * @return One standard deviation per modeled state.
   */
  std::vector<double> GetStateStdDevs() const;

  /**
   * Get the encoder's standard deviations in use, in SI units: rad/s for a flywheel, rad for an arm, m for an
   * elevator.
   *
   * @return One standard deviation per measurement.
   */
  std::vector<double> GetMeasurementStdDevs() const;

  /**
   * Set the state error tolerances, as when live tuning them, checking them.
   *
   * @param qElems One tolerance per modeled state, each above 0, in the SI units of GetQElems().
   * @return *this for chaining.
   * @throws std::invalid_argument if the number of values doesn't match the mechanism type, or one isn't above 0.
   */
  LQRConfig& WithQElems(const std::vector<double>& qElems);

  /**
   * Set the control effort (voltage) tolerance, as when live tuning it, checking it.
   *
   * @param rElems One tolerance, above 0, in volts.
   * @return *this for chaining.
   * @throws std::invalid_argument if there isn't one value, or it isn't above 0.
   */
  LQRConfig& WithRElems(const std::vector<double>& rElems);

  /**
   * Set the model's standard deviations, as when live tuning them, checking them.
   *
   * @param stateStdDevs One standard deviation per modeled state, each above 0.
   * @return *this for chaining.
   * @throws std::invalid_argument if the number of values doesn't match the mechanism type, or one isn't above 0.
   */
  LQRConfig& WithStateStdDevs(const std::vector<double>& stateStdDevs);

  /**
   * Set the encoder's standard deviation, as when live tuning it, checking it.
   *
   * @param measStdDevs One standard deviation, above 0.
   * @return *this for chaining.
   * @throws std::invalid_argument if there isn't one value, or it isn't above 0.
   */
  LQRConfig& WithMeasurementStdDevs(const std::vector<double>& measStdDevs);

  /**
   * Build and return the linear plant model.
   *
   * @return Variant holding a 1-state system (flywheel) or 2-state system (arm/elevator).
   */
  std::variant<wpi::math::LinearSystem<1, 1, 1>, wpi::math::LinearSystem<2, 1, 1>> GetSystem()
      const;

  /**
   * Build and return the complete LinearSystemLoop ready for use, with the plant, LQR and Kalman filter it points to.
   *
   * @return Variant holding a 1-state bundle (flywheel) or a 2-state bundle (arm/elevator).
   */
  std::variant<std::unique_ptr<LoopBundle<1>>, std::unique_ptr<LoopBundle<2>>> GetLoop() const;

 private:
  friend class LQRController;

  /** The values, checked against the count the mechanism type needs and that each is above 0. */
  static std::vector<double> Checked(const std::vector<double>& values, size_t size, const char* name);

  std::optional<LQRType> m_type;
  std::optional<wpi::math::LinearSystem<1, 1, 1>> m_flywheelPlant;
  std::optional<wpi::math::LinearSystem<2, 1, 1>> m_armElevatorPlant;

  std::vector<double> m_qElems;
  std::vector<double> m_rElems;
  std::vector<double> m_stateStdDevs;
  std::vector<double> m_measStdDevs;

  wpi::units::volt_t m_maxVoltage{wpi::units::volt_t{12.0}};
  wpi::units::second_t m_period{wpi::units::second_t{0.020}};
};

}  // namespace yams::math
