// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.mechanisms.swerve;

import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.MetersPerSecond;
import static edu.wpi.first.units.Units.Rotations;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.AngularVelocity;
import edu.wpi.first.units.measure.Distance;
import edu.wpi.first.units.measure.Force;
import edu.wpi.first.units.measure.LinearVelocity;
import edu.wpi.first.wpilibj.RobotBase;
import java.util.function.Supplier;
import yams.exceptions.SmartMotorControllerConfigurationException;
import yams.mechanisms.config.SwerveModuleConfig;
import yams.motorcontrollers.SmartMotorController;
import yams.motorcontrollers.SmartMotorControllerConfig.TelemetryVerbosity;
import yams.telemetry.MechanismTelemetry;
import yams.telemetry.SwerveModuleTelemetry;
import yams.telemetry.SwerveModuleTelemetryConfig;

/**
 * Swerve Module
 *
 * <p>{@link SwerveModule} coordinates the drive motor (velocity control) and the azimuth (steer)
 * motor (position control) that make up one corner of a swerve drivetrain. On construction it reads
 * the absolute encoder and seeds the azimuth relative encoder so the wheel starts at the correct
 * angle. Each periodic cycle you call {@link #setSwerveModuleState(SwerveModuleState)} to command
 * both motors, and {@link #getState()} / {@link #getPosition()} to read back the current wheel
 * velocity and heading.
 *
 * <h2>Typical usage</h2>
 *
 * <p>In almost every case you should <b>not</b> instantiate {@link SwerveModule} directly. Instead,
 * pass one {@link yams.mechanisms.config.SwerveModuleConfig} per corner to {@link yams.mechanisms.config.SwerveDriveConfig} and let {@link yams.mechanisms.swerve.SwerveDrive}
 * create and manage the modules internally:
 *
 * <pre>{@code
 * SwerveDriveConfig driveConfig = new SwerveDriveConfig()
 *     .withSwerveModuleConfig(frontLeft, frontRight, backLeft, backRight);
 *
 * SwerveDrive swerveDrive = new SwerveDrive(driveConfig);
 * }</pre>
 *
 * <h2>Direct instantiation (advanced)</h2>
 *
 * <p>If you need direct access to a module — for example when writing unit tests or custom
 * characterisation routines — you can construct one from a fully-configured {@link yams.mechanisms.config.SwerveModuleConfig}:
 *
 * <pre>{@code
 * // Assumes 'frontLeftConfig' has already been built with drive/steer motors,
 * // wheel radius, module location, absolute encoder offset, and telemetry name.
 * SwerveModule frontLeft = new SwerveModule(frontLeftConfig);
 *
 * // Command a specific state (angle + speed)
 * SwerveModuleState desiredState = new SwerveModuleState(1.5, Rotation2d.fromDegrees(45));
 * frontLeft.setSwerveModuleState(desiredState);
 *
 * // Read back current state
 * SwerveModuleState current = frontLeft.getState();
 * }</pre>
 */
public class SwerveModule {
  /** Drive motor controller. */
  protected final SmartMotorController m_driveMotorController;

  /** Azimuth motor controller. */
  protected final SmartMotorController m_azimuthMotorController;

  /** Swerve module configuration. */
  private final SwerveModuleConfig m_config;

  /** Mechanism Telemetry, used for the loop time. */
  private final MechanismTelemetry m_telemetry = new MechanismTelemetry();

  /** Absolute encoder angle, and drive/azimuth motor controller telemetry. */
  private SwerveModuleTelemetry m_swerveModuleTelemetry;

  /** Absolute encoder angle without any offsets applied. */
  private final Supplier<Angle> m_azimuthEncoderWithoutOffsets;

  /** Azimuth angle at the last {@link #getPosition()}, for the azimuth's travel. */
  private Rotation2d m_lastAzimuthAngle;

  /** How far the azimuth has turned in total, for taking the coupling out of the drive distance. */
  private Angle m_azimuthTravel = Rotations.zero();

  /**
   * Create a SwerveModule.
   *
   * @param config {@link SwerveModuleConfig} for the module.
   */
  public SwerveModule(SwerveModuleConfig config) {
    m_config = config;
    m_driveMotorController = config.getDriveMotor();
    m_azimuthMotorController = config.getAzimuthMotor();
    if (m_config.getTelemetryName().isEmpty()) {
      throw new IllegalArgumentException("SwerveModuleConfig must have a telemetry name!");
    }
    if (m_config.getLocation().isEmpty()) {
      throw new IllegalArgumentException("SwerveModuleConfig must have a position!");
    }
    if (m_azimuthMotorController.getConfig().getExternalEncoder().isPresent() && !m_azimuthMotorController.getConfig().getUseExternalFeedback()) {
      throw new SmartMotorControllerConfigurationException("External encoder cannot be used without external feedback", "External encoder could not be used", "withUseExternalFeedbackEncoder(true)");
    }
    seedAzimuthEncoder();
    m_azimuthEncoderWithoutOffsets = config.getRawAbsoluteEncoderAngle();
  }

  /**
   * Setup telemetry for the module; the {@link SwerveModuleTelemetry} config used is either the one
   * supplied via {@link SwerveModuleConfig#withTelemetry(String, SwerveModuleTelemetryConfig)} or a
   * default built from {@link SwerveModuleConfig#getTelemetryVerbosity()} (defaulting to {@link TelemetryVerbosity#HIGH}).
   *
   * @param mechName Telemetry name of the parent {@link SwerveDrive}.
   */
  public void setupTelemetry(String mechName) {
    m_telemetry.setupTelemetry(mechName + "/modules/" + getName());
    var cfg = m_config.getSwerveModuleTelemetryConfig().orElseGet(() -> new SwerveModuleTelemetryConfig().withTelemetryVerbosity(m_config.getTelemetryVerbosity().orElse(TelemetryVerbosity.HIGH)));
    m_swerveModuleTelemetry = new SwerveModuleTelemetry(cfg);
    m_swerveModuleTelemetry.setupTelemetry(mechName, this);
  }

  /**
   * Get the absolute encoder angle without any offsets applied.
   *
   * @return {@link Angle} of the absolute encoder without offsets.
   */
  public Angle getRawAbsoluteEncoderAngle() {
    return m_azimuthEncoderWithoutOffsets.get();
  }

  /** Seed the azimuth encoder with the absolute encoder angle. */
  public void seedAzimuthEncoder() {
    if (RobotBase.isReal() && (m_azimuthMotorController.getConfig().getExternalEncoder().isEmpty() || !m_azimuthMotorController.getConfig().getUseExternalFeedback())) {
      m_azimuthMotorController.setEncoderPosition(m_config.getAbsoluteEncoderAngle());
    }
  }

  /**
   * Get the name of the module.
   *
   * @return Name of the module.
   */
  public String getName() {
    return m_config.getTelemetryName().orElseThrow();
  }

  /**
   * Get the {@link SwerveModuleConfig} for the module.
   *
   * @return {@link SwerveModuleConfig} for the module.
   */
  public SwerveModuleConfig getConfig() {
    return m_config;
  }

  /**
   * Turn the wheel to the given angle without driving it, as for locking the drive in place. The
   * velocity deadband, which holds a wheel commanded too slowly to steer by where it is, does not
   * apply (see {@link SwerveModuleConfig#getLockedState(Rotation2d)}).
   *
   * @param angle Angle to turn the wheel to.
   * @return The zero speed {@link SwerveModuleState} the module was set to.
   */
  public SwerveModuleState lock(Rotation2d angle) {
    final SwerveModuleState state = m_config.getLockedState(angle);
    m_driveMotorController.setVelocity(MetersPerSecond.of(0).plus(getCouplingVelocity()));
    m_azimuthMotorController.setPosition(state.angle.getMeasure());
    return state;
  }

  /**
   * Set the {@link SwerveModuleState} of the module.
   *
   * @param state State to set.
   * @return The optimized {@link SwerveModuleState}.
   */
  public SwerveModuleState setSwerveModuleState(SwerveModuleState state) {
    state = m_config.getOptimizedState(state);
    m_driveMotorController.setVelocity(MetersPerSecond.of(state.speedMetersPerSecond).plus(getCouplingVelocity()));
    m_azimuthMotorController.setPosition(state.angle.getMeasure());
    return state;
  }

  /**
   * Set the {@link SwerveModuleState} of the module with an additional drive wheel feedforward
   * {@link Force} applied on top, e.g. from a PathPlanner set-point generator.
   *
   * @param state            State to set.
   * @param feedforwardForce Feedforward {@link Force} applied at the drive wheel, in the direction
   *                         of travel.
   * @return The optimized {@link SwerveModuleState}.
   */
  public SwerveModuleState setSwerveModuleState(SwerveModuleState state, Force feedforwardForce) {
    final Rotation2d requestedAngle = state.angle;
    state = m_config.getOptimizedState(state);
    // The force is along the requested direction of travel. Optimization may have turned the wheel
    // around and reversed its velocity, in which case the force must be reversed with it.
    if (state.angle.minus(requestedAngle).getCos() < 0) {
      feedforwardForce = feedforwardForce.unaryMinus();
    }
    // Scale the force like the velocity, so a wheel still turning to its angle is not pushed.
    feedforwardForce = feedforwardForce.times(m_config.getCosineCompensationScalar(state.angle));
    m_driveMotorController.setVelocity(MetersPerSecond.of(state.speedMetersPerSecond).plus(getCouplingVelocity()), feedforwardForce);
    m_azimuthMotorController.setPosition(state.angle.getMeasure());
    return state;
  }

  /**
   * Get the {@link SwerveModuleState} of the module.
   *
   * @return {@link SwerveModuleState} of the module.
   */
  public SwerveModuleState getState() {
    return new SwerveModuleState(m_driveMotorController.getMeasurementVelocity().minus(getCouplingVelocity()), new Rotation2d(m_azimuthMotorController.getMechanismPosition()));
  }

  /**
   * Get the {@link SwerveModulePosition} of the module.
   *
   * @return {@link SwerveModulePosition} of the module.
   */
  public SwerveModulePosition getPosition() {
    final Rotation2d azimuthAngle = new Rotation2d(m_azimuthMotorController.getMechanismPosition());
    // Add up how far the azimuth has turned, the short way round each time, so a wrap of the angle
    // does not count as a turn.
    if (m_lastAzimuthAngle != null) {
      m_azimuthTravel = m_azimuthTravel.plus(azimuthAngle.minus(m_lastAzimuthAngle).getMeasure());
    }
    m_lastAzimuthAngle = azimuthAngle;
    return new SwerveModulePosition(m_driveMotorController.getMeasurementPosition().minus(getCouplingDistance(m_azimuthTravel)), azimuthAngle);
  }

  /**
   * How far the wheel is driven by the azimuth turning the given angle, through the coupling.
   *
   * @param azimuthAngle How far the azimuth turned.
   * @return Distance the wheel was driven; zero without a coupling ratio.
   */
  private Distance getCouplingDistance(Angle azimuthAngle) {
    return m_config.getCouplingRatio()
                   .map(couplingRatio -> m_driveMotorController.getConfig().convertFromMechanism(
                       azimuthAngle.times(couplingRatio.getOutputToInputConversionFactor()).times(m_driveMotorController.getConfig().getGearing().getRotorToMechanismRatio())))
                   .orElse(Meters.zero());
  }

  /**
   * How fast the wheel is driven by the azimuth turning, through the coupling.
   *
   * @return Velocity of the wheel from the azimuth alone; zero without a coupling ratio.
   */
  private LinearVelocity getCouplingVelocity() {
    return m_config.getCouplingRatio().map(couplingRatio -> {
      final AngularVelocity coupledWheelVelocity = m_azimuthMotorController.getMechanismVelocity().times(couplingRatio.getOutputToInputConversionFactor()).times(m_driveMotorController.getConfig().getGearing().getRotorToMechanismRatio());
      return m_driveMotorController.getConfig().convertFromMechanism(coupledWheelVelocity);
    }).orElse(MetersPerSecond.zero());
  }

  /** Update the telemetry of the module. */
  public void updateTelemetry() {
    m_driveMotorController.updateTelemetry();
    m_azimuthMotorController.updateTelemetry();
    m_swerveModuleTelemetry.publish(this);
    m_telemetry.updateLoopTime();
  }

  /** Update the simulation of the module. */
  public void simIterate() {
    m_driveMotorController.simIterate();
    m_azimuthMotorController.simIterate();
  }

  /**
   * Get the azimuth {@link SmartMotorController}.
   *
   * @return Azimuth {@link SmartMotorController}.
   */
  public SmartMotorController getAzimuthMotorController() {
    return m_azimuthMotorController;
  }

  /**
   * Get the drive {@link SmartMotorController}.
   *
   * @return Drive {@link SmartMotorController}.
   */
  public SmartMotorController getDriveMotorController() {
    return m_driveMotorController;
  }
}
