// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.mechanisms.swerve;

import static edu.wpi.first.hal.FRCNetComm.tInstances.kRobotDriveSwerve_YAGSL;
import static edu.wpi.first.hal.FRCNetComm.tResourceType.kResourceType_RobotDrive;
import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.Radians;
import static edu.wpi.first.units.Units.Rotations;

import edu.wpi.first.hal.HAL;
import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.estimator.SwerveDrivePoseEstimator;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.geometry.Twist2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveDriveKinematics;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N3;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.Distance;
import edu.wpi.first.units.measure.Force;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.smartdashboard.Field2d;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.RunCommand;
import java.util.Arrays;
import java.util.Optional;
import java.util.function.Supplier;
import yams.exceptions.SwerveDriveConfigurationException;
import yams.mechanisms.config.SwerveDriveConfig;
import yams.motorcontrollers.SmartMotorControllerConfig.TelemetryVerbosity;
import yams.telemetry.MechanismTelemetry;
import yams.telemetry.SwerveDriveTelemetry;
import yams.telemetry.SwerveDriveTelemetryConfig;

/**
 * Swerve Drive mechanism
 *
 * <h2>Usage Example</h2>
 *
 * <p>The typical pattern is to wrap {@code SwerveDrive} inside a WPILib {@code SubsystemBase}.
 * Build a {@link yams.mechanisms.config.SwerveDriveConfig} (see its class-level doc for the full
 * module-construction example), then instantiate {@code SwerveDrive} once in the subsystem
 * constructor.
 *
 * <p>{@link yams.mechanisms.swerve.utility.SwerveInputStream} is the <b>recommended</b> way to
 * convert raw joystick axes into field-relative {@link edu.wpi.first.math.kinematics.ChassisSpeeds}
 * before passing them to {@link #drive(java.util.function.Supplier)}.
 *
 * <pre>{@code
 * public class SwerveSubsystem extends SubsystemBase {
 *
 *     private final SwerveDrive drive;
 *
 *     public SwerveSubsystem() {
 *         // Build SwerveDriveConfig — see SwerveDriveConfig class doc for the full example.
 *         Pigeon2 gyro = new Pigeon2(14);
 *         SwerveDriveConfig config = new SwerveDriveConfig(this, fl, fr, bl, br)
 *             .withGyro(gyro.getYaw().asSupplier())
 *             .withMaximumChassisSpeed(MetersPerSecond.of(4.5), DegreesPerSecond.of(360))
 *             .withTranslationController(new PIDController(1.0, 0, 0))
 *             .withRotationController(new PIDController(1.0, 0, 0))
 *             .withStartingPose(new Pose2d());
 *
 *         drive = new SwerveDrive(config);
 *     }
 *
 *     // Convert joystick input to a field-relative drive command using SwerveInputStream.
 *     public Command driveWithJoystick(CommandXboxController controller) {
 *         SwerveInputStream inputStream = new SwerveInputStream(
 *                 drive,
 *                 controller::getLeftX,
 *                 controller::getLeftY,
 *                 controller::getRightX)
 *             .withMaximumLinearVelocity(MetersPerSecond.of(4.5))
 *             .withMaximumAngularVelocity(DegreesPerSecond.of(360))
 *             .withDeadband(0.05)
 *             .withCubeTranslationControllerAxis()
 *             .withAllianceRelativeControl();
 *
 *         // drive() accepts a robot-relative ChassisSpeeds supplier; SwerveInputStream handles
 *         // the field-to-robot conversion internally when alliance-relative control is enabled.
 *         return drive.drive(inputStream);
 *     }
 *
 *     // Alternatively, pass field-relative speeds directly.
 *     public Command driveFieldRelative(Supplier<ChassisSpeeds> speedsSupplier) {
 *         return run(() -> drive.setFieldRelativeChassisSpeeds(speedsSupplier.get()))
 *             .withName("Field Oriented Drive");
 *     }
 *
 *     // Read the fused odometry pose at any time.
 *     public Pose2d getRobotPose() {
 *         return drive.getPose();
 *     }
 *
 *     // Update odometry and publish telemetry every robot loop (20 ms).
 *     {@literal @}Override
 *     public void periodic() {
 *         drive.updateTelemetry();
 *     }
 *
 *     // Advance the simulated gyro and modules every simulation loop.
 *     {@literal @}Override
 *     public void simulationPeriodic() {
 *         drive.simIterate();
 *     }
 * }
 * }</pre>
 */
public class SwerveDrive {
  /** The modules of the drive. */
  private final SwerveModule[] m_modules;

  /** The pose estimator for the drive. */
  private final SwerveDrivePoseEstimator m_poseEstimator;

  /** The kinematics for the drive. */
  private final SwerveDriveKinematics m_kinematics;

  /** Timer for simulation purposes only. Not used in real robot code. */
  private final Timer m_simTimer = new Timer();

  /** The config for the drive. */
  private final SwerveDriveConfig m_config;

  /** Mechanism telemetry, used for the loop time and the {@link Field2d}. */
  private final MechanismTelemetry m_telemetry = new MechanismTelemetry();

  /** Pose, chassis speeds, gyro, and auto-align tuning telemetry. */
  private SwerveDriveTelemetry m_swerveTelemetry;

  /** Simulated Gyro Angle. Used for simulation purposes only. Not used in real robot code. */
  private Angle m_simGyroAngle = Rotations.of(0);

  /** Field to display the robot's pose. */
  private Field2d m_field2d = new Field2d();

  /** Last-commanded desired module states; cached and published from updateTelemetry. */
  private SwerveModuleState[] m_desiredModuleStates;

  /**
   * Last-commanded desired robot-relative chassis speeds; cached and published from
   * updateTelemetry.
   */
  private ChassisSpeeds m_desiredChassisSpeeds = new ChassisSpeeds();

  /** The simulated pose of the robot if the {@link SwerveModuleState} were met perfectly. */
  private Pose2d m_simPose = new Pose2d();

  /**
   * Create a SwerveDrive.
   *
   * @param config {@link SwerveDriveConfig} for the drive.
   */
  public SwerveDrive(SwerveDriveConfig config) {
    m_config = config;
    m_modules = config.getModules();
    // Covers modules given to the config after withModuleStateOptimization was called.
    config.getModuleStateOptimization().ifPresent(enabled -> Arrays.stream(m_modules).forEach(module -> module.getConfig().withOptimization(enabled)));
    m_desiredModuleStates = new SwerveModuleState[m_modules.length];
    m_simPose = config.getInitialPose();
    Arrays.fill(m_desiredModuleStates, new SwerveModuleState());
    m_kinematics = getKinematics();
    m_poseEstimator = new SwerveDrivePoseEstimator(m_kinematics, getGyroRotation3d().toRotation2d(), getModulePositions(), m_config.getInitialPose());
    // Start with the gyro reading the starting pose's heading so field relative driving matches it.
    resetOdometry(m_config.getInitialPose());
    setupTelemetry();
  }

  /**
   * Setup telemetry for the drive; the {@link SwerveDriveTelemetry} config used is either the one
   * supplied via {@link SwerveDriveConfig#withTelemetry(String,SwerveDriveTelemetryConfig)} or a
   * default built from {@link SwerveDriveConfig#getTelemetryVerbosity()} (defaulting to {@link TelemetryVerbosity#HIGH}).
   */
  private void setupTelemetry() {
    var cfg = m_config.getSwerveDriveTelemetryConfig().orElseGet(() -> new SwerveDriveTelemetryConfig().withTelemetryVerbosity(m_config.getTelemetryVerbosity().orElse(TelemetryVerbosity.HIGH)));
    if (cfg.getDataLogName().isPresent()) {
      m_telemetry.setupTelemetry(getName(), cfg.getDataLogName().get());
    } else {
      m_telemetry.setupTelemetry(getName());
    }

    m_swerveTelemetry = new SwerveDriveTelemetry(cfg);
    m_swerveTelemetry.setupTelemetry(this);
    m_field2d.setRobotPose(getPose());
    SmartDashboard.putData("Mechanisms/" + getName() + "/field", m_field2d);
    SmartDashboard.putData("Mechanisms/" + getName() + "/tuning", Commands.startRun(() -> {
      System.out.println("================= Starting SwerveDrive Tuning =================\n");
      resetTranslationPID();
      resetRotationPID();
    }, () -> m_swerveTelemetry.applyTuningValues(this)));
    // Report as YAGSL bc this will become apart of YAGSL in 2027...s
    HAL.report(kResourceType_RobotDrive, kRobotDriveSwerve_YAGSL);
  }

  /**
   * Create a {@link RunCommand} to drive the swerve drive with robot relative chassis speeds.
   *
   * @param robotRelativeChassisSpeeds {@link Supplier<ChassisSpeeds>} for the robot relative
   *                                   chassis speeds. Could also use {@link yams.mechanisms.swerve.utility.SwerveInputStream}
   * @return {@link RunCommand} to drive the swerve drive.
   * @implNote Not compatible with AdvantageKit
   */
  public Command drive(Supplier<ChassisSpeeds> robotRelativeChassisSpeeds) {
    return Commands.run(() -> setRobotRelativeChassisSpeeds(robotRelativeChassisSpeeds.get()), m_config.getSubsystem()).withName("Drive");
  }

  /**
   * Get the simulated pose of the robot, assuming the {@link SwerveModuleState}s commanded to the
   * modules are met perfectly. Useful for feeding a simulated vision system with ground-truth poses
   * under perfect-world conditions.
   *
   * @return Simulated {@link Pose2d} of the robot. Only updated in simulation by {@link #simIterate()}; on a real robot this remains the configured starting pose.
   */
  public Pose2d getSimPose() {
    return m_simPose;
  }

  /**
   * Point all modules toward the robot center, thus making the robot very difficult to move.
   * Forcing the robot to keep the current pose.
   *
   * @implNote Not compatible with AdvantageKit
   */
  public void lockPose() {
    // Turn each wheel toward the robot center without driving it. SwerveModule#lock skips the
    // velocity deadband, which would otherwise hold these zero speed states where the wheels are.
    for (int i = 0; i < m_modules.length; i++) {
      m_desiredModuleStates[i] = m_modules[i].lock(m_modules[i].getConfig().getLocation().orElseThrow().getAngle());
    }
    m_desiredChassisSpeeds = new ChassisSpeeds();
  }

  /**
   * Set the {@link SwerveModuleState}s of the swerve drive directly.
   *
   * @param states {@link SwerveModuleState}s to use, must be the same count as the swerve drive is
   *               configured order is Clockwise from FL.
   * @implNote Not compatible with AdvantageKit if MapleSim is defined.
   */
  public void setSwerveModuleStates(SwerveModuleState[] states) {
    for (int i = 0; i < states.length; i++) {
      // if MapleSim is configured, run the swerve states through it.
      //      if (RobotBase.isSimulation() && m_config.getMapleDriveSim().isPresent())
      //      {
      //        m_config.getMapleDriveSim().get().runSwerveStates(states);
      //      }
      m_desiredModuleStates[i] = m_modules[i].setSwerveModuleState(states[i]);
    }
  }

  /**
   * Set the {@link SwerveModuleState}s of the swerve drive directly, with an additional drive wheel
   * feedforward {@link Force} applied per module, e.g. from a PathPlanner set-point generator.
   *
   * @param states            {@link SwerveModuleState}s to use, must be the same count as the swerve drive is
   *                          configured order is Clockwise from FL.
   * @param feedforwardForces Feedforward {@link Force}s to apply, one per module in the same FL,
   *                          FR, BL, BR order as {@code states}.
   * @implNote Not compatible with AdvantageKit if MapleSim is defined.
   */
  public void setSwerveModuleStates(SwerveModuleState[] states, Force[] feedforwardForces) {
    for (int i = 0; i < states.length; i++) {
      m_desiredModuleStates[i] = m_modules[i].setSwerveModuleState(states[i], feedforwardForces[i]);
    }
  }

  /**
   * Get the {@link SwerveModuleState}s of the swerve drive given a robot relative chassis speed, desaturated to
   * {@link SwerveDriveConfig#getMaximumModuleLinearVelocity()} if it is set.
   *
   * @param robotRelativeChassisSpeeds Robot relative {@link ChassisSpeeds}.
   * @return {@link SwerveModuleState}s of the swerve drive.
   */
  public SwerveModuleState[] getStateFromRobotRelativeChassisSpeeds(ChassisSpeeds robotRelativeChassisSpeeds) {
    robotRelativeChassisSpeeds = m_config.optimizeRobotRelativeChassisSpeeds(robotRelativeChassisSpeeds);
    SwerveModuleState[] states = m_config.getCenterOfRotation().isPresent() ? m_kinematics.toSwerveModuleStates(robotRelativeChassisSpeeds, m_config.getCenterOfRotation().get()) : m_kinematics.toSwerveModuleStates(robotRelativeChassisSpeeds);
    // Scale all modules down together so none exceeds its maximum speed. Saturating modules individually would
    // break the speed ratios between them and make them fight each other.
    final ChassisSpeeds desiredSpeeds = robotRelativeChassisSpeeds;
    m_config.getMaximumModuleLinearVelocity().ifPresent(maxSpeed -> {
      var maxLinear = m_config.getMaximumChassisLinearVelocity();
      var maxAngular = m_config.getMaximumChassisAngularVelocity();
      if (maxLinear.isPresent() && maxAngular.isPresent()) {
        // With the chassis limits known, also scale for how much of them the request asks for.
        SwerveDriveKinematics.desaturateWheelSpeeds(states, desiredSpeeds, maxSpeed, maxLinear.get(), maxAngular.get());
      } else {
        SwerveDriveKinematics.desaturateWheelSpeeds(states, maxSpeed);
      }
    });
    return states;
  }

  /**
   * Get the {@link ChassisSpeeds} based off the {@link SwerveModuleState}s.
   *
   * @param states {@link SwerveModuleState}s to use, must be the same count as the swerve drive is.
   * @return {@link ChassisSpeeds} based off the {@link SwerveModuleState}s.
   */
  public ChassisSpeeds getRobotRelativeChassisSpeedsFromState(SwerveModuleState[] states) {
    return m_kinematics.toChassisSpeeds(states);
  }

  /**
   * Set robot relative chassis speeds.
   *
   * @param robotRelativeChassisSpeeds Robot relative chassis speeds.
   */
  public void setRobotRelativeChassisSpeeds(ChassisSpeeds robotRelativeChassisSpeeds) {
    setRobotRelativeChassisSpeeds(robotRelativeChassisSpeeds, new Force[0]);
  }

  /**
   * Set robot relative chassis speeds, with an additional drive wheel feedforward {@link Force}
   * applied per module, e.g. from a PathPlanner set-point generator.
   *
   * @param robotRelativeChassisSpeeds Robot relative chassis speeds.
   * @param feedforwardForces          Feedforward {@link Force}s to apply, one per module in FL, FR, BL, BR
   *                                   order. Pass an empty array to apply no feedforward.
   */
  public void setRobotRelativeChassisSpeeds(ChassisSpeeds robotRelativeChassisSpeeds, Force[] feedforwardForces) {
    m_desiredChassisSpeeds = robotRelativeChassisSpeeds;
    SwerveModuleState[] states = getStateFromRobotRelativeChassisSpeeds(robotRelativeChassisSpeeds);
    if (feedforwardForces.length == 0) {
      setSwerveModuleStates(states);
      return;
    }
    if (feedforwardForces.length != states.length) {
      throw new IllegalArgumentException("feedforwardForces must be empty or have one entry per module (" + states.length + "), in FL, FR, BL, BR order.");
    }
    setSwerveModuleStates(states, feedforwardForces);
  }

  /**
   * Set field relative chassis speeds.
   *
   * @param fieldRelativeChassisSpeeds Field relative chassis speeds.
   */
  public void setFieldRelativeChassisSpeeds(ChassisSpeeds fieldRelativeChassisSpeeds) {
    setRobotRelativeChassisSpeeds(ChassisSpeeds.fromFieldRelativeSpeeds(fieldRelativeChassisSpeeds, getGyroRotation3d().toRotation2d()));
  }

  /**
   * Gets the measured pose (position and rotation) of the robot, as reported by odometry.
   *
   * @return The robot's pose
   */
  public Pose2d getPose() {
    //    if (RobotBase.isSimulation() && m_config.getMapleDriveSim().isPresent())
    //    {
    //      return m_config.getMapleDriveSim().get().getOdometryEstimatedPose();
    //    }
    return m_poseEstimator.getEstimatedPosition();
  }

  /**
   * Create the {@link SwerveDriveKinematics} so you can recreate a new {@link SwerveDrivePoseEstimator}.
   *
   * @return {@link SwerveDriveKinematics}
   */
  public SwerveDriveKinematics getKinematics() {
    return new SwerveDriveKinematics(Arrays.stream(m_modules).map(module -> module.getConfig().getLocation().orElseThrow()).toArray(Translation2d[]::new));
  }

  //  /**
  //   * Gets the actual pose in the {@link org.ironmaple.simulation.SimulatedArena} from MapleSim.
  //   *
  //   * @return the robot's real pose.
  //   * @implNote Not compatible with AdvantageKit
  //   */
  //  public Pose2d getMapleSimPose()
  //  {
  //    if (RobotBase.isSimulation())
  //    {
  //      return m_config.getMapleDriveSim().get().getActualPoseInSimulationWorld();
  //    }
  //    throw new IllegalStateException("getMapleSimPose() is only available in simulation.");
  //  }

  /**
   * Resets the gyro angle to zero and resets odometry to the same position, but facing toward 0
   * (red alliance station).
   *
   * @implNote Not compatible with AdvantageKit
   */
  public void zeroGyro() {
    // If in sim reset to the simulated drive.
    //    resetOdometry(
    //        RobotBase.isSimulation() ? getMapleSimPose() : new Pose2d(getPose().getTranslation(),
    //        Rotation2d.kZero));
    resetOdometry(new Pose2d(getPose().getTranslation(), Rotation2d.kZero));
  }

  /**
   * Make {@link #getGyroRotation3d()} read the given heading as its yaw from now on. On a real robot
   * the gyro offset is adjusted; in simulation the simulated gyro angle is set directly.
   *
   * @param heading Heading the gyro should report.
   */
  private void setGyroAngle(Angle heading) {
    if (RobotBase.isSimulation()) {
      m_simGyroAngle = heading;
      return;
    }
    m_config.withGyroOffset(getGyroRotation3d().getMeasureZ().plus(m_config.getGyroOffset()).minus(heading));
  }

  /**
   * Get the robot's attitude from the gyro (see {@link SwerveDriveConfig#getGyroRotation3d()}): its
   * yaw is the robot's heading. In simulation, the simulated heading with no tilt.
   *
   * @return The robot's attitude.
   */
  public Rotation3d getGyroRotation3d() {
    if (RobotBase.isSimulation()) {
      return new Rotation3d(0, 0, m_simGyroAngle.in(Radians));
    }
    return m_config.getGyroRotation3d();
  }

  /**
   * Get the name of the drive.
   *
   * @return Name of the drive.
   */
  public String getName() {
    return m_config.getTelemetryName();
  }

  /**
   * Resets odometry to the given pose, and the gyro to the pose's heading so that field relative
   * driving agrees with the pose. Module positions do not need to be reset when calling this method.
   * However, if a module position is reset, this must be called in order for odometry to keep
   * working.
   *
   * @param pose The pose to set the odometry to. Field relative, blue-origin where 0deg is facing
   *             towards RED alliance.
   */
  public void resetOdometry(Pose2d pose) {
    //    if (RobotBase.isSimulation() && m_config.getMapleDriveSim().isPresent())
    //    {
    //      m_config.getMapleDriveSim().get().resetOdometry(pose);
    //      m_config.getMapleDriveSim().get().setSimulationWorldPose(pose);
    //    }
    setGyroAngle(pose.getRotation().getMeasure());
    m_poseEstimator.resetPosition(getGyroRotation3d().toRotation2d(), getModulePositions(), pose);
    m_desiredChassisSpeeds = new ChassisSpeeds();
    m_desiredModuleStates = m_kinematics.toSwerveModuleStates(new ChassisSpeeds());
    m_simPose = pose;
  }

  /** Resets the auto-align rotational PID controller. */
  public void resetRotationPID() {
    m_config.getRotationPID().ifPresent(PIDController::reset);
  }

  /** Resets the auto-align translation PID controller. */
  public void resetTranslationPID() {
    m_config.getTranslationPID().ifPresent(PIDController::reset);
  }

  /**
   * Set the auto-align rotational PID controller.
   *
   * @param controller {@link PIDController} to use, units given is in Radians.
   */
  public void setRotationPID(PIDController controller) {
    var currentRotationPID = m_config.getRotationPID();
    if (currentRotationPID.isEmpty() || currentRotationPID.get().getP() != controller.getP() || currentRotationPID.get().getI() != controller.getI() || currentRotationPID.get().getD() != controller.getD()) {
      controller.reset();
      m_config.withRotationController(controller);
    }
  }

  /**
   * Sets the auto-align translation PID controller.
   *
   * @param controller {@link PIDController} to reset, Units given is in Meters.
   */
  public void setTranslationPID(PIDController controller) {
    var currentTranslationPID = m_config.getTranslationPID();
    if (currentTranslationPID.isEmpty() || currentTranslationPID.get().getP() != controller.getP() || currentTranslationPID.get().getI() != controller.getI() || currentTranslationPID.get().getD() != controller.getD()) {
      controller.reset();
      m_config.withTranslationController(controller);
    }
  }

  /**
   * Get the {@link Distance} from the given pose to the robot.
   *
   * @param pose {@link Pose2d} to get the distance from.
   * @return {@link Distance} from the given pose to the robot.
   */
  public Distance getDistanceFromPose(Pose2d pose) {
    return Meters.of(getPose().getTranslation().getDistance(pose.getTranslation()));
  }

  /**
   * Get the angle difference between the robot's current pose and the given pose.
   *
   * @param pose {@link Pose2d} to get the angle difference from.
   * @return {@link Angle} difference between the robot's current pose and the given pose.
   */
  public Angle getAngleDifferenceFromPose(Pose2d pose) {
    return getPose().minus(pose).getRotation().getMeasure();
  }

  /**
   * Drive the robot to the given pose. The command runs until it is interrupted and stops the drive
   * when it is.
   *
   * @param pose {@link Pose2d} to drive the robot to. Field relative, blue-origin where 0deg is
   *             facing towards RED
   * @return {@link Command} that drives the robot toward the given pose until interrupted.
   * @implNote Not compatible with AdvantageKit
   */
  public Command driveToPose(Pose2d pose) {
    return Commands.startRun(() -> {
      resetTranslationPID();
      resetRotationPID();
    }, () -> setRobotRelativeChassisSpeeds(driveToPoseSetpoint(pose)), m_config.getSubsystem())
                   .finallyDo(() -> setRobotRelativeChassisSpeeds(new ChassisSpeeds()))
                   .withName("Drive to Pose");
  }

  /**
   * Drive the robot to the given pose, ending once the robot is within the given tolerances. The
   * drive is stopped when the command ends or is interrupted.
   *
   * @param pose                 {@link Pose2d} to drive the robot to. Field relative, blue-origin
   *                             where 0deg is facing towards RED
   * @param translationTolerance Maximum distance from the pose to be considered at the pose.
   * @param rotationTolerance    Maximum heading error from the pose to be considered at the pose.
   * @return {@link Command} to drive the robot to the given pose.
   * @implNote Not compatible with AdvantageKit
   */
  public Command driveToPose(Pose2d pose, Distance translationTolerance, Angle rotationTolerance) {
    return Commands.startRun(() -> {
      resetTranslationPID();
      resetRotationPID();
    }, () -> setRobotRelativeChassisSpeeds(driveToPoseSetpoint(pose)), m_config.getSubsystem())
                   .until(() -> isNear(pose, translationTolerance, rotationTolerance))
                   .finallyDo(this::stop)
                   .withName("Drive to Pose");
  }

  /**
   * Whether the robot is within the given tolerances of a pose.
   *
   * @param pose                 {@link Pose2d} to compare against.
   * @param translationTolerance Maximum distance from the pose.
   * @param rotationTolerance    Maximum heading error from the pose.
   * @return True if the robot is within both tolerances of the pose.
   */
  public boolean isNear(Pose2d pose, Distance translationTolerance, Angle rotationTolerance) {
    return getDistanceFromPose(pose).lte(translationTolerance) &&
           Math.abs(getAngleDifferenceFromPose(pose).in(Radians)) <= rotationTolerance.in(Radians);
  }

  /** Stop the drive by commanding zero chassis speeds. */
  public void stop() {
    setRobotRelativeChassisSpeeds(new ChassisSpeeds());
  }

  /**
   * Drive to the target pose, primarily for use in Live Tuning, could also be used for setpoint
   * commands.
   *
   * @param targetPose Pose to drive towards.
   * @implNote Remember to call {@link #resetRotationPID()} and {@link #resetTranslationPID()}
   *           before calling this method in a loop.
   * @return robot-relative {@link ChassisSpeeds} to drive the robot to the given pose.
   * @throws SwerveDriveConfigurationException if the translation or rotation PID controller is not
   *                                           configured.
   */
  public ChassisSpeeds driveToPoseSetpoint(Pose2d targetPose) {
    return driveToPoseSetpoint(targetPose, getPose(), getGyroRotation3d().toRotation2d());
  }

  /**
   * Drive to the target pose from a given pose and heading, for callers that keep their own pose,
   * such as AdvantageKit replay.
   *
   * @param targetPose  Pose to drive towards.
   * @param currentPose Pose the robot is at.
   * @param heading     Heading of the robot, to turn the field relative speeds to robot relative.
   * @return robot-relative {@link ChassisSpeeds} to drive the robot to the given pose.
   * @throws SwerveDriveConfigurationException if the translation or rotation PID controller is not
   *                                           configured.
   */
  public ChassisSpeeds driveToPoseSetpoint(Pose2d targetPose, Pose2d currentPose, Rotation2d heading) {
    var rotationPID = m_config.getRotationPID().orElseThrow(() -> new SwerveDriveConfigurationException("No rotation PID controller configured", "Cannot drive to pose", "withRotationController(PIDController)"));
    var translationPID = m_config.getTranslationPID().orElseThrow(() -> new SwerveDriveConfigurationException("No translation PID controller configured", "Cannot drive to pose", "withTranslationController(PIDController)"));
    var toTarget = targetPose.getTranslation().minus(currentPose.getTranslation());
    var distance = toTarget.getNorm();
    // The controller sees the distance as its measurement with a setpoint of 0, so its output is
    // negative while there is distance left: the speed toward the target is the negative of it.
    var speed = -translationPID.calculate(distance, 0);
    // Drive at that speed along the unit vector toward the target.
    var velocity = distance > 1e-9 ? toTarget.div(distance).times(speed) : new Translation2d();
    return ChassisSpeeds.fromFieldRelativeSpeeds(new ChassisSpeeds(velocity.getX(), velocity.getY(), rotationPID.calculate(currentPose.getRotation().getRadians(), targetPose.getRotation().getRadians())), heading);
  }

  /**
   * Add a vision measurement to the {@link SwerveDrivePoseEstimator} and update the gyro reading
   * with the given timestamp of the vision measurement.
   *
   * @param robotPose                Robot {@link Pose2d} as measured by vision.
   * @param timestamp                Timestamp the measurement was taken as time since startup, should be taken
   *                                 from {@link Timer#getFPGATimestamp()} or similar sources.
   * @param visionMeasurementStdDevs Vision measurement standard deviation that will be sent to the
   *                                 {@link SwerveDrivePoseEstimator}.The standard deviation of the vision measurement, for best
   *                                 accuracy calculate the standard deviation at 2 or more points and fit a line to it with the
   *                                 calculated optimal standard deviation. (Units should be meters per pixel). By optimizing
   *                                 this you can get * vision accurate to inches instead of feet.
   */
  public void addVisionMeasurement(Pose2d robotPose, double timestamp, Matrix<N3, N1> visionMeasurementStdDevs) {
    m_poseEstimator.addVisionMeasurement(robotPose, timestamp, visionMeasurementStdDevs);
  }

  /**
   * Sets the pose estimator's trust of global measurements. This might be used to change trust in
   * vision measurements after the autonomous period, or to change trust as distance to a vision
   * target increases.
   *
   * @param visionMeasurementStdDevs Standard deviations of the vision measurements. Increase these
   *                                 numbers to trust global measurements from vision less. This matrix is in the form [x, y,
   *                                 theta], with units in meters and radians.
   */
  public void setVisionMeasurementStdDevs(Matrix<N3, N1> visionMeasurementStdDevs) {
    m_poseEstimator.setVisionMeasurementStdDevs(visionMeasurementStdDevs);
  }

  /**
   * Add a vision measurement to the {@link SwerveDrivePoseEstimator} and update the gyro reading
   * with the given timestamp of the vision measurement.
   *
   * @param robotPose Robot {@link Pose2d} as measured by vision.
   * @param timestamp Timestamp the measurement was taken as time since startup, should be taken
   *                  from {@link Timer#getFPGATimestamp()} or similar sources.
   */
  public void addVisionMeasurement(Pose2d robotPose, double timestamp) {
    m_poseEstimator.addVisionMeasurement(robotPose, timestamp);
  }

  /**
   * Update the {@link SwerveDrivePoseEstimator} with the current gyro angle and {@link SwerveModulePosition}
   */
  private void updatePoseEstimator() {
    m_poseEstimator.update(getGyroRotation3d().toRotation2d(), getModulePositions());
  }

  /** Update the telemetry and {@link SwerveDrivePoseEstimator} of the drive. */
  public void updateTelemetry() {
    updatePoseEstimator();
    Pose2d robotPose = getPose();
    SwerveModuleState[] currentStates = getModuleStates();

    m_swerveTelemetry.publish(this);

    Arrays.stream(m_modules).forEach(SwerveModule::updateTelemetry);
    m_telemetry.updateLoopTime();

    m_field2d.setRobotPose(robotPose);
    Pose2d[] modulePoses = new Pose2d[m_modules.length];
    for (int i = 0; i < m_modules.length; i++) {
      Translation2d location = m_modules[i].getConfig().getLocation().orElseThrow();
      Translation2d rotated = location.rotateBy(robotPose.getRotation());
      Translation2d moduleTranslation = robotPose.getTranslation().plus(rotated);
      Rotation2d moduleHeading = robotPose.getRotation().plus(currentStates[i].angle);
      modulePoses[i] = new Pose2d(moduleTranslation, moduleHeading);
    }
    m_field2d.getObject("modules").setPoses(modulePoses);
  }

  /** Simulate the drive, updating the gyroscope based off of module states. */
  public void simIterate() {
    // If MapleSim is configured, update it.
    //    if (m_config.getMapleDriveSim().isPresent())
    //    {
    //      m_config.getMapleDriveSim().get().periodic();
    //    }
    if (!m_simTimer.isRunning()) {
      m_simTimer.start();
    }
    Arrays.stream(m_modules).forEach(SwerveModule::simIterate);
    var dt = m_simTimer.get();
    ChassisSpeeds desired = m_kinematics.toChassisSpeeds(m_desiredModuleStates);
    Twist2d twist = new Twist2d(desired.vxMetersPerSecond * dt, desired.vyMetersPerSecond * dt, desired.omegaRadiansPerSecond * dt);
    m_simPose = m_simPose.exp(twist);
    m_simGyroAngle = m_simPose.getRotation().getMeasure();
    m_simTimer.reset();
  }

  /**
   * Get the robot relative speed of the drive.
   *
   * @return Robot relative speed of the drive.
   */
  public ChassisSpeeds getRobotRelativeSpeed() {
    return m_kinematics.toChassisSpeeds(getModuleStates());
  }

  /**
   * Get the field relative speed of the drive.
   *
   * @return Field relative speed of the drive.
   */
  public ChassisSpeeds getFieldRelativeSpeed() {
    return ChassisSpeeds.fromRobotRelativeSpeeds(getRobotRelativeSpeed(), getGyroRotation3d().toRotation2d());
  }

  /**
   * Get the {@link SwerveModulePosition} of the modules.
   *
   * @return {@link SwerveModulePosition} of the modules.
   */
  public SwerveModulePosition[] getModulePositions() {
    // If MapleSim is configured, return the simulated positions.
    //    if (RobotBase.isSimulation() && m_config.getMapleDriveSim().isPresent())
    //    {
    //      return m_config.getMapleDriveSim().get().getLatestModulePositions();
    //    }
    return Arrays.stream(m_modules).map(SwerveModule::getPosition).toArray(SwerveModulePosition[]::new);
  }

  /**
   * Get the {@link SwerveModuleState} of the modules.
   *
   * @return {@link SwerveModuleState} of the modules.
   */
  public SwerveModuleState[] getModuleStates() {
    // If MapleSim is configured, return the simulated states.
    //    if (RobotBase.isSimulation() && m_config.getMapleDriveSim().isPresent())
    //    {
    //      return m_config.getMapleDriveSim().get().getMeasuredStates();
    //    }
    return Arrays.stream(m_modules).map(SwerveModule::getState).toArray(SwerveModuleState[]::new);
  }

  /**
   * Get the {@link SwerveDriveConfig} of the drive.
   *
   * @return {@link SwerveDriveConfig} of the drive.
   */
  public SwerveDriveConfig getConfig() {
    return m_config;
  }

  /**
   * Get the {@link Field2d} used to display the robot's pose, so callers (e.g. vision subsystems)
   * can publish additional {@link edu.wpi.first.wpilibj.smartdashboard.FieldObject2d}s onto the
   * same field widget instead of creating their own.
   *
   * @return {@link Field2d} of the drive.
   */
  public Field2d getField2d() {
    return m_field2d;
  }

  /**
   * Get the last-commanded desired robot-relative {@link ChassisSpeeds} of the drive. This is the
   * value cached by {@link #setRobotRelativeChassisSpeeds(ChassisSpeeds)} (which {@link #setFieldRelativeChassisSpeeds(ChassisSpeeds)} and {@link #drive(java.util.function.Supplier)}
   * funnel through) and published on every {@link #updateTelemetry()} call.
   *
   * @implNote It is a setpoint, not a measurement of actual robot motion. Use {@link #getRobotRelativeSpeed()} or {@link #getFieldRelativeSpeed()} instead if you need the
   *           drive's actual measured speed.
   * @return Robot-relative {@link ChassisSpeeds} last commanded to the drive. Defaults to a zeroed
   *         {@link ChassisSpeeds} if the drive has never been commanded.
   */
  public ChassisSpeeds getDesiredChassisSpeeds() {
    return m_desiredChassisSpeeds;
  }

  /**
   * Get the last-commanded desired {@link SwerveModuleState}s of the drive.
   *
   * @return {@link SwerveModuleState}s last commanded to the drive. Defaults to a zeroed {@link SwerveModuleState}s if the drive has never been commanded.
   */
  public SwerveModuleState[] getDesiredModuleStates() {
    return m_desiredModuleStates;
  }

  /**
   * Get a module by its name.
   *
   * @param moduleName Name of the module.
   * @return {@link SwerveModule} with the given name if it exists.
   */
  public Optional<SwerveModule> getModule(String moduleName) {
    Optional<SwerveModule> module = Optional.empty();
    for (var mod : m_modules) {
      if (mod.getName().equals(moduleName)) {
        module = Optional.of(mod);
        break;
      }
    }
    return module;
  }

  /**
   * Get all {@link SwerveModule}s for this {@link SwerveDrive}.
   *
   * @return Array of {@link SwerveModule}s.
   */
  public SwerveModule[] getModules() {
    return m_modules;
  }
}
