// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.mechanisms.config;

import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.MetersPerSecond;
import static edu.wpi.first.units.Units.Rotations;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.Distance;
import edu.wpi.first.units.measure.LinearVelocity;
import edu.wpi.first.wpilibj.RobotBase;
import java.util.Optional;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import yams.gearing.GearBox;
import yams.gearing.MechanismGearing;
import yams.mechanisms.swerve.SwerveModule;
import yams.motorcontrollers.SmartMotorController;
import yams.motorcontrollers.SmartMotorControllerConfig;
import yams.motorcontrollers.SmartMotorControllerConfig.TelemetryVerbosity;
import yams.telemetry.SwerveModuleTelemetryConfig;

/**
 * Swerve Module
 *
 * <h2>Configuration Example</h2>
 *
 * <p>The following example shows how to build a complete {@link SwerveModuleConfig} for a single
 * swerve module using TalonFX motors and a CANcoder absolute encoder.
 *
 * <pre>{@code
 * import static edu.wpi.first.units.Units.*;
 * import com.ctre.phoenix6.hardware.TalonFX;
 * import com.ctre.phoenix6.hardware.CANcoder;
 * import edu.wpi.first.math.system.plant.DCMotor;
 * import yams.motorcontrollers.SmartMotorControllerConfig;
 * import yams.motorcontrollers.SmartMotorControllerConfig.ControlMode;
 * import yams.motorcontrollers.SmartMotorController;
 * import yams.motorcontrollers.remote.TalonFXWrapper;
 * import yams.mechanisms.config.SwerveModuleConfig;
 * import yams.gearing.GearBox;
 *
 * // Drive motor: velocity closed-loop control (e.g. L2 Falcon gearing 6.75:1)
 * SmartMotorControllerConfig driveConfig = new SmartMotorControllerConfig()
 *     .withMotorInverted(false)
 *     .withStatorCurrentLimit(Amps.of(50))
 *     .withGearing(new GearBox(new double[]{6.75}))
 *     .withClosedLoopController(0.05, 0.0, 0.001)
 *     .withControlMode(ControlMode.CLOSED_LOOP);
 *
 * // Steer (azimuth) motor: position closed-loop control (e.g. 12.8:1 reduction)
 * SmartMotorControllerConfig steerConfig = new SmartMotorControllerConfig()
 *     .withMotorInverted(true)
 *     .withStatorCurrentLimit(Amps.of(30))
 *     .withGearing(new GearBox(new double[]{12.8}))
 *     .withContinuousWrapping(Rotations.of(-0.5), Rotations.of(0.5))
 *     .withClosedLoopController(5.0, 0.0, 0.1)
 *     .withControlMode(ControlMode.CLOSED_LOOP);
 *
 * // Create motor controller instances directly
 * SmartMotorController driveMotor = new TalonFXWrapper(new TalonFX(1), DCMotor.getKrakenX60(1), driveConfig);
 * SmartMotorController steerMotor = new TalonFXWrapper(new TalonFX(2), DCMotor.getFalcon500(1), steerConfig);
 *
 * // Assemble the module config (front-left corner, 0.2 m from centre each axis)
 * CANcoder cancoder = new CANcoder(10);
 * SwerveModuleConfig frontLeftConfig = new SwerveModuleConfig(driveMotor, steerMotor)
 *     .withWheelRadius(Inches.of(2))
 *     .withLocation(Meters.of(0.2), Meters.of(0.2))     // front, left
 *     .withAbsoluteEncoder(cancoder)
 *     .withAbsoluteEncoderOffset(Rotations.of(0.25))    // bevel-left zero offset
 *     .withCosineCompensation(true)
 *     .withOptimization(true)
 *     .withTelemetry("FrontLeft", TelemetryVerbosity.HIGH);
 * }</pre>
 */
public class SwerveModuleConfig {
  /** {@link SmartMotorController} for the {@link SwerveModule} */
  private Optional<SmartMotorController> driveMotor = Optional.empty();

  /** {@link SmartMotorController} for the {@link SwerveModule} */
  private Optional<SmartMotorController> azimuthMotor = Optional.empty();

  /** Telemetry name. */
  private Optional<String> telemetryName = Optional.empty();

  /** Telemetry verbosity */
  private Optional<TelemetryVerbosity> telemetryVerbosity = Optional.empty();

  /**
   * User specified {@link SwerveModuleTelemetryConfig}, takes precedence over {@link #telemetryVerbosity} if present.
   */
  private Optional<SwerveModuleTelemetryConfig> specifiedTelemetryConfig = Optional.empty();

  /** Absolute encoder supplier for the azimuth {@link SmartMotorController}. */
  private Optional<Supplier<Angle>> absoluteEncoderSupplier = Optional.empty();

  /**
   * Absolute encoder offset for the azimuth {@link SmartMotorController} to 0 with the bevel facing
   * left.
   */
  private Optional<Angle> absoluteEncoderOffset = Optional.empty();

  /** Gearbox for the absolute encoder. */
  private GearBox absoluteEncoderGearbox = new GearBox(new double[] {
                                                                     1});

  /**
   * Swerve module state optimization using {@link edu.wpi.first.math.kinematics.SwerveModuleState#optimize(Rotation2d)}.
   */
  private boolean swerveModuleStateOptimization = true;

  /** Swerve module cosine compensation. */
  private boolean cosineCompensation = false;

  /** Coupling ratio for the {@link SwerveModule}, see {@link #withCouplingRatio(GearBox)}. */
  private Optional<GearBox> couplingRatio = Optional.empty();

  /** Velocity deadband, see {@link #withVelocityDeadband(LinearVelocity)}. */
  private Optional<LinearVelocity> velocityDeadband = Optional.of(MetersPerSecond.of(0.1));

  /** Distance from the center of rotation for the {@link SwerveModule}. */
  private Optional<Translation2d> distanceFromCenterOfRotation = Optional.empty();

  /**
   * Absolute encoder for the azimuth {@link SmartMotorController}, must be of the same vendor as
   * the azimuth motor.
   */
  private Optional<Object> absoluteEncoder = Optional.empty();

  /** Wheel circumference for the drive {@link SmartMotorController}. */
  private Optional<Distance> wheelCircumference = Optional.empty();

  /**
   * Last angle this config actually commanded via {@link #getOptimizedState(SwerveModuleState)}.
   * The flip decision is made against this, not the live absolute encoder reading: kinematics
   * recomputes the raw desired angle every loop with no memory of a prior flip, so if the decision
   * were re-derived from the encoder, holding the raw state while a flip is debouncing would drive
   * the wheel toward the raw angle, pulling the encoder (and thus the error that triggered the
   * flip) back down before the debounce could ever confirm it.
   */
  private Rotation2d lastCommandedAngle;

  /**
   * Create the {@link SwerveModuleConfig} for the {@link SwerveModule}
   *
   * @param drive   Drive motor controller.
   * @param azimuth Azimuth motor controller.
   */
  public SwerveModuleConfig(SmartMotorController drive, SmartMotorController azimuth) {
    this.driveMotor = Optional.ofNullable(drive);
    this.azimuthMotor = Optional.ofNullable(azimuth);
  }

  /**
   * Create the {@link SwerveModuleConfig} for the {@link SwerveModule}
   *
   * @implNote Required to use {@link #withSmartMotorController(SmartMotorController, SmartMotorController)} BEFORE passed into {@link SwerveModule}
   */
  public SwerveModuleConfig() {
  }

  /**
   * Copy constructor.
   *
   * @param cfg Config to copy.
   */
  private SwerveModuleConfig(SwerveModuleConfig cfg) {
    this.driveMotor = cfg.driveMotor;
    this.azimuthMotor = cfg.azimuthMotor;
    this.telemetryName = cfg.telemetryName;
    this.telemetryVerbosity = cfg.telemetryVerbosity;
    this.specifiedTelemetryConfig = cfg.specifiedTelemetryConfig;
    this.absoluteEncoderSupplier = cfg.absoluteEncoderSupplier;
    this.absoluteEncoderOffset = cfg.absoluteEncoderOffset;
    this.absoluteEncoderGearbox = cfg.absoluteEncoderGearbox;
    this.swerveModuleStateOptimization = cfg.swerveModuleStateOptimization;
    this.cosineCompensation = cfg.cosineCompensation;
    this.couplingRatio = cfg.couplingRatio;
    this.velocityDeadband = cfg.velocityDeadband;
    this.distanceFromCenterOfRotation = cfg.distanceFromCenterOfRotation;
    this.absoluteEncoder = cfg.absoluteEncoder;
    this.wheelCircumference = cfg.wheelCircumference;
  }

  @Override
  public SwerveModuleConfig clone() {
    return new SwerveModuleConfig(this);
  }

  /**
   * Set the {@link SmartMotorController} for the {@link SwerveModule}.
   *
   * @param driveMotor   {@link SmartMotorController} for the drive motor.
   * @param azimuthMotor {@link SmartMotorController} for the azimuth motor.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withSmartMotorController(SmartMotorController driveMotor, SmartMotorController azimuthMotor) {
    if (this.driveMotor.isPresent()) {
      throw new IllegalStateException("Drive motor controller already set.");
    }
    if (this.azimuthMotor.isPresent()) {
      throw new IllegalStateException("Azimuth motor controller already set.");
    }
    this.driveMotor = Optional.of(driveMotor);
    this.azimuthMotor = Optional.of(azimuthMotor);
    absoluteEncoder.ifPresent(this::withAbsoluteEncoder);
    wheelCircumference.ifPresent(circumference -> driveMotor.getConfig().withMechanismCircumference(circumference));
    return this;
  }

  /**
   * Cosine compensation for the {@link SwerveModule}, adjusting the velocity by the cosine of the
   * (current_angle-desired_angle).
   *
   * @param compensate Enable or disable cosine compensation.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withCosineCompensation(boolean compensate) {
    this.cosineCompensation = compensate;
    return this;
  }

  // TODO: Add coupling ratio

  /**
   * Set the absolute encoder for the azimuth {@link SmartMotorController} if it's the SAME VENDOR,
   * only.
   *
   * @param absoluteEncoder Same vendor, absolute encoder for the {@link SmartMotorController}
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoder(Object absoluteEncoder) {
    this.absoluteEncoder = Optional.ofNullable(absoluteEncoder);
    this.absoluteEncoderSupplier = Optional.empty();
    azimuthMotor.ifPresent(azimuthMotor -> azimuthMotor.getConfig().withExternalEncoder(absoluteEncoder));
    return this;
  }

  /**
   * Set the distance from the center of rotation for the {@link SwerveModule}.
   *
   * @param front Distance from the front of the robot, will be converted to Meters. (The X
   *              location)
   * @param left  Distance from the left of the robot, will be converted to Meters. (The Y location)
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withDistanceFromCenterOfRotation(Distance front, Distance left) {
    distanceFromCenterOfRotation = Optional.of(new Translation2d(front, left));
    return this;
  }

  /**
   * Set the location for the {@link SwerveModule} in Meters from the center of rotation.
   *
   * @param location Location of the {@link SwerveModule} in meters from the center of rotation.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withLocation(Translation2d location) {
    distanceFromCenterOfRotation = Optional.of(location);
    return this;
  }

  /**
   * Set the distance from the center of rotation for the {@link SwerveModule}.
   *
   * @param front Distance from the front of the robot, will be converted to meters. (The X
   *              location)
   * @param left  Distance from the left of the robot, will be converted to meters. (The Y location)
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withLocation(Distance front, Distance left) {
    return withDistanceFromCenterOfRotation(front, left);
  }

  /**
   * Set the location for the {@link SwerveModule} using polar coordinates.
   *
   * @param distance Distance from the center of rotation will be converted to meters.
   * @param angle    Angle from the center of rotation.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withLocation(Distance distance, Angle angle) {
    distanceFromCenterOfRotation = Optional.of(new Translation2d(distance.in(Meters), new Rotation2d(angle)));
    return this;
  }

  /**
   * Supply a non-alike vendor absolute encoder for the azimuth {@link SmartMotorController}.
   *
   * @param locationProvider Provides the Rotation for the azimuth {@link SmartMotorController}.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoder(Supplier<Angle> locationProvider) {
    absoluteEncoderSupplier = Optional.ofNullable(locationProvider);
    return this;
  }

  /**
   * Supply a non-alike vendor absolute encoder for the azimuth {@link SmartMotorController}.
   *
   * @param rotationSupplier Provides the Rotation for the azimuth {@link SmartMotorController}.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoder(DoubleSupplier rotationSupplier) {
    if (rotationSupplier != null) {
      return withAbsoluteEncoder(() -> Rotations.of(rotationSupplier.getAsDouble()));
    }
    return this;
  }

  /**
   * Set the gearing of the absolute encoder if it's not 1:1.
   *
   * @param gearing {@link GearBox} for the absolute encoder to get the azimuth angle.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoderGearing(GearBox gearing) {
    absoluteEncoderGearbox = gearing;
    if (azimuthMotor.isPresent()) {
      SmartMotorControllerConfig azimuthConfig = azimuthMotor.orElseThrow().getConfig();
      if (azimuthConfig.getExternalEncoder().isPresent()) {
        azimuthConfig.withExternalEncoderGearing(new MechanismGearing(gearing));
      }
    }
    return this;
  }

  /**
   * Set the absolute encoder offset for the azimuth {@link SmartMotorController} so that the
   * absolute encoder reads 0 while the wheel is facing forwards and bevel to the left.
   *
   * @param offset Offset for the absolute encoder.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoderOffset(Angle offset) {
    absoluteEncoderOffset = Optional.ofNullable(offset);

    if (azimuthMotor.isPresent()) {
      SmartMotorControllerConfig azimuthConfig = azimuthMotor.orElseThrow().getConfig();
      if (azimuthConfig.getExternalEncoder().isPresent()) {
        azimuthConfig.withExternalEncoderZeroOffset(offset);
      }
    }
    return this;
  }

  /**
   * Set the wheel radius for the {@link SmartMotorController}, ideally should be set inside the
   * drive motor {@link SmartMotorControllerConfig}
   *
   * @param radius Radius of the wheel.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withWheelRadius(Distance radius) {
    wheelCircumference = Optional.ofNullable(radius.times(2.0).times(Math.PI));
    driveMotor.ifPresent(driveMotor -> driveMotor.getConfig().withMechanismCircumference(radius.times(2.0).times(Math.PI)));
    return this;
  }

  /**
   * Set the wheel diameter for the {@link SmartMotorController}, ideally should be set inside the
   * drive motor {@link SmartMotorControllerConfig}.
   *
   * @param diameter Diameter of the wheel.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withWheelDiameter(Distance diameter) {
    wheelCircumference = Optional.ofNullable(diameter.times(Math.PI));
    driveMotor.ifPresent(driveMotor -> driveMotor.getConfig().withMechanismCircumference(diameter.times(Math.PI)));
    return this;
  }

  /**
   * Set the velocity deadband: a wheel commanded at or below this speed is held where it is, at zero
   * speed, instead of being turned to an angle it is too slow to steer by. This keeps the wheels
   * from snapping back to forward when the driver lets go of the sticks. 0.1 m/s by default.
   *
   * @param speed Speed at or below which the wheel is held where it is, or null for no deadband.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withVelocityDeadband(LinearVelocity speed) {
    velocityDeadband = Optional.ofNullable(speed);
    return this;
  }

  /**
   * Get the velocity deadband.
   *
   * @return Speed at or below which the wheel is held where it is, empty when there is no deadband.
   */
  public Optional<LinearVelocity> getVelocityDeadband() {
    return velocityDeadband;
  }

  /**
   * Set the coupling between the azimuth and the drive: on most modules turning the azimuth also
   * turns the wheel a little, because the drive gearing rides on the azimuth. With the ratio set,
   * the module takes that out of the drive velocity and distance it reports, and adds it to the
   * drive velocity it commands, so turning the wheels does not read as driving.
   *
   * @param couplingRatio {@link GearBox} from azimuth rotations to drive motor rotations, or null
   *                      for no coupling.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withCouplingRatio(GearBox couplingRatio) {
    this.couplingRatio = Optional.ofNullable(couplingRatio);
    return this;
  }

  /**
   * Set the coupling between the azimuth and the drive, see {@link #withCouplingRatio(GearBox)}.
   *
   * @param driveMotorRotationsPerAzimuthRotation How many rotations the drive motor makes for one
   *                                              rotation of the azimuth with the wheel held still.
   *                                              0 for no coupling.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withCouplingRatio(double driveMotorRotationsPerAzimuthRotation) {
    if (driveMotorRotationsPerAzimuthRotation == 0) {
      this.couplingRatio = Optional.empty();
      return this;
    }
    return withCouplingRatio(GearBox.fromReductionStages(driveMotorRotationsPerAzimuthRotation));
  }

  /**
   * Get the coupling between the azimuth and the drive.
   *
   * @return Empty when no coupling ratio is set.
   */
  public Optional<GearBox> getCouplingRatio() {
    return couplingRatio;
  }

  /**
   * Use {@link edu.wpi.first.math.kinematics.SwerveModuleState#optimize(Rotation2d)} to optimize
   * each state.
   *
   * @param swerveModuleStateOptimization True to enable optimization, false otherwise.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withOptimization(boolean swerveModuleStateOptimization) {
    this.swerveModuleStateOptimization = swerveModuleStateOptimization;
    return this;
  }

  /**
   * Configure telemetry for the {@link SwerveModule} mechanism.
   *
   * @param telemetryName      Telemetry NetworkTable name to appear under "SmartDashboard/"
   * @param telemetryVerbosity Telemetry verbosity to apply.
   * @return {@link ArmConfig} for chaining.
   */
  public SwerveModuleConfig withTelemetry(String telemetryName, TelemetryVerbosity telemetryVerbosity) {
    this.telemetryName = Optional.ofNullable(telemetryName);
    this.telemetryVerbosity = Optional.ofNullable(telemetryVerbosity);
    return this;
  }

  /**
   * Configure telemetry for the {@link SwerveModule} mechanism with a {@link SwerveModuleTelemetryConfig}.
   *
   * @param telemetryName   Telemetry NetworkTable name to appear under "SmartDashboard/"
   * @param telemetryConfig Config that specifies what to log.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withTelemetry(String telemetryName, SwerveModuleTelemetryConfig telemetryConfig) {
    this.telemetryName = Optional.ofNullable(telemetryName);
    this.telemetryVerbosity = Optional.of(TelemetryVerbosity.HIGH);
    this.specifiedTelemetryConfig = Optional.ofNullable(telemetryConfig);
    return this;
  }

  /**
   * Get the user specified {@link SwerveModuleTelemetryConfig}, if configured via {@link #withTelemetry(String, SwerveModuleTelemetryConfig)}.
   *
   * @return {@link SwerveModuleTelemetryConfig} if configured.
   */
  public Optional<SwerveModuleTelemetryConfig> getSwerveModuleTelemetryConfig() {
    return specifiedTelemetryConfig;
  }

  /**
   * Get the absolute encoder angle for the azimuth {@link SmartMotorController}.
   *
   * @return Absolute encoder {@link Angle}.
   */
  public Angle getAbsoluteEncoderAngle() {
    return absoluteEncoderSupplier.map(angleSupplier -> angleSupplier.get().times(absoluteEncoderGearbox.getInputToOutputConversionFactor()).minus(absoluteEncoderOffset.orElse(Rotations.of(0)))).orElse(azimuthMotor.orElseThrow()
        .getMechanismPosition());
  }

  /**
   * Get the absolute encoder angle as a supplier without offsets applied.
   *
   * @return {@link Supplier<Angle>} for the absolute encoder angle without offsets.
   */
  public Supplier<Angle> getRawAbsoluteEncoderAngle() {
    if (absoluteEncoderSupplier.isPresent()) {
      return absoluteEncoderSupplier.get();
    } else {
      var offset = RobotBase.isSimulation() ? Rotations.zero() : azimuthMotor.orElseThrow().getConfig().getExternalEncoderZeroOffset().orElse(Rotations.zero());
      return () -> azimuthMotor.orElseThrow().getMechanismPosition().plus(offset);
    }
  }

  /**
   * Get the absolute encoder supplier
   *
   * @return Absolute encoder supplier.
   */
  public Optional<Supplier<Angle>> getAbsoluteEncoderSupplier() {
    return absoluteEncoderSupplier;
  }

  /**
   * Enable or disable state optimization.
   *
   * @return True if optimization is enabled, false otherwise.
   */
  public boolean getStateOptimization() {
    return swerveModuleStateOptimization;
  }

  /**
   * Get the drive {@link SmartMotorController} for the {@link SwerveModule}.
   *
   * @return {@link SmartMotorController} for the drive motor.
   */
  public SmartMotorController getDriveMotor() {
    return driveMotor.orElseThrow();
  }

  /**
   * Get the azimuth {@link SmartMotorController} for the {@link SwerveModule}.
   *
   * @return {@link SmartMotorController} for the azimuth motor.
   */
  public SmartMotorController getAzimuthMotor() {
    return azimuthMotor.orElseThrow();
  }

  /**
   * Get the cosine-compensated velocity to set the swerve module to.
   *
   * @param desiredState Desired {@link SwerveModuleState} to use.
   * @param currentAngle Current azimuth angle to compare against, read once per control cycle so it
   *                     stays consistent with whatever value was used earlier in that cycle (e.g. for
   *                     optimization).
   * @return Cosine compensated velocity in meters/second.
   */
  private double getCosineCompensatedVelocity(SwerveModuleState desiredState, Rotation2d currentAngle) {
    // Taken from the CTRE SwerveModule class.
    // https://api.ctr-electronics.com/phoenix6/release/java/src-html/com/ctre/phoenix6/mechanisms/swerve/SwerveModule.html#line.46
    /* From FRC 900's whitepaper, we add a cosine compensator to the applied drive velocity */
    /* To reduce the "skew" that occurs when changing direction */
    /* If error is close to 0 rotations, we're already there, so apply full power */
    /* If the error is close to 0.25 rotations, then we're 90 degrees, so movement doesn't help us at all */
    return desiredState.speedMetersPerSecond * getCosineScalar(desiredState.angle, currentAngle);
  }

  /**
   * How much of the commanded drive output to apply while the wheel is {@code currentAngle} away
   * from {@code desiredAngle}: all of it when aligned, none of it at 90 degrees or more.
   *
   * @param desiredAngle Angle the wheel is commanded to.
   * @param currentAngle Angle the wheel is at.
   * @return Scalar in [0, 1].
   */
  private static double getCosineScalar(Rotation2d desiredAngle, Rotation2d currentAngle) {
    // Optimization keeps the wheel within 90 degrees of its target except while it holds the
    // orientation it was last sent to (see optimize), where the wheel is still turning toward it
    // and driving would push the robot the wrong way.
    return Math.max(desiredAngle.minus(currentAngle).getCos(), 0.0);
  }

  /**
   * Get the scalar cosine compensation applies to the drive output for a wheel commanded to the
   * given angle, so that a feedforward given alongside the velocity can be scaled the same way.
   *
   * @param desiredAngle Angle the wheel is commanded to, after optimization.
   * @return Scalar in [0, 1]; 1 when cosine compensation is disabled.
   */
  public double getCosineCompensationScalar(Rotation2d desiredAngle) {
    if (!cosineCompensation) {
      return 1.0;
    }
    return getCosineScalar(desiredAngle, new Rotation2d(azimuthMotor.orElseThrow().getMechanismPosition()));
  }

  /**
   * Optimize a module state like {@link SwerveModuleState#optimize(Rotation2d)}, keeping the
   * orientation the wheel was last sent to unless the other is better by more than 30 degrees. A
   * wheel still turning can be near 90 degrees from both orientations of a target that keeps
   * moving, such as a path starting off in a new direction; choosing by its angle alone would
   * reverse it back and forth.
   *
   * @param desired       Module state to optimize.
   * @param currentAngle  Angle the wheel is at.
   * @param lastCommanded Angle the wheel was last sent to, or null if it has not been sent anywhere.
   * @return The optimized module state.
   */
  private static SwerveModuleState optimize(SwerveModuleState desired, Rotation2d currentAngle, Rotation2d lastCommanded) {
    final SwerveModuleState state = new SwerveModuleState(desired.speedMetersPerSecond, desired.angle);
    state.optimize(currentAngle);
    if (lastCommanded == null || Math.abs(state.angle.minus(lastCommanded).getDegrees()) <= 90) {
      return state;
    }
    final SwerveModuleState lastOrientation = new SwerveModuleState(-state.speedMetersPerSecond, state.angle.rotateBy(Rotation2d.kPi));
    return Math.abs(lastOrientation.angle.minus(currentAngle).getDegrees()) < 90 + 30 ? lastOrientation : state;
  }

  /**
   * Get the optimized {@link SwerveModuleState} applying all optional optimizations.
   *
   * @param state {@link SwerveModuleState} to optimize.
   * @return {@link SwerveModuleState} optimized.
   */
  public SwerveModuleState getOptimizedState(SwerveModuleState state) {
    // Use the angle the azimuth controller is closing the loop on (seeded from the absolute encoder) so optimization,
    // cosine compensation, and the azimuth setpoint all agree on where the module is pointing.
    Rotation2d currentAngle = new Rotation2d(azimuthMotor.map(SmartMotorController::getMechanismPosition)
                                                         .orElseGet(this::getAbsoluteEncoderAngle));
    if (velocityDeadband.isPresent() && MetersPerSecond.of(Math.abs(state.speedMetersPerSecond)).lte(velocityDeadband.get())) {
      // Too slow to steer by: hold the wheel where it is.
      state = new SwerveModuleState(0, currentAngle);
      lastCommandedAngle = currentAngle;
    } else if (swerveModuleStateOptimization) {
      state = optimize(state, currentAngle, lastCommandedAngle);
      lastCommandedAngle = state.angle;
    }
    if (cosineCompensation) {
      state.speedMetersPerSecond = getCosineCompensatedVelocity(state, currentAngle);
    }
    return state;
  }

  /**
   * Get the state that turns the wheel to {@code angle} without driving it, as for locking the
   * drive in place. Unlike {@link #getOptimizedState(SwerveModuleState)}, the velocity deadband
   * does not hold the wheel where it is, since the wheel is meant to turn without driving. With
   * optimization enabled the wheel turns to whichever of {@code angle} and its opposite is nearer,
   * as either holds the drive the same way.
   *
   * @param angle Angle to turn the wheel to.
   * @return Zero speed {@link SwerveModuleState} at the angle to turn the wheel to.
   */
  public SwerveModuleState getLockedState(Rotation2d angle) {
    SwerveModuleState state = new SwerveModuleState(0, angle);
    if (swerveModuleStateOptimization) {
      Rotation2d currentAngle = new Rotation2d(azimuthMotor.map(SmartMotorController::getMechanismPosition)
                                                           .orElseGet(this::getAbsoluteEncoderAngle));
      state = optimize(state, currentAngle, lastCommandedAngle);
    }
    lastCommandedAngle = state.angle;
    return state;
  }

  /**
   * Get the telemetry name for the {@link SwerveModule}.
   *
   * @return Telemetry name for the {@link SwerveModule}.
   */
  public Optional<String> getTelemetryName() {
    return telemetryName;
  }

  /**
   * Get the telemetry verbosity for the {@link SwerveModule}.
   *
   * @return {@link TelemetryVerbosity} for the {@link SwerveModule}.
   */
  public Optional<TelemetryVerbosity> getTelemetryVerbosity() {
    return telemetryVerbosity;
  }

  /**
   * Get the location of the {@link SwerveModule} in meters from the center of rotation.
   *
   * @return {@link Translation2d} of the {@link SwerveModule}
   */
  public Optional<Translation2d> getLocation() {
    return distanceFromCenterOfRotation;
  }
}
