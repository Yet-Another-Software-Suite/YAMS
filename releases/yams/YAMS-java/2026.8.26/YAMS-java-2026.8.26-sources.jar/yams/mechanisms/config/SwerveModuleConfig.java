// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.mechanisms.config;

import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.MetersPerSecond;
import static edu.wpi.first.units.Units.Rotations;

import edu.wpi.first.math.filter.Debouncer;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.Distance;
import edu.wpi.first.units.measure.LinearVelocity;
import java.util.Optional;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;

import edu.wpi.first.wpilibj.RobotBase;
import yams.gearing.GearBox;
import yams.gearing.MechanismGearing;
import yams.mechanisms.swerve.SwerveModule;
import yams.motorcontrollers.SmartMotorController;
import yams.motorcontrollers.SmartMotorControllerConfig;
import yams.motorcontrollers.SmartMotorControllerConfig.TelemetryVerbosity;

/**
 * Swerve Module
 *
 * <h2>Configuration Example</h2>
 * <p>
 * The following example shows how to build a complete {@link SwerveModuleConfig} for a single
 * swerve module using TalonFX motors and a CANcoder absolute encoder.
 * </p>
 * <pre>{@code
 * import static edu.wpi.first.units.Units.*;
 * import com.ctre.phoenix6.hardware.TalonFX;
 * import com.ctre.phoenix6.hardware.CANcoder;
 * import edu.wpi.first.math.system.plant.DCMotor;
 * import yams.motorcontrollers.SmartMotorControllerConfig;
 * import yams.motorcontrollers.SmartMotorControllerConfig.ControlMode;
 * import yams.motorcontrollers.SmartMotorController;
 * import yams.motorcontrollers.remote.TalonFXWrapper;
 * import yams.mechanisms.config.SwerveModuleConfig;
 * import yams.gearing.GearBox;
 *
 * // Drive motor: velocity closed-loop control (e.g. L2 Falcon gearing 6.75:1)
 * SmartMotorControllerConfig driveConfig = new SmartMotorControllerConfig()
 *     .withMotorInverted(false)
 *     .withStatorCurrentLimit(Amps.of(50))
 *     .withGearing(new GearBox(new double[]{6.75}))
 *     .withClosedLoopController(0.05, 0.0, 0.001)
 *     .withControlMode(ControlMode.CLOSED_LOOP);
 *
 * // Steer (azimuth) motor: position closed-loop control (e.g. 12.8:1 reduction)
 * SmartMotorControllerConfig steerConfig = new SmartMotorControllerConfig()
 *     .withMotorInverted(true)
 *     .withStatorCurrentLimit(Amps.of(30))
 *     .withGearing(new GearBox(new double[]{12.8}))
 *     .withContinuousWrapping(Rotations.of(-0.5), Rotations.of(0.5))
 *     .withClosedLoopController(5.0, 0.0, 0.1)
 *     .withControlMode(ControlMode.CLOSED_LOOP);
 *
 * // Create motor controller instances directly
 * SmartMotorController driveMotor = new TalonFXWrapper(new TalonFX(1), DCMotor.getKrakenX60(1), driveConfig);
 * SmartMotorController steerMotor = new TalonFXWrapper(new TalonFX(2), DCMotor.getFalcon500(1), steerConfig);
 *
 * // Assemble the module config (front-left corner, 0.2 m from centre each axis)
 * CANcoder cancoder = new CANcoder(10);
 * SwerveModuleConfig frontLeftConfig = new SwerveModuleConfig(driveMotor, steerMotor)
 *     .withWheelRadius(Inches.of(2))
 *     .withLocation(Meters.of(0.2), Meters.of(0.2))     // front, left
 *     .withAbsoluteEncoder(cancoder)
 *     .withAbsoluteEncoderOffset(Rotations.of(0.25))    // bevel-left zero offset
 *     .withCosineCompensation(true)
 *     .withOptimization(true)
 *     .withTelemetry("FrontLeft", TelemetryVerbosity.HIGH);
 * }</pre>
 **/
public class SwerveModuleConfig
{
  /**
   * {@link SmartMotorController} for the {@link SwerveModule}
   */
  private Optional<SmartMotorController> driveMotor   = Optional.empty();
  /**
   * {@link SmartMotorController} for the {@link SwerveModule}
   */
  private Optional<SmartMotorController> azimuthMotor = Optional.empty();
  /**
   * Telemetry name.
   */
  private Optional<String>               telemetryName                 = Optional.empty();
  /**
   * Telemetry verbosity
   */
  private Optional<TelemetryVerbosity>   telemetryVerbosity            = Optional.empty();
  /**
   * DataLog entry name prefix for this module's telemetry (currently just the absolute encoder field).
   */
  private Optional<String>               dataLogName                   = Optional.empty();
  /**
   * Absolute encoder supplier for the azimuth {@link SmartMotorController}.
   */
  private Optional<Supplier<Angle>>      absoluteEncoderSupplier       = Optional.empty();
  /**
   * Absolute encoder offset for the azimuth {@link SmartMotorController} to 0 with the bevel facing left.
   */
  private Optional<Angle>                absoluteEncoderOffset         = Optional.empty();
  /**
   * Gearbox for the absolute encoder.
   */
  private GearBox                        absoluteEncoderGearbox        = new GearBox(new double[]{1});
  /**
   * Swerve module state optimization using
   * {@link edu.wpi.first.math.kinematics.SwerveModuleState#optimize(Rotation2d)}.
   */
  private boolean                        swerveModuleStateOptimization = true;
  /**
   * Swerve module cosine compensation.
   */
  private boolean                        cosineCompensation            = false;
  /**
   * Coupling ratio for the {@link SwerveModule}.
   */
  private GearBox                        couplingRatio;
  /**
   * Swerve module minimum velocity.
   */
  private Optional<LinearVelocity>       minimumVelocity               = Optional.empty();
  /**
   * Distance from the center of rotation for the {@link SwerveModule}.
   */
  private Optional<Translation2d>        distanceFromCenterOfRotation  = Optional.empty();
  /**
   * Absolute encoder for the azimuth {@link SmartMotorController}, must be of the same vendor as the azimuth motor.
   */
  private Optional<Object> absoluteEncoder = Optional.empty();
  /**
   * Wheel circumference for the drive {@link SmartMotorController}.
   */
  private Optional<Distance> wheelCircumference = Optional.empty();
  /**
   * Last angle this config actually commanded via {@link #getOptimizedState(SwerveModuleState)}.
   * The flip decision is made against this, not the live absolute encoder reading: kinematics
   * recomputes the raw desired angle every loop with no memory of a prior flip, so if the
   * decision were re-derived from the encoder, holding the raw state while a flip is debouncing
   * would drive the wheel toward the raw angle, pulling the encoder (and thus the error that
   * triggered the flip) back down before the debounce could ever confirm it.
   */
  private Rotation2d lastCommandedAngle;

  /**
   * Create the {@link SwerveModuleConfig} for the {@link SwerveModule}
   *
   * @param drive   Drive motor controller.
   * @param azimuth Azimuth motor controller.
   */
  public SwerveModuleConfig(SmartMotorController drive, SmartMotorController azimuth)
  {
    this.driveMotor = Optional.ofNullable(drive);
    this.azimuthMotor = Optional.ofNullable(azimuth);
  }

  /**
   * Create the {@link SwerveModuleConfig} for the {@link SwerveModule}
   *
   * @implNote Required to use {@link #withSmartMotorController(SmartMotorController, SmartMotorController)} BEFORE
   * passed into {@link SwerveModule}
   */
  public SwerveModuleConfig() {}

  /**
   * Copy constructor.
   *
   * @param cfg Config to copy.
   */
  private SwerveModuleConfig(SwerveModuleConfig cfg)
  {
    this.driveMotor = cfg.driveMotor;
    this.azimuthMotor = cfg.azimuthMotor;
    this.telemetryName = cfg.telemetryName;
    this.telemetryVerbosity = cfg.telemetryVerbosity;
    this.dataLogName = cfg.dataLogName;
    this.absoluteEncoderSupplier = cfg.absoluteEncoderSupplier;
    this.absoluteEncoderOffset = cfg.absoluteEncoderOffset;
    this.absoluteEncoderGearbox = cfg.absoluteEncoderGearbox;
    this.swerveModuleStateOptimization = cfg.swerveModuleStateOptimization;
    this.cosineCompensation = cfg.cosineCompensation;
    this.couplingRatio = cfg.couplingRatio;
    this.minimumVelocity = cfg.minimumVelocity;
    this.distanceFromCenterOfRotation = cfg.distanceFromCenterOfRotation;
    this.absoluteEncoder = cfg.absoluteEncoder;
    this.wheelCircumference = cfg.wheelCircumference;
  }

  @Override
  public SwerveModuleConfig clone()
  {
    return new SwerveModuleConfig(this);
  }

  /**
   * Set the {@link SmartMotorController} for the {@link SwerveModule}.
   *
   * @param driveMotor   {@link SmartMotorController} for the drive motor.
   * @param azimuthMotor {@link SmartMotorController} for the azimuth motor.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withSmartMotorController(SmartMotorController driveMotor, SmartMotorController azimuthMotor)
  {
    if (this.driveMotor.isPresent())
    {throw new IllegalStateException("Drive motor controller already set.");}
    if (this.azimuthMotor.isPresent())
    {throw new IllegalStateException("Azimuth motor controller already set.");}
    this.driveMotor = Optional.of(driveMotor);
    this.azimuthMotor = Optional.of(azimuthMotor);
    absoluteEncoder.ifPresent(this::withAbsoluteEncoder);
    wheelCircumference.ifPresent(circumference -> driveMotor.getConfig().withMechanismCircumference(circumference));
    return this;
  }

  /**
   * Cosine compensation for the {@link SwerveModule}, adjusting the velocity by the cosine of
   * the (current_angle-desired_angle).
   *
   * @param compensate Enable or disable cosine compensation.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withCosineCompensation(boolean compensate)
  {
    this.cosineCompensation = compensate;
    return this;
  }
  // TODO: Add coupling ratio

  /**
   * Set the absolute encoder for the azimuth {@link SmartMotorController} if it's the SAME VENDOR, only.
   *
   * @param absoluteEncoder Same vendor, absolute encoder for the {@link SmartMotorController}
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoder(Object absoluteEncoder)
  {
    this.absoluteEncoder = Optional.ofNullable(absoluteEncoder);
    azimuthMotor.ifPresent(azimuthMotor -> azimuthMotor.getConfig().withExternalEncoder(absoluteEncoder));
    return this;
  }

  /**
   * Set the distance from the center of rotation for the {@link SwerveModule}.
   *
   * @param front Distance from the front of the robot, will be converted to Meters. (The X location)
   * @param left  Distance from the left of the robot, will be converted to Meters. (The Y location)
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withDistanceFromCenterOfRotation(Distance front, Distance left)
  {
    distanceFromCenterOfRotation = Optional.of(new Translation2d(front, left));
    return this;
  }


  /**
   * Set the location for the {@link SwerveModule} in Meters from the center of rotation.
   *
   * @param location Location of the {@link SwerveModule} in meters from the center of rotation.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withLocation(Translation2d location)
  {
    distanceFromCenterOfRotation = Optional.of(location);
    return this;
  }

  /**
   * Set the distance from the center of rotation for the {@link SwerveModule}.
   *
   * @param front Distance from the front of the robot, will be converted to meters. (The X location)
   * @param left  Distance from the left of the robot, will be converted to meters. (The Y location)
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withLocation(Distance front, Distance left)
  {
    return withDistanceFromCenterOfRotation(front, left);
  }

  /**
   * Set the location for the {@link SwerveModule} using polar coordinates.
   *
   * @param distance Distance from the center of rotation will be converted to meters.
   * @param angle    Angle from the center of rotation.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withLocation(Distance distance, Angle angle)
  {
    distanceFromCenterOfRotation = Optional.of(new Translation2d(distance.in(Meters), new Rotation2d(angle)));
    return this;
  }

  /**
   * Supply a non-alike vendor absolute encoder for the azimuth {@link SmartMotorController}.
   *
   * @param locationProvider Provides the Rotation for the azimuth {@link SmartMotorController}.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoder(Supplier<Angle> locationProvider)
  {
    absoluteEncoderSupplier = Optional.ofNullable(locationProvider);
    return this;
  }

  /**
   * Supply a non-alike vendor absolute encoder for the azimuth {@link SmartMotorController}.
   *
   * @param rotationSupplier Provides the Rotation for the azimuth {@link SmartMotorController}.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoder(DoubleSupplier rotationSupplier)
  {
    if (rotationSupplier != null)
    {return withAbsoluteEncoder(() -> Rotations.of(rotationSupplier.getAsDouble()));}
    return this;
  }

  /**
   * Set the gearing of the absolute encoder if it's not 1:1.
   *
   * @param gearing {@link GearBox} for the absolute encoder to get the azimuth angle.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoderGearing(GearBox gearing)
  {
    absoluteEncoderGearbox = gearing;
    if (azimuthMotor.isPresent())
    {
      SmartMotorControllerConfig azimuthConfig = azimuthMotor.orElseThrow().getConfig();
      if (azimuthConfig.getExternalEncoder().isPresent())
      {azimuthConfig.withExternalEncoderGearing(new MechanismGearing(gearing));}
    }
    return this;
  }

  /**
   * Set the absolute encoder offset for the azimuth {@link SmartMotorController} so that the absolute encoder reads 0
   * while the wheel is facing forwards and bevel to the left.
   *
   * @param offset Offset for the absolute encoder.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withAbsoluteEncoderOffset(Angle offset)
  {
    absoluteEncoderOffset = Optional.ofNullable(offset);

    if (azimuthMotor.isPresent())
    {
      SmartMotorControllerConfig azimuthConfig = azimuthMotor.orElseThrow().getConfig();
      if (azimuthConfig.getExternalEncoder().isPresent())
      {azimuthConfig.withExternalEncoderZeroOffset(offset);}
    }
    return this;
  }

  /**
   * Set the wheel radius for the {@link SmartMotorController}, ideally should be set inside the drive motor
   * {@link SmartMotorControllerConfig}
   *
   * @param radius Radius of the wheel.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withWheelRadius(Distance radius)
  {
    wheelCircumference = Optional.ofNullable(radius.times(2.0).times(Math.PI));
    driveMotor.ifPresent(driveMotor -> driveMotor.getConfig()
                                                 .withMechanismCircumference(radius.times(2.0).times(Math.PI)));
    return this;
  }

  /**
   * Set the wheel diameter for the {@link SmartMotorController}, ideally should be set inside the drive motor
   * {@link SmartMotorControllerConfig}.
   *
   * @param diameter Diameter of the wheel.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withWheelDiameter(Distance diameter)
  {
    wheelCircumference = Optional.ofNullable(diameter.times(Math.PI));
    driveMotor.ifPresent(driveMotor -> driveMotor.getConfig()
                                                 .withMechanismCircumference(diameter.times(Math.PI)));
    return this;
  }

  /**
   * Set the minimum velocity for the {@link SmartMotorController}.
   *
   * @param speed Minimum velocity for the {@link SmartMotorController}.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withMinimumVelocity(LinearVelocity speed)
  {
    minimumVelocity = Optional.ofNullable(speed);
    return this;
  }

  /**
   * Use {@link edu.wpi.first.math.kinematics.SwerveModuleState#optimize(Rotation2d)} to optimize each state.
   *
   * @param swerveModuleStateOptimization True to enable optimization, false otherwise.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withOptimization(boolean swerveModuleStateOptimization)
  {
    this.swerveModuleStateOptimization = swerveModuleStateOptimization;
    return this;
  }

  /**
   * Configure telemetry for the {@link SwerveModule} mechanism.
   *
   * @param telemetryName      Telemetry NetworkTable name to appear under "SmartDashboard/"
   * @param telemetryVerbosity Telemetry verbosity to apply.
   * @return {@link ArmConfig} for chaining.
   */
  public SwerveModuleConfig withTelemetry(String telemetryName, TelemetryVerbosity telemetryVerbosity)
  {
    this.telemetryName = Optional.ofNullable(telemetryName);
    this.telemetryVerbosity = Optional.ofNullable(telemetryVerbosity);
    return this;
  }

  /**
   * Log this module's telemetry (currently just the absolute encoder field) to a WPILib DataLog under the given
   * name, in addition to NetworkTables.
   *
   * @param dataLogName DataLog entry name prefix for this module's telemetry.
   * @return {@link SwerveModuleConfig} for chaining.
   */
  public SwerveModuleConfig withDataLogName(String dataLogName)
  {
    this.dataLogName = Optional.ofNullable(dataLogName);
    return this;
  }

  /**
   * Get the DataLog entry name prefix for this module's telemetry.
   *
   * @return DataLog entry name prefix, if configured.
   */
  public Optional<String> getDataLogName()
  {
    return dataLogName;
  }

  /**
   * Get the absolute encoder angle for the azimuth {@link SmartMotorController}.
   *
   * @return Absolute encoder {@link Angle}.
   */
  public Angle getAbsoluteEncoderAngle()
  {
    return absoluteEncoderSupplier.map(angleSupplier -> angleSupplier.get()
                                                                     .times(absoluteEncoderGearbox.getInputToOutputConversionFactor())
                                                                     .minus(absoluteEncoderOffset.orElse(Rotations.of(0))))
                                  .orElse(azimuthMotor.orElseThrow().getMechanismPosition());
  }

  /**
   * Get the absolute encoder angle as a supplier without offsets applied.
   *
   * @return {@link Supplier<Angle>} for the absolute encoder angle without offsets.
   */
  public Supplier<Angle> getRawAbsoluteEncoderAngle()
  {
    if(absoluteEncoderSupplier.isPresent())
    {
      return absoluteEncoderSupplier.get();
    }
    else
    {
      var offset = RobotBase.isSimulation() ? Rotations.zero() : azimuthMotor.orElseThrow().getConfig().getZeroOffset().orElse(Rotations.zero());
      return () -> azimuthMotor.orElseThrow().getMechanismPosition().plus(offset);
    }
  }

  /**
   * Get the absolute encoder supplier
   *
   * @return Absolute encoder supplier.
   */
  public Optional<Supplier<Angle>> getAbsoluteEncoderSupplier()
  {
    return absoluteEncoderSupplier;
  }

  /**
   * Enable or disable state optimization.
   *
   * @return True if optimization is enabled, false otherwise.
   */
  public boolean getStateOptimization()
  {
    return swerveModuleStateOptimization;
  }

  /**
   * Get the drive {@link SmartMotorController} for the {@link SwerveModule}.
   *
   * @return {@link SmartMotorController} for the drive motor.
   */
  public SmartMotorController getDriveMotor()
  {
    return driveMotor.orElseThrow();
  }

  /**
   * Get the azimuth {@link SmartMotorController} for the {@link SwerveModule}.
   *
   * @return {@link SmartMotorController} for the azimuth motor.
   */
  public SmartMotorController getAzimuthMotor()
  {
    return azimuthMotor.orElseThrow();
  }

  /**
   * Get the cosine-compensated velocity to set the swerve module to.
   *
   * @param desiredState Desired {@link SwerveModuleState} to use.
   * @param currentAngle Current azimuth angle to compare against, read once per control cycle so
   *                     it stays consistent with whatever value was used earlier in that cycle
   *                     (e.g. for optimization).
   * @return Cosine compensated velocity in meters/second.
   */
  private double getCosineCompensatedVelocity(SwerveModuleState desiredState, Rotation2d currentAngle)
  {
    // Taken from the CTRE SwerveModule class.
    // https://api.ctr-electronics.com/phoenix6/release/java/src-html/com/ctre/phoenix6/mechanisms/swerve/SwerveModule.html#line.46
    /* From FRC 900's whitepaper, we add a cosine compensator to the applied drive velocity */
    /* To reduce the "skew" that occurs when changing direction */
    /* If error is close to 0 rotations, we're already there, so apply full power */
    /* If the error is close to 0.25 rotations, then we're 90 degrees, so movement doesn't help us at all */
    // The azimuth is only meaningful modulo 180 degrees (0 == 180) since the drive motor can spin
    // either direction. Using the SIGNED cosine of the (correctly wrapped) angle difference
    // handles that on its own: near 0 degrees it scales close to +1 (drive forward as
    // commanded), near 90 degrees it goes to 0, and near 180 degrees it goes to -1, which flips
    // the sign of the applied speed so the wheel drives backward at its current heading instead
    // of losing that direction to a forced-positive scalar.
    double cosineScalar = desiredState.angle.minus(currentAngle).getCos();
    if(cosineScalar < 0.0)
      cosineScalar = 1.0;

    return desiredState.speedMetersPerSecond * cosineScalar;
  }

  /**
   * Get the optimized {@link SwerveModuleState} applying all optional optimizations.
   *
   * @param state {@link SwerveModuleState} to optimize.
   * @return {@link SwerveModuleState} optimized.
   */
  public SwerveModuleState getOptimizedState(SwerveModuleState state)
  {
    Rotation2d currentAngle = new Rotation2d(getAbsoluteEncoderAngle());
    if (minimumVelocity.isPresent())
    {
      if (MetersPerSecond.of(Math.abs(state.speedMetersPerSecond)).lte(minimumVelocity.get()))
      {
//        state = new SwerveModuleState(0, state.angle);
        state = new SwerveModuleState(0, currentAngle);

      }
    }
    if (swerveModuleStateOptimization)
    {
        if (lastCommandedAngle == null)
        {
            lastCommandedAngle = currentAngle;
        }
        state.optimize(lastCommandedAngle);
        lastCommandedAngle = state.angle;
    }
    if (cosineCompensation)
    {
      state.speedMetersPerSecond = getCosineCompensatedVelocity(state, new Rotation2d(azimuthMotor.orElseThrow().getMechanismPosition()));
    }
    return state;
  }

  /**
   * Get the telemetry name for the {@link SwerveModule}.
   *
   * @return Telemetry name for the {@link SwerveModule}.
   */
  public Optional<String> getTelemetryName()
  {
    return telemetryName;
  }

  /**
   * Get the telemetry verbosity for the {@link SwerveModule}.
   *
   * @return {@link TelemetryVerbosity} for the {@link SwerveModule}.
   */
  public Optional<TelemetryVerbosity> getTelemetryVerbosity()
  {
    return telemetryVerbosity;
  }

  /**
   * Get the location of the {@link SwerveModule} in meters from the center of rotation.
   *
   * @return {@link Translation2d} of the {@link SwerveModule}
   */
  public Optional<Translation2d> getLocation()
  {
    return distanceFromCenterOfRotation;
  }

}
