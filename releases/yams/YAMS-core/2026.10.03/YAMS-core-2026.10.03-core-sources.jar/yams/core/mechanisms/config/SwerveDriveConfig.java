// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.core.mechanisms.config;

import static org.wpilib.units.Units.MetersPerSecond;
import static org.wpilib.units.Units.Microsecond;
import static org.wpilib.units.Units.Milliseconds;
import static org.wpilib.units.Units.Radians;
import static org.wpilib.units.Units.RadiansPerSecond;
import static org.wpilib.units.Units.Rotations;
import static org.wpilib.units.Units.Seconds;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.Supplier;
import org.wpilib.framework.RobotBase;
import org.wpilib.math.controller.AntiTipping;
import org.wpilib.math.controller.PIDController;
import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.geometry.Rotation3d;
import org.wpilib.math.geometry.Translation2d;
import org.wpilib.math.kinematics.ChassisVelocities;
import org.wpilib.math.util.MathUtil;
import org.wpilib.units.measure.Angle;
import org.wpilib.units.measure.AngularVelocity;
import org.wpilib.units.measure.Distance;
import org.wpilib.units.measure.LinearVelocity;
import org.wpilib.units.measure.Time;
import org.wpilib.util.Alert;
import yams.core.math.DerivativeTimeFilter;
import yams.core.mechanisms.swerve.SwerveDrive;
import yams.core.mechanisms.swerve.SwerveModule;
import yams.core.telemetry.SwerveDriveTelemetryConfig;
import yams.core.telemetry.enums.TelemetryVerbosity;

/**
 * Swerve Drive Configuration.
 *
 * <p>Holds modules, gyro supplier, and drive controllers. Modules are ordered clockwise from
 * front-left: FL, FR, BL, BR. See {@link yams.commands2.config.SwerveDriveConfig} for the
 * Subsystem-bound subclass and a full construction example.
 *
 * @param <T> Concrete config type, so chained {@code with} calls keep the subclass type.
 */
public abstract class SwerveDriveConfig<T extends SwerveDriveConfig<T>> {
  /**
   * {@link SwerveModule}s for the {@link SwerveDrive}.
   */
  private SwerveModule[] modules;
  /**
   * Telemetry name for the {@link SwerveDrive}.
   */
  private String telemetryName = "swerve";
  /**
   * Telemetry verbosity
   */
  private Optional<TelemetryVerbosity> telemetryVerbosity = Optional.empty();
  /**
   * User specified {@link SwerveDriveTelemetryConfig}, takes precedence over
   * {@link #telemetryVerbosity} if present.
   */
  private Optional<SwerveDriveTelemetryConfig> specifiedTelemetryConfig = Optional.empty();
  /**
   * Gyro supplier.
   */
  private Optional<Supplier<Rotation3d>> gyroSupplier = Optional.empty();
  /**
   * The gyro's yaw, kept continuous: a {@link Rotation3d}'s yaw wraps at half a rotation, but the
   * heading must not jump when the robot turns past it.
   */
  private double continuousYawRadians = 0;
  /**
   * Whether {@link #continuousYawRadians} has been read from the gyro yet.
   */
  private boolean continuousYawRead = false;
  /**
   * Gyro angular velocity supplier.
   */
  private Optional<Supplier<AngularVelocity>> gyroAngularVelocitySupplier = Optional.empty();
  /**
   * Derives the gyro angular velocity from the gyro angle ({@link #getGyroAngle()}) when
   * {@link #gyroAngularVelocitySupplier} is not configured, in both simulation and real robot code.
   */
  private final DerivativeTimeFilter gyroAngularVelocityFilter = new DerivativeTimeFilter(Milliseconds.of(20));
  /**
   * Alert shown once if {@link #angularVelocitySkewCorrection(ChassisVelocities)} runs without a
   * {@link #gyroAngularVelocitySupplier} configured, warning that the gyro angular velocity is
   * being
   * derived from the gyro angle instead.
   */
  private Alert noGyroAngularVelocitySupplierAlert = null;
  /**
   * Gyro offset.
   */
  private Optional<Angle> gyroOffset = Optional.empty();
  /**
   * Gyro inverted.
   */
  private boolean gyroInverted = false;
  /**
   * Starting pose on the field.
   */
  private Pose2d initialPose = new Pose2d();
  /**
   * Maximum speed of the chassis.
   */
  private Optional<LinearVelocity> maximumChassisLinearVelocity = Optional.empty();
  /**
   * Maximum angular speed of the chassis.
   */
  private Optional<AngularVelocity> maximumChassisAngularVelocity = Optional.empty();
  /**
   * Maximum speed of the modules.
   */
  private Optional<LinearVelocity> maximumModuleLinearVelocity = Optional.empty();
  /**
   * Override for every module's state optimization; empty to leave each module's own setting.
   */
  private Optional<Boolean> moduleStateOptimization = Optional.empty();
  /**
   * Discretization time for the pose estimation.
   */
  private Optional<Time> discretizationSeconds = Optional.empty();
  /**
   * Angular velocity scale factor.
   */
  private OptionalDouble angularVelocityScaleFactor = OptionalDouble.empty();
  /**
   * Center of Rotation
   */
  private Optional<Translation2d> centerOfRotation = Optional.empty();
  /**
   * Translation PID controller.
   */
  private Optional<PIDController> translationController = Optional.empty();
  /**
   * Rotation PID controller.
   */
  private Optional<PIDController> rotationController = Optional.empty();
  /**
   * Simulated translation PID controller.
   */
  private Optional<PIDController> simTranslationController = Optional.empty();
  /**
   * Simulated rotation PID controller.
   */
  private Optional<PIDController> simRotationController = Optional.empty();
  /**
   * Discretization time for the pose estimation.
   */
  private Optional<Time> simDiscretizationSeconds = Optional.empty();
  /**
   * Angular velocity scale factor.
   */
  private OptionalDouble simAngularVelocityScaleFactor = OptionalDouble.empty();
  /**
   * Anti-tipping correction, see {@link #withAntiTipping(AntiTipping)}.
   */
  private Optional<AntiTipping> antiTipping = Optional.empty();

  /**
   * Create the {@link SwerveDriveConfig} for the {@link SwerveDrive}
   *
   * @param modules {@link SwerveModule}s for the {@link SwerveDrive}
   * @implNote Protected so only {@link yams.commands2.config.SwerveDriveConfig} can construct
   *           this.
   */
  protected SwerveDriveConfig(SwerveModule... modules) {
    this.modules = modules;
  }

  /**
   * Create the {@link SwerveDriveConfig} for the {@link SwerveDrive}
   *
   * @implNote Must define modules with {@link #withModules(SwerveModule...)}. Protected so only
   *           {@link yams.commands2.config.SwerveDriveConfig} can construct this.
   */
  protected SwerveDriveConfig() {
  }

  protected SwerveDriveConfig(SwerveDriveConfig<T> cfg) {
    this.telemetryVerbosity = cfg.telemetryVerbosity;
    this.specifiedTelemetryConfig = cfg.specifiedTelemetryConfig;
    this.initialPose = cfg.initialPose;
    this.maximumChassisLinearVelocity = cfg.maximumChassisLinearVelocity;
    this.maximumChassisAngularVelocity = cfg.maximumChassisAngularVelocity;
    this.maximumModuleLinearVelocity = cfg.maximumModuleLinearVelocity;
    this.moduleStateOptimization = cfg.moduleStateOptimization;
    this.discretizationSeconds = cfg.discretizationSeconds;
    this.angularVelocityScaleFactor = cfg.angularVelocityScaleFactor;
    this.centerOfRotation = cfg.centerOfRotation;
    this.translationController = cfg.translationController;
    this.rotationController = cfg.rotationController;
    this.simTranslationController = cfg.simTranslationController;
    this.simRotationController = cfg.simRotationController;
    this.simDiscretizationSeconds = cfg.simDiscretizationSeconds;
    this.simAngularVelocityScaleFactor = cfg.simAngularVelocityScaleFactor;
    this.antiTipping = cfg.antiTipping;
    // Intentionally not copying these, as they are not user-configurable.
    //    this.gyroSupplier = cfg.gyroSupplier;
    //    this.gyroAngularVelocitySupplier = cfg.gyroAngularVelocitySupplier;
    //    this.gyroOffset = cfg.gyroOffset;
    //    this.gyroInverted = cfg.gyroInverted;
    //    this.telemetryName = cfg.telemetryName;
    //    this.modules = cfg.modules;
    //    this.subsystem = cfg.subsystem;
    //    this.noGyroAngularVelocitySupplierAlert = cfg.noGyroAngularVelocitySupplierAlert;
  }

  /**
   * Get this config as its concrete type, so chained {@code with} calls keep the subclass type.
   *
   * @return this {@link SwerveDriveConfig}.
   */
  protected abstract T self();

  /**
   * Clone the {@link SwerveDriveConfig} without modules, subsystem, telemetry name, gyro supplier,
   * gyro angular velocity supplier, gyro offset, and gyro inversion.
   *
   * @return New {@link SwerveDriveConfig}
   */
  @Override
  public abstract T clone();

  /**
   * Set the {@link SwerveModule}s for the {@link SwerveDrive}.
   *
   * @param modules {@link SwerveModule}s for the {@link SwerveDrive}.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withModules(SwerveModule... modules) {
    this.modules = modules;
    return self();
  }

  /**
   * Set the translation PID controller.
   *
   * @param controller {@link PIDController} for the translation, input units are meters.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withSimTranslationController(PIDController controller) {
    simTranslationController = Optional.ofNullable(controller);
    return self();
  }

  /**
   * Set the rotation PID controller.
   *
   * @param controller {@link PIDController} for the rotation, input units are radians.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withSimRotationController(PIDController controller) {
    if (controller != null) {
      controller.enableContinuousInput(-Math.PI, Math.PI);
    }
    simRotationController = Optional.ofNullable(controller);
    return self();
  }

  /**
   * Set the translation PID controller.
   *
   * @param controller {@link PIDController} for the translation, input units are meters.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withTranslationController(PIDController controller) {
    translationController = Optional.ofNullable(controller);
    return self();
  }

  /**
   * Set the rotation PID controller.
   *
   * @param controller {@link PIDController} for the rotation, input units are radians.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withRotationController(PIDController controller) {
    if (controller != null) {
      controller.enableContinuousInput(-Math.PI, Math.PI);
    }
    rotationController = Optional.ofNullable(controller);
    return self();
  }

  /**
   * Set the center of rotation; 0,0 is the center of the robot.
   *
   * @param centerOfRotation {@link Translation2d} of the center of rotation in Meters, X is
   *                         forward, Y is left.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withCenterOfRotation(Translation2d centerOfRotation) {
    this.centerOfRotation = Optional.ofNullable(centerOfRotation);
    return self();
  }

  /**
   * Set the center of rotation; 0,0 is the center of the robot.
   *
   * @param forward Forward distance from the center of robot.
   * @param left    Left distance from the center of robot.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withCenterOfRotation(Distance forward, Distance left) {
    this.centerOfRotation = Optional.ofNullable(new Translation2d(forward, left));
    return self();
  }

  /**
   * Set the discretization time for the pose estimation.
   *
   * @param dt Discretization time for the pose estimation.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withSimDiscretizationTime(Time dt) {
    simDiscretizationSeconds = Optional.ofNullable(dt);
    return self();
  }

  /**
   * Set the angular velocity scale factor to improve the accuracy of the pose estimation.
   *
   * @param scaleFactor Scale factor to apply to the gyro angular velocity, [0, 1].
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withSimGyroAngularVelocityScaleFactor(double scaleFactor) {
    simAngularVelocityScaleFactor = OptionalDouble.of(scaleFactor);
    return self();
  }

  /**
   * Set the discretization time for the pose estimation.
   *
   * @param dt Discretization time for the pose estimation.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withDiscretizationTime(Time dt) {
    discretizationSeconds = Optional.ofNullable(dt);
    return self();
  }

  /**
   * Set the angular velocity scale factor to improve the accuracy of the pose estimation.
   *
   * @param scaleFactor Scale factor to apply to the gyro angular velocity, [0, 1].
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withGyroAngularVelocityScaleFactor(double scaleFactor) {
    angularVelocityScaleFactor = OptionalDouble.of(scaleFactor);
    return self();
  }

  /**
   * Angular velocity of the gyro.
   *
   * @param angularVelocitySupplier {@link Supplier<AngularVelocity>} for the gyro angular velocity.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withGyroVelocity(Supplier<AngularVelocity> angularVelocitySupplier) {
    gyroAngularVelocitySupplier = Optional.ofNullable(angularVelocitySupplier);
    return self();
  }

  /**
   * Set the gyro, as the robot's attitude: its yaw is the robot's heading, and its roll and pitch
   * are what anti-tipping corrects with (see {@link #withAntiTipping(AntiTipping)}).
   *
   * @param gyro {@link Supplier} for the robot's attitude, such as {@code pigeon::getRotation3d} or
   *             {@code imu::getRotation3d}.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withGyro(Supplier<Rotation3d> gyro) {
    gyroSupplier = Optional.ofNullable(gyro);
    continuousYawRead = false;
    return self();
  }

  /**
   * Drive the robot back under itself when it starts to tip, with WPILib's {@link AntiTipping}: once
   * the robot's pitch or roll, from the gyro set with {@link #withGyro(Supplier)}, is past
   * {@code tippingThreshold}, a correction toward the side it is tipping to, {@code kP} times the sine
   * of the tilt and at most {@code maxCorrectionSpeed}, is added to every robot relative chassis
   * speed. See {@link AntiTipping} for tuning.
   *
   * @param kP                 Correction speed per sine of the tilt.
   * @param tippingThreshold   Tilt past which to correct: a few degrees above the most the robot
   *                           tilts in normal driving, well below where it tips.
   * @param maxCorrectionSpeed Fastest the correction may drive.
   * @return {@link SwerveDriveConfig} for chaining.
   * @throws IllegalArgumentException if {@code kP} or {@code maxCorrectionSpeed} is not positive, or
   *                                  {@code tippingThreshold} is not between 0 and 90 degrees.
   */
  public T withAntiTipping(LinearVelocity kP, Angle tippingThreshold, LinearVelocity maxCorrectionSpeed) {
    if (kP.in(MetersPerSecond) <= 0) {
      throw new IllegalArgumentException("Anti-tipping kP must be positive, but was " + kP);
    }
    if (maxCorrectionSpeed.in(MetersPerSecond) <= 0) {
      throw new IllegalArgumentException("Anti-tipping maximum correction speed must be positive, but was " + maxCorrectionSpeed);
    }
    if (tippingThreshold.in(Radians) <= 0 || tippingThreshold.in(Radians) >= Math.PI / 2) {
      throw new IllegalArgumentException("Anti-tipping threshold must be between 0 and 90 degrees, but was " + tippingThreshold);
    }
    return withAntiTipping(new AntiTipping(kP.in(MetersPerSecond), tippingThreshold.in(Radians), maxCorrectionSpeed.in(MetersPerSecond)));
  }

  /**
   * Drive the robot back under itself when it starts to tip, with an {@link AntiTipping} reading the
   * robot's attitude from the gyro set with {@link #withGyro(Supplier)}: its correction is added to
   * every robot relative chassis speed.
   *
   * @param antiTipping {@link AntiTipping} to correct with.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withAntiTipping(AntiTipping antiTipping) {
    this.antiTipping = Optional.ofNullable(antiTipping);
    return self();
  }

  /**
   * Get the anti-tipping correction for the robot's attitude now.
   *
   * @return Robot relative correction, or zero when the robot is not tipping, or anti-tipping or the
   *     gyro is not configured.
   */
  public ChassisVelocities getAntiTippingCorrection() {
    if (antiTipping.isEmpty() || gyroSupplier.isEmpty()) {
      return new ChassisVelocities();
    }
    // AntiTipping gives the correction in the frame of the attitude, which the gyro's yaw makes the
    // field's. Turn it to the robot's, like the chassis speeds it is added to.
    final Rotation3d attitude = gyroSupplier.get().get();
    return antiTipping.get().calculate(attitude).toRobotRelative(new Rotation2d(attitude.getZ()));
  }

  /**
   * Set the gyro offset.
   *
   * @param offset Offset to apply to the gyro.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withGyroOffset(Angle offset) {
    gyroOffset = Optional.ofNullable(offset);
    return self();
  }

  /**
   * Set the gyro inverted.
   *
   * @param inverted Inverted state of the gyro.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withGyroInverted(boolean inverted) {
    gyroInverted = inverted;
    return self();
  }

  /**
   * Maximum speed of the chassis to desaturate towards.
   *
   * @param speed           Linear velocity of the Chassis.
   * @param angularVelocity Angular velocity of the Chassis.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withMaximumChassisSpeed(LinearVelocity speed, AngularVelocity angularVelocity) {
    maximumChassisLinearVelocity = Optional.ofNullable(speed);
    maximumChassisAngularVelocity = Optional.ofNullable(angularVelocity);
    return self();
  }

  /**
   * Set the maximum speed of the modules to desaturate towards.
   *
   * @param speed Linear velocity of the modules.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withMaximumModuleSpeed(LinearVelocity speed) {
    maximumModuleLinearVelocity = Optional.ofNullable(speed);
    return self();
  }

  /**
   * Enable or disable state optimization on every {@link SwerveModule} of the drive, overriding each
   * module's {@link yams.core.mechanisms.config.SwerveModuleConfig#withOptimization(boolean)}. Without
   * this override, each module keeps its own setting.
   *
   * <p>Modules already in this config are updated immediately, so calling this on a running drive's
   * config (e.g. {@code drive.getConfig().withModuleStateOptimization(false)}) toggles optimization
   * during operation. Modules added later with {@link #withModules(SwerveModule...)} get it when the
   * {@link SwerveDrive} is created.
   *
   * @param enabled True to let modules turn around and reverse their drive when that is the shorter
   *                way to the requested angle, false to always steer to the requested angle.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withModuleStateOptimization(boolean enabled) {
    moduleStateOptimization = Optional.of(enabled);
    if (modules != null) {
      for (SwerveModule module : modules) {
        module.getConfig().withOptimization(enabled);
      }
    }
    return self();
  }

  /**
   * Set the starting pose of the robot.
   *
   * @param pose {@link Pose2d} to set the robot to. {@code new Pose2d()}
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withStartingPose(Pose2d pose) {
    initialPose = pose;
    return self();
  }

  //  /**
  //   * Sets up MapleSim Physics Collision support on the simulated {@link
  //   yams.mechanisms.swerve.SwerveDrive}.
  //   * This integration is simplified and may result in slight differences compared to the real
  //   robot.
  //   * For more information read these
  //   * <a
  //   href="https://shenzhen-robotics-alliance.github.io/maple-sim/swerve-simulation-overview">MapleSim
  //   Docs</a>
  //   *
  //   * @param mapleConfig {@link DriveTrainSimulationConfig} for the simulated {@link
  //   yams.mechanisms.swerve.SwerveDrive}.
  //   * @param startingPose initial pose of the simulated {@link
  //   yams.mechanisms.swerve.SwerveDrive}.
  //   * @return {@link SwerveDriveConfig} for chaining.
  //   */
  //  public T withMapleSim(DriveTrainSimulationConfig mapleConfig, Pose2d
  // startingPose)
  //  {
  //      if (RobotBase.isSimulation()) {
  //          this.mapleDriveSim = Optional.of(new SelfControlledSwerveDriveSimulation(new
  // SwerveDriveSimulation(mapleConfig, startingPose)));
  //          this.initialPose = startingPose;
  //          // Register the drivetrain sim with the SimulatedArena
  //
  // SimulatedArena.getInstance().addDriveTrainSimulation(mapleDriveSim.get().getDriveTrainSimulation());
  //      }
  //      return self();
  //  }

  /**
   * Configure telemetry for the {@link SwerveModule} mechanism.
   *
   * @param name               Telemetry Name
   * @param telemetryVerbosity Telemetry verbosity to apply.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withTelemetry(String name, TelemetryVerbosity telemetryVerbosity) {
    this.telemetryName = name;
    this.telemetryVerbosity = Optional.ofNullable(telemetryVerbosity);
    return self();
  }

  /**
   * Configure telemetry for the {@link SwerveDrive} with a {@link SwerveDriveTelemetryConfig}.
   *
   * @param name            Telemetry Name
   * @param telemetryConfig Config that specifies what to log.
   * @return {@link SwerveDriveConfig} for chaining.
   */
  public T withTelemetry(String name, SwerveDriveTelemetryConfig telemetryConfig) {
    this.telemetryName = name;
    this.telemetryVerbosity = Optional.empty();
    this.specifiedTelemetryConfig = Optional.ofNullable(telemetryConfig);
    return self();
  }

  /**
   * Get the user specified {@link SwerveDriveTelemetryConfig}, if configured via
   * {@link #withTelemetry(String,SwerveDriveTelemetryConfig)}.
   *
   * @return {@link SwerveDriveTelemetryConfig} if configured.
   */
  public Optional<SwerveDriveTelemetryConfig> getSwerveDriveTelemetryConfig() {
    return specifiedTelemetryConfig;
  }

  /**
   * Get the telemetry name for the {@link SwerveDrive}.
   *
   * @return Telemetry name for the {@link SwerveDrive}.
   */
  public String getTelemetryName() {
    return telemetryName;
  }

  /**
   * Get the center of rotation.
   *
   * @return {@link Translation2d} of the center of rotation in Meters, X is forward, Y is left.
   */
  public Optional<Translation2d> getCenterOfRotation() {
    return centerOfRotation;
  }

  /**
   * Get the telemetry verbosity for the {@link SwerveModule}.
   *
   * @return {@link TelemetryVerbosity} for the {@link SwerveModule}.
   */
  public Optional<TelemetryVerbosity> getTelemetryVerbosity() {
    return telemetryVerbosity;
  }

  /**
   * Get the {@link SwerveModule}s for the {@link SwerveDrive}.
   *
   * @return {@link SwerveModule}s for the {@link SwerveDrive}.
   */
  public SwerveModule[] getModules() {
    return modules;
  }

  /**
   * Get the gyro angle with inversions and offsets applied.
   *
   * @return {@link Angle} of the gyro.
   * @throws IllegalStateException if no gyro supplier was set with {@link #withGyro(Supplier)}.
   */
  public Angle getGyroAngle() {
    if (gyroSupplier.isEmpty()) {
      throw new IllegalStateException("Gyro supplier is not set! Please use .withGyro() to set the gyro supplier!");
    }
    // Keep the yaw continuous: unwrapped, it would jump a whole rotation when the robot turns past
    // half a rotation, and the gyro angular velocity derived from it would spike.
    final double wrappedYawRadians = gyroSupplier.get().get().getZ();
    continuousYawRadians = continuousYawRead
                           ? continuousYawRadians + MathUtil.angleModulus(wrappedYawRadians - continuousYawRadians)
                           : wrappedYawRadians;
    continuousYawRead = true;
    final Angle yaw = Radians.of(continuousYawRadians);
    return (gyroInverted ? yaw.unaryMinus() : yaw).minus(gyroOffset.orElse(Rotations.of(0)));
  }

  /**
   * Get the starting pose of the robot.
   *
   * @return {@link Pose2d} of the robot.
   */
  public Pose2d getInitialPose() {
    return initialPose;
  }

  /**
   * Get the maximum speed of the chassis.
   *
   * @return Maximum speed of the chassis.
   */
  public Optional<LinearVelocity> getMaximumChassisLinearVelocity() {
    return maximumChassisLinearVelocity;
  }

  /**
   * Get the maximum angular speed of the chassis.
   *
   * @return Maximum angular speed of the chassis.
   */
  public Optional<AngularVelocity> getMaximumChassisAngularVelocity() {
    return maximumChassisAngularVelocity;
  }

  /**
   * Get the maximum speed of the modules.
   *
   * @return Maximum speed of the modules.
   */
  public Optional<LinearVelocity> getMaximumModuleLinearVelocity() {
    return maximumModuleLinearVelocity;
  }

  /**
   * Get the module state optimization override.
   *
   * @return True or false to enable or disable optimization on every module, or empty to leave each
   *         module's own setting.
   */
  public Optional<Boolean> getModuleStateOptimization() {
    return moduleStateOptimization;
  }

  /**
   * Correct for skew that worsens as angular velocity increases
   *
   * @param robotRelativeVelocity The chassis speeds to set the robot to achieve.
   * @return {@link ChassisVelocities} of the robot after angular velocity skew correction.
   * @throws IllegalStateException if no gyro supplier was set with {@link #withGyro(Supplier)}.
   */
  private ChassisVelocities angularVelocitySkewCorrection(ChassisVelocities robotRelativeVelocity) {
    AngularVelocity gyroAngularVelocity;
    if (gyroAngularVelocitySupplier.isPresent()) {
      gyroAngularVelocity = gyroAngularVelocitySupplier.get().get();
    } else {
      if (noGyroAngularVelocitySupplierAlert == null) {
        noGyroAngularVelocitySupplierAlert = new Alert("YAMS",
            getTelemetryName() + " has an angular velocity scale factor configured but no gyro angular velocity " + ("supplier (see SwerveDriveConfig#withGyroVelocity); deriving it from the gyro " + "angle instead."), Alert.Level.LOW);
        noGyroAngularVelocitySupplierAlert.set(true);
      }
      gyroAngularVelocity = Radians.per(Microsecond).of(gyroAngularVelocityFilter.derivative(getGyroAngle().in(Radians)));
    }
    var angularVelocityScale = (RobotBase.isSimulation() ? simAngularVelocityScaleFactor.orElse(angularVelocityScaleFactor.orElseThrow()) : angularVelocityScaleFactor.orElseThrow());
    var angularVelocity = new Rotation2d(gyroAngularVelocity.in(RadiansPerSecond) * angularVelocityScale);
    if (angularVelocity.getRadians() != 0.0) {
      var gyroRotation = new Rotation2d(getGyroAngle());
      ChassisVelocities fieldRelativeVelocity = robotRelativeVelocity.toFieldRelative(gyroRotation);
      robotRelativeVelocity = fieldRelativeVelocity.toRobotRelative(gyroRotation.plus(angularVelocity));
    }
    return robotRelativeVelocity;
  }

  /**
   * Optimize the given chassis speeds, first adding the anti-tipping correction when it is
   * configured with {@link #withAntiTipping(AntiTipping)}.
   *
   * @param speeds {@link ChassisVelocities} to optimize.
   * @return Optimized {@link ChassisVelocities}.
   * @throws IllegalStateException if a gyro angular velocity scale factor is configured with
   *                               {@link #withGyroAngularVelocityScaleFactor(double)} but no gyro
   *                               supplier was set with {@link #withGyro(Supplier)}.
   */
  public ChassisVelocities optimizeRobotRelativeChassisSpeeds(ChassisVelocities speeds) {
    if (antiTipping.isPresent()) {
      speeds = speeds.plus(getAntiTippingCorrection());
    }
    if (angularVelocityScaleFactor.isPresent()) {
      speeds = angularVelocitySkewCorrection(speeds);
    }
    if (discretizationSeconds.isPresent()) {
      speeds = speeds.discretize((RobotBase.isSimulation() ? simDiscretizationSeconds.orElse(discretizationSeconds.get()) : discretizationSeconds.get()).in(Seconds));
    }
    return speeds;
  }

  /**
   * Get the gyro offset.
   *
   * @return Gyro offset.
   */
  public Angle getGyroOffset() {
    return gyroOffset.orElse(Rotations.of(0));
  }

  /**
   * Get the translation PID controller used for drive to pose. In simulation the simulation
   * controller is preferred over the real one.
   *
   * @return Translation PID controller, or empty when none is configured.
   */
  public Optional<PIDController> getTranslationPID() {
    return RobotBase.isSimulation() ? simTranslationController.or(() -> translationController) : translationController;
  }

  /**
   * Get the rotation PID controller used for drive to pose and heading control. In simulation the
   * simulation controller is preferred over the real one.
   *
   * @return Rotation PID controller, or empty when none is configured.
   */
  public Optional<PIDController> getRotationPID() {
    return RobotBase.isSimulation() ? simRotationController.or(() -> rotationController) : rotationController;
  }

  /**
   * Cube the {@link Translation2d} magnitude given in Polar coordinates.
   *
   * @param translation {@link Translation2d} to manipulate.
   * @return Cubed magnitude from {@link Translation2d}.
   */
  public static Translation2d cubeTranslation(Translation2d translation) {
    if (Math.hypot(translation.getX(), translation.getY()) <= 1.0E-6) {
      return translation;
    }
    return new Translation2d(Math.pow(translation.getNorm(), 3), translation.getAngle().orElse(new Rotation2d()));
  }

  /**
   * Scale the {@link Translation2d} Polar coordinate magnitude.
   *
   * @param translation {@link Translation2d} to use.
   * @param scalar      Multiplier for the Polar coordinate magnitude to use.
   * @return {@link Translation2d} scaled by given magnitude scalar.
   */
  public static Translation2d scaleTranslation(Translation2d translation, double scalar) {
    if (Math.hypot(translation.getX(), translation.getY()) <= 1.0E-6) {
      return translation;
    }
    return new Translation2d(translation.getNorm() * scalar, translation.getAngle().orElse(new Rotation2d()));
  }

  /**
   * Get the discretization time for the pose estimation used by
   * {@link #optimizeRobotRelativeChassisSpeeds(ChassisVelocities)}
   *
   * @return Discretization time for the pose estimation.
   */
  public Optional<Time> getDiscretization() {
    return RobotBase.isSimulation() ? simDiscretizationSeconds : discretizationSeconds;
  }

  //  /**
  //   * Get the {@link SelfControlledSwerveDriveSimulation} if it is configured.
  //   *
  //   * @return the {@link SelfControlledSwerveDriveSimulation} if it is configured, otherwise
  // throws an exception.
  //   */
  //  public Optional<SelfControlledSwerveDriveSimulation> getMapleDriveSim() {
  //      if (RobotBase.isSimulation()) {
  //          return mapleDriveSim;
  //      }
  //      throw new IllegalStateException("RobotBase is not in Simulation, MapleDriveSim is
  // empty!");
  //  }

  /**
   * Use an external feedback sensor for the {@link SwerveModule}s.
   *
   * @return External feedback sensor for the {@link SwerveModule}s.
   */
  public boolean useExternalFeedbackSensor() {
    return true;
  }
}
