// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.core.motorcontrollers.simulation;

import static org.wpilib.units.Units.Amps;
import static org.wpilib.units.Units.Meters;
import static org.wpilib.units.Units.MetersPerSecond;
import static org.wpilib.units.Units.Microsecond;
import static org.wpilib.units.Units.Milliseconds;
import static org.wpilib.units.Units.RadiansPerSecond;
import static org.wpilib.units.Units.RotationsPerSecond;
import static org.wpilib.units.Units.Seconds;
import static org.wpilib.units.Units.Volts;

import java.util.UUID;
import java.util.function.Supplier;
import org.wpilib.math.filter.LinearFilter;
import org.wpilib.math.system.DCMotor;
import org.wpilib.simulation.ElevatorSim;
import org.wpilib.simulation.RoboRioSim;
import org.wpilib.units.measure.Angle;
import org.wpilib.units.measure.AngularAcceleration;
import org.wpilib.units.measure.AngularVelocity;
import org.wpilib.units.measure.Current;
import org.wpilib.units.measure.Time;
import org.wpilib.units.measure.Voltage;
import yams.core.exceptions.SmartMotorControllerConfigurationException;
import yams.core.gearing.MechanismGearing;
import yams.core.math.DerivativeTimeFilter;
import yams.core.motorcontrollers.SimSupplier;
import yams.core.motorcontrollers.SmartMotorController;
import yams.core.motorcontrollers.SmartMotorControllerConfig;

/**
 * ElevatorSim Supplier simulates an elevator mechanism using WPILib's
 * {@link org.wpilib.simulation.ElevatorSim}.
 *
 * <p>This supplier steps WPILib's {@code ElevatorSim} physics model each control loop and exposes
 * the resulting height, linear velocity, current draw, and voltage through the
 * {@link yams.core.motorcontrollers.SimSupplier} interface. Because {@code ElevatorSim} operates in linear
 * units (meters), positions and velocities are converted to and from mechanism (angular) units
 * using the associated {@link yams.core.motorcontrollers.SmartMotorController}'s config.
 *
 * <h2>Example</h2>
 *
 * <pre>{@code
 * // 1. Build the WPILib elevator physics model
 * ElevatorSim elevatorPhysics = new ElevatorSim(
 *     DCMotor.getNEO(1),
 *     10.0,                 // gear ratio (rotor/mechanism)
 *     5.0,                  // carriage mass (kg)
 *     Units.inchesToMeters(1.0), // drum radius (meters)
 *     0.0,                  // minimum height (meters)
 *     1.5,                  // maximum height (meters)
 *     true,                 // simulate gravity
 *     0.0);                 // starting height (meters)
 *
 * // 2. Configure and build the YAMS smart motor controller
 * SmartMotorController motor = new SparkMaxController(
 *     new SmartMotorControllerConfig()
 *         .withGearing(new MechanismGearing(10.0))
 *         .withClosedLoopControlPeriod(Milliseconds.of(20)));
 *
 * // 3. Wrap physics model in the supplier and register it
 * ElevatorSimSupplier sim = new ElevatorSimSupplier(elevatorPhysics, motor);
 * motor.getConfig().withSimSupplier(sim);
 * }</pre>
 */
public class ElevatorSimSupplier implements SimSupplier {
  private final ElevatorSim                sim;
  private final SmartMotorControllerConfig<?> config;
  private final MechanismGearing           mechGearing;
  private final DCMotor                    motor;
  private final UUID                       uuid;
  private final Supplier<Double>           motorDutyCycleSupplier;
  private final Supplier<Double>           pos;
  private final Supplier<Double>           mps;
  private final DerivativeTimeFilter       mpsps;
  private final LinearFilter               supplyCurrentFilter;
  private final Time                       simPeriod;
  private boolean                          inputFed   = false;
  private boolean                          simUpdated = false;

  /**
   * Construct the ElevatorSim supplier
   *
   * @param simulation           Simulation instance
   * @param smartMotorController SMC for the ElevatorSim.
   */
  public ElevatorSimSupplier(ElevatorSim simulation, SmartMotorController smartMotorController) {
    sim = simulation;
    config = smartMotorController.getConfig();
    mechGearing = config.getGearing();
    motor = smartMotorController.getDCMotor();
    uuid = smartMotorController.m_batterySimUUID;
    motorDutyCycleSupplier = smartMotorController::getDutyCycle;
    pos = sim::getPosition;
    mps = sim::getVelocity;
    simPeriod = config.getSimulationPeriod();
    mpsps = new DerivativeTimeFilter(pos.get(), simPeriod);
    // Based off comment from https://github.com/wpilibsuite/allwpilib/issues/8691
    supplyCurrentFilter = LinearFilter.singlePoleIIR(Milliseconds.of(100).in(Seconds), simPeriod.in(Seconds));
  }

  @Override
  public void updateSimState() {
    if (!isInputFed()) {
      sim.setInputVoltage(motorDutyCycleSupplier.get() * RoboRioSim.getVInVoltage());
      RoboRioSim.setVInVoltage(BatterySim.calculateVoltage(uuid, getSupplyCurrent()));
    }
    if (!simUpdated) {
      starveInput();
      sim.update(simPeriod.in(Seconds));
      feedUpdateSim();
    }
  }

  @Override
  public boolean getUpdatedSim() {
    return simUpdated;
  }

  @Override
  public void feedUpdateSim() {
    simUpdated = true;
  }

  @Override
  public void starveUpdateSim() {
    simUpdated = false;
  }

  @Override
  public boolean isInputFed() {
    return inputFed;
  }

  @Override
  public void feedInput() {
    inputFed = true;
  }

  @Override
  public void starveInput() {
    inputFed = false;
  }

  @Override
  public void setMechanismStatorDutyCycle(double dutyCycle) {
    feedInput();
    sim.setInputVoltage(dutyCycle * getMechanismSupplyVoltage().in(Volts));
  }

  @Override
  public Voltage getMechanismSupplyVoltage() {
    return Volts.of(RoboRioSim.getVInVoltage());
  }

  @Override
  public Voltage getMechanismStatorVoltage() {
    return Volts.of(motor.getVoltage(motor.getTorque(sim.getCurrentDraw()), getMechanismVelocity().in(RadiansPerSecond)));
  }

  @Override
  public void setMechanismStatorVoltage(Voltage volts) {
    feedInput();
    sim.setInputVoltage(volts.in(Volts));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public Angle getMechanismPosition() {
    return config.convertToMechanism(Meters.of(pos.get()));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public void setMechanismPosition(Angle position) {
    sim.setState(config.convertFromMechanism(position).in(Meters), mps.get());
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public Angle getRotorPosition() {
    return getMechanismPosition().times(mechGearing.getMechanismToRotorRatio());
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public AngularVelocity getMechanismVelocity() {
    return config.convertToMechanism(MetersPerSecond.of(mps.get()));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public void setMechanismVelocity(AngularVelocity velocity) {
    sim.setState(pos.get(), config.convertFromMechanism(velocity).in(MetersPerSecond));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public AngularVelocity getRotorVelocity() {
    return getMechanismVelocity().times(mechGearing.getMechanismToRotorRatio());
  }

  @Override
  public Current getStatorCurrent() {
    return Amps.of(sim.getCurrentDraw());
  }

  @Override
  public Current getSupplyCurrent() {
    // For a BLDC driven by a switching converter, power is conserved across the duty-cycle
    // transformation: supplyVoltage * supplyCurrent = statorVoltage * statorCurrent, and
    // statorVoltage = dutyCycle * supplyVoltage, so supplyCurrent = dutyCycle * statorCurrent.
    double dutyCycle = motorDutyCycleSupplier.get();
    return Amps.of(supplyCurrentFilter.calculate(dutyCycle * sim.getCurrentDraw()));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public AngularAcceleration getRotorAcceleration() {
    return RotationsPerSecond.per(Microsecond).of(mpsps.derivative(getRotorVelocity().in(RotationsPerSecond)));
  }
}
