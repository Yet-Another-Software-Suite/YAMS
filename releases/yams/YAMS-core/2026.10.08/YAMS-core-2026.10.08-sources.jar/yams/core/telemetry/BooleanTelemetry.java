// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.core.telemetry;

import java.util.Optional;
import org.wpilib.datalog.BooleanLogEntry;
import org.wpilib.networktables.BooleanPublisher;
import org.wpilib.networktables.BooleanSubscriber;
import org.wpilib.networktables.BooleanTopic;
import org.wpilib.networktables.NetworkTable;
import org.wpilib.networktables.PubSub;
import org.wpilib.system.DataLogManager;
import org.wpilib.system.Timer;

/**
 * Boolean Telemetry for SmartMotorControllers.
 *
 * <p>A lightweight wrapper that publishes a single {@code boolean} value to NetworkTables and/or a
 * WPILib DataLog. It is used internally by {@link SmartMotorControllerTelemetry} to track flags
 * such as limit-switch states, active feedforward type, and motor inversion but it can also be
 * constructed directly when you need a standalone boolean entry.
 *
 * <h2>Example</h2>
 *
 * <pre>{@code
 * // Create and publish a boolean entry for "at speed" under the Shooter table.
 * BooleanTelemetry&lt;BooleanTelemetryField&gt; atSpeed = new BooleanTelemetry&lt;&gt;(
 *     "atSpeed",                                        // NetworkTables key
 *     false,                                            // default value
 *     SmartMotorControllerTelemetry.BooleanTelemetryField.VelocityControl,
 *     false);                                           // not tunable
 *
 * NetworkTable shooterTable = NetworkTableInstance.getDefault().getTable("Shooter");
 * atSpeed.enable();
 * atSpeed.setupNetworkTable(shooterTable);
 *
 * // In periodic:
 * atSpeed.set(shooter.isAtSpeed());
 * }</pre>
 *
 * @param <F> Enum type identifying which field this telemetry entry represents.
 */
public class BooleanTelemetry<F> {
  /** Field representing. */
  private final F field;
  /** Network table key. */
  private final String key;
  /** Tunable? */
  private final boolean tunable;
  /** Enabled? */
  protected boolean enabled = false;
  /** Default value. */
  private boolean defaultValue;
  /** Cached value. */
  private boolean cachedValue;
  /** Publisher. */
  private BooleanPublisher publisher = null;
  /** Subscriber. */
  private Optional<BooleanSubscriber> subscriber = Optional.empty();
  /** Sub publisher. */
  private BooleanPublisher pubSub = null;
  /** pub or sub topic. */
  private BooleanTopic topic;
  /** DataLog entry. */
  private Optional<BooleanLogEntry> dataLogEntry = Optional.empty();
  /** Tuning table */
  private Optional<NetworkTable> tuningTable = Optional.empty();
  /** Data table. */
  private Optional<NetworkTable> dataTable = Optional.empty();

  /**
   * Setup boolean telemetry for a field.
   *
   * @param keyString  Networks table key.
   * @param defaultVal Default value.
   * @param field      Field representing.
   * @param tunable    Tunable?
   */
  public BooleanTelemetry(String keyString, boolean defaultVal, F field, boolean tunable) {
    key = keyString;
    cachedValue = defaultValue = defaultVal;
    this.field = field;
    this.tunable = tunable;
  }

  /**
   * Setup network tables.
   *
   * @param dataTable   Data tables.
   * @param tuningTable Tuning table.
   */
  public void setupNetworkTables(NetworkTable dataTable, NetworkTable tuningTable) {
    this.dataTable = Optional.ofNullable(dataTable);
    this.tuningTable = Optional.ofNullable(tuningTable);
    if (tuningTable != null && tunable) {
      topic = tuningTable.getBooleanTopic(key);
      pubSub = topic.publish();
      pubSub.setDefault(defaultValue);
      subscriber = Optional.of(topic.subscribe(defaultValue));
    } else {
      topic = dataTable.getBooleanTopic(key);
      publisher = topic.publish();
      publisher.setDefault(defaultValue);
    }
  }

  /**
   * Setup the DataLog entry for this telemetry field.
   *
   * @param prefix Prefix of the entry.
   */
  public void setupDataLog(String prefix) {
    if (!tunable) {
      if (!prefix.endsWith("/")) {
        prefix += "/";
      }
      dataLogEntry = Optional.of(new BooleanLogEntry(DataLogManager.getLog(), prefix + key, (long) Timer.getTimestamp()));
    }
  }

  /**
   * Setup network tables.
   *
   * @param dataTable Data tables.
   */
  public void setupNetworkTable(NetworkTable dataTable) {
    setupNetworkTables(dataTable, null);
  }

  /**
   * Set the value of the publisher, checking to see if the value is the same as the subscriber.
   *
   * @param value Value to set.
   * @return True if value was able to be set.
   */
  public boolean set(boolean value) {
    if (dataLogEntry.isPresent()) {
      dataLogEntry.get().append(value);
    }
    if (subscriber.isPresent()) {
      boolean tuningValue = subscriber.get().get(defaultValue);
      if (tuningValue != value) {
        return false;
      }
    }
    if (publisher != null) {
      publisher.accept(value);
    }
    return true;
  }

  /**
   * Forcibly overwrite the tunable value in NetworkTables, bypassing the subscriber-must-match
   * guard in {@link #set(boolean)}. Used to enforce mutual exclusion between tunable modes that
   * share the same underlying drive/mechanism.
   *
   * @param value Value to force onto the tuning topic.
   */
  public void forceSet(boolean value) {
    cachedValue = value;
    if (pubSub != null) {
      pubSub.accept(value);
    } else if (publisher != null) {
      publisher.accept(value);
    }
  }

  /**
   * Get the value.
   *
   * @return Value.
   * @throws RuntimeException if this field is not tunable, so no tuning subscriber exists.
   * @throws RuntimeException if {@link #setupNetworkTables(NetworkTable, NetworkTable)} was not
   *                          called with a non-null tuning table, so no tuning subscriber exists.
   */
  public boolean get() {
    if (subscriber.isPresent()) {
      return subscriber.get().get(defaultValue);
    }
    throw new RuntimeException("Tuning table not configured for " + key + "!");
  }

  /**
   * Check to see if the value has changed.
   *
   * @return True if the value has changed.
   */
  public boolean tunable() {
    if (subscriber.isPresent() && tunable && enabled) {
      if (subscriber.get().get(defaultValue) != cachedValue) {
        cachedValue = subscriber.get().get(defaultValue);
        return true;
      }
      return false;
    }
    return false;
  }

  /** Enable the telemetry. */
  public void enable() {
    enabled = true;
  }

  /** Disable the telemetry. */
  public void disable() {
    enabled = false;
  }

  /**
   * Display the telemetry.
   *
   * @param state Enable or disable.
   */
  public void display(boolean state) {
    enabled = state;
  }

  /**
   * Get the field.
   *
   * @return field.
   */
  public F getField() {
    return field;
  }

  /**
   * Set the default value.
   *
   * @param value Default value.
   */
  public void setDefaultValue(boolean value) {
    defaultValue = value;
    cachedValue = value;
  }

  /** Close the telemetry field. */
  public void close() {
    subscriber.ifPresent(PubSub::close);
    if (pubSub != null) {
      pubSub.close();
    }
    if (publisher != null) {
      publisher.close();
    }
    dataTable.ifPresent(table -> table.getEntry(key).unpublish());
    tuningTable.ifPresent(table -> table.getEntry(key).unpublish());
  }
}
