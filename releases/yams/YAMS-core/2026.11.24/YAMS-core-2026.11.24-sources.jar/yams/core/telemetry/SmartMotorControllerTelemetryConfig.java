// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.core.telemetry;

import static org.wpilib.units.Units.Degrees;
import static org.wpilib.units.Units.Meters;
import static org.wpilib.units.Units.RPM;
import static org.wpilib.units.Units.RotationsPerSecond;
import static org.wpilib.units.Units.RotationsPerSecondPerSecond;
import static org.wpilib.units.Units.Second;
import static org.wpilib.units.Units.Seconds;
import static org.wpilib.units.Units.Volts;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import yams.core.math.LQRConfig.LQRType;
import yams.core.math.LQRController;
import yams.core.motorcontrollers.SmartMotorController;
import yams.core.telemetry.SmartMotorControllerTelemetry.BooleanTelemetryField;
import yams.core.telemetry.SmartMotorControllerTelemetry.DoubleTelemetryField;
import yams.core.telemetry.enums.TelemetryVerbosity;

/**
 * Smart motor controller telemetry configuration.
 *
 * <p>Use this builder to select exactly which fields are published to NetworkTables and/or DataLog.
 * Every field is disabled by default; call the individual {@code with*()} methods to opt in, or use
 * {@link #withTelemetryVerbosity} to enable a predefined set.
 *
 * <h2>Example</h2>
 *
 * <pre>{@code
 * SmartMotorControllerTelemetryConfig telemetryCfg =
 *     new SmartMotorControllerTelemetryConfig()
 *         // choose a verbosity preset (LOW / MID / HIGH), or enable fields individually below
 *         .withTelemetryVerbosity(TelemetryVerbosity.HIGH)
 *         // optionally enable individual fields on top of the preset
 *         .withStatorCurrent()
 *         .withTemperature()
 *         .withOutputVoltage()
 *         .withSetpointPosition()
 *         .withSetpointVelocity()
 *         .withSetpointForce()
 *         .withMechanismPosition()
 *         .withMechanismVelocity()
 *         .withRotorPosition()
 *         .withRotorVelocity()
 *         .withMeasurementPosition()
 *         .withMeasurementVelocity()
 *         .withMechanismUpperLimit()
 *         .withMechanismLowerLimit()
 *         .withTemperatureLimit()
 *         .withVelocityControl()
 *         .withMotionProfile()
 *         .withArmFeedforward()
 *         .withElevatorFeedforward()
 *         .withSimpleFeedforward()
 *         // disable NT4 output (e.g. during competition) and log to DataLog instead
 *         .withoutNetworkTables()
 *         .withDataLogName("motors/shooter");
 * }</pre>
 */
public class SmartMotorControllerTelemetryConfig {
  /** DataLog entry name */
  private Optional<String> dataLogName = Optional.empty();
  /** Enable telemetry over network tables. */
  private boolean NT4Telemetry = true;
  /** {@link BooleanTelemetryField}s to enable or disable. */
  private final Map<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> boolFields = Arrays.stream(BooleanTelemetryField.values()).collect(Collectors.toMap(e -> e, BooleanTelemetryField::create));
  /** {@link DoubleTelemetryField} to enable or disable. */
  private final Map<DoubleTelemetryField, DoubleTelemetry<DoubleTelemetryField>> doubleFields = Arrays.stream(DoubleTelemetryField.values()).collect(Collectors.toMap(e -> e, DoubleTelemetryField::create));

  /** Create a {@link SmartMotorControllerTelemetryConfig} with the default fields. */
  public SmartMotorControllerTelemetryConfig() {}

  /**
   * Set up a DataLog entry for this {@link SmartMotorController}
   *
   * @param dataLogName DataLog entry name
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withDataLogName(String dataLogName) {
    this.dataLogName = Optional.ofNullable(dataLogName);
    return this;
  }

  /**
   * Enable or disable NT4 Telemetry. This will not create NT4 entries and is generally only
   * advisable during competition matches.
   *
   * @param NT4Telemetry NT4 Boolean
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withNetworkTables(boolean NT4Telemetry) {
    this.NT4Telemetry = NT4Telemetry;
    return this;
  }

  /**
   * Disable NetworkTable output.
   *
   * @return Disable NT4 telemetry.
   */
  public SmartMotorControllerTelemetryConfig withoutNetworkTables() {
    this.NT4Telemetry = false;
    return this;
  }

  /**
   * Setup with {@link TelemetryVerbosity}
   *
   * @param verbosity {@link TelemetryVerbosity} to use.
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withTelemetryVerbosity(TelemetryVerbosity verbosity) {
    switch (verbosity) {
      case HIGH:
        boolFields.get(BooleanTelemetryField.MechanismLowerLimit).enable();
        boolFields.get(BooleanTelemetryField.MechanismUpperLimit).enable();
        boolFields.get(BooleanTelemetryField.TemperatureLimit).enable();
        boolFields.get(BooleanTelemetryField.VelocityControl).enable();
        boolFields.get(BooleanTelemetryField.ElevatorFeedForward).enable();
        boolFields.get(BooleanTelemetryField.ArmFeedForward).enable();
        boolFields.get(BooleanTelemetryField.SimpleMotorFeedForward).enable();
        boolFields.get(BooleanTelemetryField.MotionProfile).enable();
        boolFields.get(BooleanTelemetryField.MotorInversion).enable();
        boolFields.get(BooleanTelemetryField.EncoderInversion).enable();
        boolFields.get(BooleanTelemetryField.TunableVoltageEnabled).enable();
        doubleFields.get(DoubleTelemetryField.TunableVoltage).enable();
        doubleFields.get(DoubleTelemetryField.TunableSetpointPosition).enable();
        doubleFields.get(DoubleTelemetryField.TunableSetpointVelocity).enable();
        doubleFields.get(DoubleTelemetryField.TunableClosedLoopControllerSlot).enable();
        doubleFields.get(DoubleTelemetryField.MotorTemperature).enable();
        doubleFields.get(DoubleTelemetryField.MechanismLowerLimit).enable();
        doubleFields.get(DoubleTelemetryField.MechanismUpperLimit).enable();
        doubleFields.get(DoubleTelemetryField.StatorCurrentLimit).enable();
        doubleFields.get(DoubleTelemetryField.SupplyCurrentLimit).enable();
        doubleFields.get(DoubleTelemetryField.OpenloopRampRate).enable();
        doubleFields.get(DoubleTelemetryField.ClosedloopRampRate).enable();
        doubleFields.get(DoubleTelemetryField.MeasurementLowerLimit).enable();
        doubleFields.get(DoubleTelemetryField.MeasurementUpperLimit).enable();
        doubleFields.get(DoubleTelemetryField.kS).enable();
        doubleFields.get(DoubleTelemetryField.kV).enable();
        doubleFields.get(DoubleTelemetryField.kG).enable();
        doubleFields.get(DoubleTelemetryField.kA).enable();
        doubleFields.get(DoubleTelemetryField.kP).enable();
        doubleFields.get(DoubleTelemetryField.kI).enable();
        doubleFields.get(DoubleTelemetryField.kD).enable();
        // Only kept for a motor controller running an ADRC, see SmartMotorControllerTelemetry.setupTelemetry.
        doubleFields.get(DoubleTelemetryField.ADRCDisturbance).enable();
        doubleFields.get(DoubleTelemetryField.ADRCBandwidth).enable();
        doubleFields.get(DoubleTelemetryField.ADRCObserverBandwidth).enable();
        doubleFields.get(DoubleTelemetryField.ADRCSystemOrder).enable();
        doubleFields.get(DoubleTelemetryField.ADRCB0).enable();
        doubleFields.get(DoubleTelemetryField.ADRCSettlingTime).enable();
        doubleFields.get(DoubleTelemetryField.ADRCBandwidthScale).enable();
        // Only kept for a motor controller configured with an LQR, see getDoubleFields.
        doubleFields.get(DoubleTelemetryField.LQRQelmsPosition).enable();
        doubleFields.get(DoubleTelemetryField.LQRQelmsVelocity).enable();
        doubleFields.get(DoubleTelemetryField.LQRRelms).enable();
        doubleFields.get(DoubleTelemetryField.LQRModelPosition).enable();
        doubleFields.get(DoubleTelemetryField.LQRModelVelocity).enable();
        doubleFields.get(DoubleTelemetryField.LQREncoderPosition).enable();
        doubleFields.get(DoubleTelemetryField.LQREncoderVelocity).enable();
        doubleFields.get(DoubleTelemetryField.LQRMaxVoltage).enable();
        doubleFields.get(DoubleTelemetryField.SetpointForce).enable();
        doubleFields.get(DoubleTelemetryField.ClosedLoopPeriod).enable();
        doubleFields.get(DoubleTelemetryField.VelocityMeasurementDelay).enable();
      case MID:
        doubleFields.get(DoubleTelemetryField.OutputVoltage).enable();
        doubleFields.get(DoubleTelemetryField.StatorCurrent).enable();
        doubleFields.get(DoubleTelemetryField.SupplyCurrent).enable();
      case LOW:
        doubleFields.get(DoubleTelemetryField.ActiveClosedLoopControllerSlot).enable();
        doubleFields.get(DoubleTelemetryField.SetpointPosition).enable();
        doubleFields.get(DoubleTelemetryField.SetpointVelocity).enable();
        doubleFields.get(DoubleTelemetryField.MeasurementPosition).enable();
        doubleFields.get(DoubleTelemetryField.MeasurementCircumference).enable();
        doubleFields.get(DoubleTelemetryField.MeasurementVelocity).enable();
        doubleFields.get(DoubleTelemetryField.MeasurementAcceleration).enable();
        doubleFields.get(DoubleTelemetryField.MechanismPosition).enable();
        doubleFields.get(DoubleTelemetryField.MechanismVelocity).enable();
        doubleFields.get(DoubleTelemetryField.MechanismAcceleration).enable();
        doubleFields.get(DoubleTelemetryField.RotorPosition).enable();
        doubleFields.get(DoubleTelemetryField.RotorGearRatio).enable();
        doubleFields.get(DoubleTelemetryField.RotorVelocity).enable();
        doubleFields.get(DoubleTelemetryField.ExternalEncoderPosition).enable();
        doubleFields.get(DoubleTelemetryField.ExternalEncoderVelocity).enable();
    }
    /*
    if (verbosity == TelemetryVerbosity.HIGH)
    {
      for (DoubleTelemetry dt : doubleFields.values())
      {
        if (!dt.enabled)
        {
          //System.err.println("DT " + dt.getField().name() + " is DISABLED!!");
        }
      }
      for (BooleanTelemetry<BooleanTelemetryField> dt : boolFields.values())
      {
        if (!dt.enabled)
        {
          //System.err.println("BT " + dt.getField().name() + " is DISABLED!!");
        }
      }
    }*/
    return this;
  }

  /**
   * Get the entry name for the smart motor controller in DataLog.
   *
   * @return DataLog entry name.
   */
  public Optional<String> getDataLogName() {
    return dataLogName;
  }

  /**
   * Log telemetry to NT4?
   *
   * @return should Telemetry be sent to NT4.
   */
  public boolean getNT4Enabled() {
    return NT4Telemetry;
  }

  /**
   * Get the configured double fields.
   *
   * @param smc {@link SmartMotorController} used to disable unavailable telemetry for certain motor
   *            controllers.
   * @return Configured {@link DoubleTelemetry} for each {@link DoubleTelemetryField}
   */
  public Map<DoubleTelemetryField, DoubleTelemetry<DoubleTelemetryField>> getDoubleFields(SmartMotorController smc) {
    var config = smc.getConfig();
    var unsupTelemetry = smc.getUnsupportedTelemetryFields();
    unsupTelemetry.getFirst().ifPresent(btList -> {
      for (BooleanTelemetryField bt : btList) {
        boolFields.get(bt).disable();
      }
    });
    unsupTelemetry.getSecond().ifPresent(dtList -> {
      for (DoubleTelemetryField dt : dtList) {
        doubleFields.get(dt).disable();
      }
    });
    if (smc.getSupplyCurrent().isEmpty()) {
      doubleFields.get(DoubleTelemetryField.SupplyCurrent).disable();
      doubleFields.get(DoubleTelemetryField.SupplyCurrentLimit).disable();
    }
    if (config.getSimpleFeedforward(smc.getClosedLoopControllerSlot()).isEmpty()) {
      doubleFields.get(DoubleTelemetryField.kG).disable();
    }
    if (config.getMechanismCircumference().isEmpty()) {
      doubleFields.get(DoubleTelemetryField.MeasurementLowerLimit).disable();
      doubleFields.get(DoubleTelemetryField.MeasurementUpperLimit).disable();
      doubleFields.get(DoubleTelemetryField.MeasurementPosition).disable();
      doubleFields.get(DoubleTelemetryField.MeasurementCircumference).disable();
      doubleFields.get(DoubleTelemetryField.MeasurementVelocity).disable();
    } else {
      config.getMechanismUpperLimit().ifPresent(upperLimit -> doubleFields.get(DoubleTelemetryField.MeasurementUpperLimit).setDefaultValue(config.convertFromMechanism(upperLimit).in(Meters)));
      config.getMechanismLowerLimit().ifPresent(limit -> doubleFields.get(DoubleTelemetryField.MeasurementLowerLimit).setDefaultValue(config.convertFromMechanism(limit).in(Meters)));
    }
    config.getMechanismUpperLimit().ifPresent(limit -> doubleFields.get(DoubleTelemetryField.MechanismUpperLimit).setDefaultValue(limit.in(Degrees)));
    config.getMechanismLowerLimit().ifPresent(limit -> doubleFields.get(DoubleTelemetryField.MechanismLowerLimit).setDefaultValue(limit.in(Degrees)));
    config.getSupplyStallCurrentLimit().ifPresent(e -> doubleFields.get(DoubleTelemetryField.SupplyCurrentLimit).setDefaultValue(e));
    config.getStatorStallCurrentLimit().ifPresent(e -> doubleFields.get(DoubleTelemetryField.StatorCurrentLimit).setDefaultValue(e));
    config.getPID(smc.getClosedLoopControllerSlot()).ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.kP).setDefaultValue(e.getP());
      doubleFields.get(DoubleTelemetryField.kI).setDefaultValue(e.getI());
      doubleFields.get(DoubleTelemetryField.kD).setDefaultValue(e.getD());
    });
    config.getTrapezoidProfile().ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.ExponentialProfileMaxInput).disable();
      doubleFields.get(DoubleTelemetryField.ExponentialProfileKA).disable();
      doubleFields.get(DoubleTelemetryField.ExponentialProfileKV).disable();

      doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxAcceleration).enable();
      if (config.getVelocityTrapezoidalProfileInUse()) {
        var maxJerk = RotationsPerSecondPerSecond.per(Second).of(e.maxAcceleration);
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxJerk).setDefaultValue(maxJerk.in(RPM.per(Second).per(Second)));
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxJerk).enable();
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxVelocity).disable();
      } else if (config.getLinearClosedLoopControllerUse()) {
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxAcceleration).setDefaultValue(e.maxAcceleration);
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxVelocity).setDefaultValue(e.maxVelocity);
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxVelocity).enable();
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxJerk).disable();
      } else {
        // In the units applyTuningValues reads it back in.
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxAcceleration).setDefaultValue(RotationsPerSecondPerSecond.of(e.maxAcceleration).in(RPM.per(Second)));
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxVelocity).setDefaultValue(RotationsPerSecond.of(e.maxVelocity).in(RPM));
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxVelocity).enable();
        doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxJerk).disable();
      }
    });
    config.getExponentialProfile().ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxAcceleration).disable();
      doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxVelocity).disable();
      doubleFields.get(DoubleTelemetryField.TrapezoidalProfileMaxJerk).disable();

      doubleFields.get(DoubleTelemetryField.ExponentialProfileKA).enable();
      doubleFields.get(DoubleTelemetryField.ExponentialProfileKV).enable();
      doubleFields.get(DoubleTelemetryField.ExponentialProfileMaxInput).enable();
      // In the profile's own units, as configured and as setExponentialProfile takes them.
      var defaultkV = -e.A / e.B;
      var defaultkA = 1.0 / e.B;
      var defaultMaxInput = e.maxInput;
      doubleFields.get(DoubleTelemetryField.ExponentialProfileKA).setDefaultValue(defaultkA);
      doubleFields.get(DoubleTelemetryField.ExponentialProfileKV).setDefaultValue(defaultkV);
      doubleFields.get(DoubleTelemetryField.ExponentialProfileMaxInput).setDefaultValue(defaultMaxInput);
    });
    // An LQR replaces kP, kI and kD with its own values. Without one, its fields never appear.
    var lqr = config.getLQRClosedLoopController().flatMap(LQRController::getConfig);
    if (lqr.isEmpty()) {
      doubleFields.get(DoubleTelemetryField.LQRQelmsPosition).disable();
      doubleFields.get(DoubleTelemetryField.LQRQelmsVelocity).disable();
      doubleFields.get(DoubleTelemetryField.LQRRelms).disable();
      doubleFields.get(DoubleTelemetryField.LQRModelPosition).disable();
      doubleFields.get(DoubleTelemetryField.LQRModelVelocity).disable();
      doubleFields.get(DoubleTelemetryField.LQREncoderPosition).disable();
      doubleFields.get(DoubleTelemetryField.LQREncoderVelocity).disable();
      doubleFields.get(DoubleTelemetryField.LQRMaxVoltage).disable();
    }
    lqr.ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.kP).disable();
      doubleFields.get(DoubleTelemetryField.kI).disable();
      doubleFields.get(DoubleTelemetryField.kD).disable();
      LQRType type = e.getType();
      double[] qelms = e.getQelms();
      double[] model = e.getModelStdDevs();
      double[] encoder = e.getEncoderStdDevs();
      doubleFields.get(DoubleTelemetryField.LQRRelms).setDefaultValue(e.getRelms().in(Volts));
      doubleFields.get(DoubleTelemetryField.LQRMaxVoltage).setDefaultValue(e.getMaxVoltage().in(Volts));
      if (type == LQRType.FLYWHEEL) {
        // One modeled state, velocity, measured by the encoder.
        doubleFields.get(DoubleTelemetryField.LQRQelmsPosition).disable();
        doubleFields.get(DoubleTelemetryField.LQRModelPosition).disable();
        doubleFields.get(DoubleTelemetryField.LQREncoderPosition).disable();
        doubleFields.get(DoubleTelemetryField.LQRQelmsVelocity).setDefaultValue(LQRUnits.fromSI(type, false, qelms[0]));
        doubleFields.get(DoubleTelemetryField.LQRModelVelocity).setDefaultValue(LQRUnits.fromSI(type, false, model[0]));
        doubleFields.get(DoubleTelemetryField.LQREncoderVelocity).setDefaultValue(LQRUnits.fromSI(type, false, encoder[0]));
      } else {
        // Two modeled states, position and velocity, with the encoder measuring position.
        doubleFields.get(DoubleTelemetryField.LQREncoderVelocity).disable();
        doubleFields.get(DoubleTelemetryField.LQRQelmsPosition).setDefaultValue(LQRUnits.fromSI(type, true, qelms[0]));
        doubleFields.get(DoubleTelemetryField.LQRQelmsVelocity).setDefaultValue(LQRUnits.fromSI(type, false, qelms[1]));
        doubleFields.get(DoubleTelemetryField.LQRModelPosition).setDefaultValue(LQRUnits.fromSI(type, true, model[0]));
        doubleFields.get(DoubleTelemetryField.LQRModelVelocity).setDefaultValue(LQRUnits.fromSI(type, false, model[1]));
        doubleFields.get(DoubleTelemetryField.LQREncoderPosition).setDefaultValue(LQRUnits.fromSI(type, true, encoder[0]));
      }
    });
    // An ADRC replaces kP, kI and kD with its own values. Without one, SmartMotorControllerTelemetry disables its
    // fields.
    smc.getADRCController().ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.kP).disable();
      doubleFields.get(DoubleTelemetryField.kI).disable();
      doubleFields.get(DoubleTelemetryField.kD).disable();
      // Seed the tuning topics with the controller's values, so the dashboard shows what is
      // running instead of the enum defaults.
      doubleFields.get(DoubleTelemetryField.ADRCB0).setDefaultValue(e.getB0());
      doubleFields.get(DoubleTelemetryField.ADRCSettlingTime).setDefaultValue(e.getSettlingTime().in(Seconds));
      doubleFields.get(DoubleTelemetryField.ADRCBandwidthScale).setDefaultValue(e.getBandwidthScale());
    });
    config.getArmFeedforward(smc.getClosedLoopControllerSlot()).ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.kG).enable();
      doubleFields.get(DoubleTelemetryField.kS).setDefaultValue(e.getKs());
      doubleFields.get(DoubleTelemetryField.kV).setDefaultValue(e.getKv());
      doubleFields.get(DoubleTelemetryField.kA).setDefaultValue(e.getKa());
      doubleFields.get(DoubleTelemetryField.kG).setDefaultValue(e.getKg());
    });
    config.getElevatorFeedforward(smc.getClosedLoopControllerSlot()).ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.kG).enable();
      doubleFields.get(DoubleTelemetryField.kS).setDefaultValue(e.getKs());
      doubleFields.get(DoubleTelemetryField.kV).setDefaultValue(e.getKv());
      doubleFields.get(DoubleTelemetryField.kA).setDefaultValue(e.getKa());
      doubleFields.get(DoubleTelemetryField.kG).setDefaultValue(e.getKg());
    });
    config.getSimpleFeedforward(smc.getClosedLoopControllerSlot()).ifPresent(e -> {
      doubleFields.get(DoubleTelemetryField.kG).disable();
      doubleFields.get(DoubleTelemetryField.kS).setDefaultValue(e.getKs());
      doubleFields.get(DoubleTelemetryField.kV).setDefaultValue(e.getKv());
      doubleFields.get(DoubleTelemetryField.kA).setDefaultValue(e.getKa());
    });
    if (smc.getExternalEncoderMechanismPosition().isEmpty()) {
      doubleFields.get(DoubleTelemetryField.ExternalEncoderPosition).disable();
    }
    if (smc.getExternalEncoderMechanismVelocity().isEmpty()) {
      doubleFields.get(DoubleTelemetryField.ExternalEncoderVelocity).disable();
    }
    return doubleFields;
  }

  /**
   * Get the configured bool fields.
   *
   * @param smc {@link SmartMotorController} used to disable unavailable telemetry for certain motor
   *            controllers.
   * @return Configured {@link BooleanTelemetry} for each {@link BooleanTelemetryField}.
   */
  public Map<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> getBoolFields(SmartMotorController smc) {
    var config = smc.getConfig();
    if (config.getArmFeedforward(smc.getClosedLoopControllerSlot()).isEmpty()) {
      boolFields.get(BooleanTelemetryField.ArmFeedForward).disable();
    }
    if (config.getElevatorFeedforward(smc.getClosedLoopControllerSlot()).isEmpty()) {
      boolFields.get(BooleanTelemetryField.ElevatorFeedForward).disable();
    }
    if (config.getSimpleFeedforward(smc.getClosedLoopControllerSlot()).isEmpty()) {
      boolFields.get(BooleanTelemetryField.SimpleMotorFeedForward).disable();
    }
    if (config.getMotorInverted().isPresent()) {
      boolFields.get(BooleanTelemetryField.MotorInversion).setDefaultValue(config.getMotorInverted().get());
    } else {
      boolFields.get(BooleanTelemetryField.MotorInversion).disable();
    }
    if (config.getEncoderInverted().isPresent()) {
      boolFields.get(BooleanTelemetryField.EncoderInversion).setDefaultValue(config.getEncoderInverted().get());
    } else {
      boolFields.get(BooleanTelemetryField.EncoderInversion).disable();
    }
    return boolFields;
  }

  /**
   * Enables the mechanism lower limit logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMechanismLowerLimit() {
    boolFields.get(BooleanTelemetryField.MechanismLowerLimit).enable();
    return this;
  }

  /**
   * Enables the mechanism upper limit logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMechanismUpperLimit() {
    boolFields.get(BooleanTelemetryField.MechanismUpperLimit).enable();
    return this;
  }

  /**
   * Enables the temperature limit logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withTemperatureLimit() {
    boolFields.get(BooleanTelemetryField.TemperatureLimit).enable();
    return this;
  }

  /**
   * Enables the velocity control mode logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withVelocityControl() {
    boolFields.get(BooleanTelemetryField.VelocityControl).enable();
    return this;
  }

  /**
   * Enables the elevator feedforward logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withElevatorFeedforward() {
    boolFields.get(BooleanTelemetryField.ElevatorFeedForward).enable();
    return this;
  }

  /**
   * Enables the arm feedforward logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withArmFeedforward() {
    boolFields.get(BooleanTelemetryField.ArmFeedForward).enable();
    return this;
  }

  /**
   * Enables the simple feedforward logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withSimpleFeedforward() {
    boolFields.get(BooleanTelemetryField.SimpleMotorFeedForward).enable();
    return this;
  }

  /**
   * Enables the motion profile logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMotionProfile() {
    boolFields.get(BooleanTelemetryField.MotionProfile).enable();
    return this;
  }

  /**
   * Enables the setpoint position logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withSetpointPosition() {
    doubleFields.get(DoubleTelemetryField.SetpointPosition).enable();
    return this;
  }

  /**
   * Enables the setpoint velocity logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withSetpointVelocity() {
    doubleFields.get(DoubleTelemetryField.SetpointVelocity).enable();
    return this;
  }

  /**
   * Enables the setpoint feedforward force logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withSetpointForce() {
    doubleFields.get(DoubleTelemetryField.SetpointForce).enable();
    return this;
  }

  /**
   * Enables logging how far behind the mechanism the measured velocity is, when it is known.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withVelocityMeasurementDelay() {
    doubleFields.get(DoubleTelemetryField.VelocityMeasurementDelay).enable();
    return this;
  }

  /**
   * Enables logging the period the closed loop controller runs at.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withClosedLoopPeriod() {
    doubleFields.get(DoubleTelemetryField.ClosedLoopPeriod).enable();
    return this;
  }

  /**
   * Enables the output voltage logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withOutputVoltage() {
    doubleFields.get(DoubleTelemetryField.OutputVoltage).enable();
    return this;
  }

  /**
   * Enables the stator current logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withStatorCurrent() {
    doubleFields.get(DoubleTelemetryField.StatorCurrent).enable();
    return this;
  }

  /**
   * Enables the temperature logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withTemperature() {
    doubleFields.get(DoubleTelemetryField.MotorTemperature).enable();
    return this;
  }

  /**
   * Enables the distance logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMeasurementPosition() {
    doubleFields.get(DoubleTelemetryField.MeasurementPosition).enable();
    return this;
  }

  /**
   * Enables logging the mechanism's circumference if it has one, so a log can convert a rotor
   * reading to meters.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMeasurementCircumference() {
    doubleFields.get(DoubleTelemetryField.MeasurementCircumference).enable();
    return this;
  }

  /**
   * Enables the linear velocity logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMeasurementVelocity() {
    doubleFields.get(DoubleTelemetryField.MeasurementVelocity).enable();
    return this;
  }

  /**
   * Enables the mechanism position logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMechanismPosition() {
    doubleFields.get(DoubleTelemetryField.MechanismPosition).enable();
    return this;
  }

  /**
   * Enables the mechanism velocity logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withMechanismVelocity() {
    doubleFields.get(DoubleTelemetryField.MechanismVelocity).enable();
    return this;
  }

  /**
   * Enables the rotor position logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withRotorPosition() {
    doubleFields.get(DoubleTelemetryField.RotorPosition).enable();
    return this;
  }

  /**
   * Enables logging the gear ratio, rotor rotations per mechanism rotation, so a log can convert a
   * rotor reading to the mechanism's.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withRotorGearRatio() {
    doubleFields.get(DoubleTelemetryField.RotorGearRatio).enable();
    return this;
  }

  /**
   * Enables the rotor velocity logging if available.
   *
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining.
   */
  public SmartMotorControllerTelemetryConfig withRotorVelocity() {
    doubleFields.get(DoubleTelemetryField.RotorVelocity).enable();
    return this;
  }

  /**
   * Escape hatch for unimplemented fields which should be enabled or disabled.
   *
   * @param field Field to configure
   * @param value Enable on true, Disable on false.
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining
   */
  public SmartMotorControllerTelemetryConfig withCustom(DoubleTelemetryField field, boolean value) {
    if (value)
      doubleFields.get(field).enable();
    else
      doubleFields.get(field).disable();
    return this;
  }

  /**
   * Escape hatch for unimplemented fields which should be enabled or disabled.
   *
   * @param field Field to configure
   * @param value Enable on true, Disable on false.
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining
   */
  public SmartMotorControllerTelemetryConfig withCustom(BooleanTelemetryField field, boolean value) {
    if (value)
      boolFields.get(field).enable();
    else
      boolFields.get(field).disable();
    return this;
  }

  /**
   * Escape hatch for unimplemented fields which should be enabled or disabled.
   *
   * @param field Field to configure
   * @param value Enable on true, Disable on false.
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining
   */
  public SmartMotorControllerTelemetryConfig withCustom(BooleanTelemetryField[] field, boolean value) {
    for (BooleanTelemetryField field1 : field) {
      withCustom(field1, value);
    }
    return this;
  }

  /**
   * Escape hatch for unimplemented fields which should be enabled or disabled.
   *
   * @param field Field to configure
   * @param value Enable on true, Disable on false.
   * @return {@link SmartMotorControllerTelemetryConfig} for chaining
   */
  public SmartMotorControllerTelemetryConfig withCustom(DoubleTelemetryField[] field, boolean value) {
    for (DoubleTelemetryField field1 : field) {
      withCustom(field1, value);
    }
    return this;
  }
}
