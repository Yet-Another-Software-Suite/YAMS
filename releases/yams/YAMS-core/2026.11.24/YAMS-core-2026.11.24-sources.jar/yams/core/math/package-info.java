// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

/**
 * Yet Another Mechanism System math classes for easier calculations.
 *
 * <p>This package contains control-theory math utilities used internally by YAMS mechanisms and
 * available for direct use by teams that need low-level control primitives. All classes are
 * designed to integrate seamlessly with WPILib 2026 unit types and the rest of the YAMS API.
 *
 * <h2>Class Overview</h2>
 *
 * <ul>
 * <li><b>{@link yams.core.math.LQRController}</b> and <b>{@link yams.core.math.LQRConfig}</b> —
 * implement discrete Linear Quadratic Regulator (LQR) control. {@code LQRConfig} holds the Q (state
 * cost) and R (input cost) weighting matrices along with the plant model; {@code LQRController}
 * solves the discrete algebraic Riccati equation at construction time and exposes a
 * {@code calculate()} method suitable for calling from a periodic loop. <li><b>
 * {@link yams.core.math.DerivativeTimeFilter}</b> computes a filtered derivative estimate for use
 * as the D term in PID controllers. Rather than a raw finite difference (which amplifies sensor
 * noise), this class applies a configurable low-pass filter to the derivative signal, trading off
 * noise rejection against phase lag. <li><b>{@link yams.core.math.SmartMath}</b> a collection of
 * static helper methods for common control-theory and unit-conversion tasks (clamping,
 * interpolation, wrapping angles, etc.) that do not belong to a specific controller class. <li><b>
 * {@link yams.core.math.ExponentialProfilePIDController}</b> a profiled PID variant that uses an
 * exponential motion profile to generate setpoints. Compared to a trapezoidal profile, the
 * exponential profile produces smoother acceleration transitions and is less prone to
 * overshoot on mechanisms with significant inertia. <li><b>
 * {@link yams.core.math.ADRCController}</b> and <b>{@link
 * yams.core.math.TrackingDifferentiator}</b> implement active disturbance rejection control: the
 * controller estimates the total disturbance (friction, back-EMF, loads) with an extended state
 * observer and cancels it, so the closed loop settles in the requested time from only a plant order
 * and an approximate input gain. The tracking differentiator smooths step references and supplies
 * their derivatives. Teams usually configure both through {@link yams.core.math.ADRCConfig} rather
 * than constructing them directly.
 * </ul>
 *
 * <h2>Example LQR Setup</h2>
 *
 * <pre>{@code
 * // Build a config for a single-state, single-input system (e.g., flywheel velocity).
 * LQRConfig config = new LQRConfig()
 *     .withQWeights(1.0)   // state cost: penalise velocity error
 *     .withRWeights(12.0)  // input cost: penalise voltage
 *     .withPlant(plant);   // LinearSystem from SysId or known constants
 *
 * LQRController lqr = new LQRController(config);
 *
 * // In periodic():
 * double voltage = lqr.calculate(currentVelocity, goalVelocity);
 * motor.setVoltage(voltage);
 * }</pre>
 *
 * <h2>Example Filtered Derivative</h2>
 *
 * <pre>{@code
 * DerivativeTimeFilter dFilter = new DerivativeTimeFilter(0.02 /* dt seconds *\/);
 *
 * // In periodic():
 * double filteredDeriv = dFilter.calculate(measurement);
 * }</pre>
 *
 * @see yams.core.math.LQRController
 * @see yams.core.math.LQRConfig
 * @see yams.core.math.DerivativeTimeFilter
 * @see yams.core.math.SmartMath
 * @see yams.core.math.ExponentialProfilePIDController
 * @see yams.core.math.ADRCController
 * @see yams.core.math.TrackingDifferentiator
 */
package yams.core.math;
