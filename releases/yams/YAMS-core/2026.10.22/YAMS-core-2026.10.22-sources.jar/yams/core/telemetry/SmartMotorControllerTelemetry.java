// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.core.telemetry;

import static org.wpilib.units.Units.Amps;
import static org.wpilib.units.Units.Degrees;
import static org.wpilib.units.Units.Fahrenheit;
import static org.wpilib.units.Units.Meters;
import static org.wpilib.units.Units.MetersPerSecond;
import static org.wpilib.units.Units.MetersPerSecondPerSecond;
import static org.wpilib.units.Units.Newtons;
import static org.wpilib.units.Units.RPM;
import static org.wpilib.units.Units.Rotations;
import static org.wpilib.units.Units.RotationsPerSecond;
import static org.wpilib.units.Units.RotationsPerSecondPerSecond;
import static org.wpilib.units.Units.Second;
import static org.wpilib.units.Units.Seconds;
import static org.wpilib.units.Units.Volts;

import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import org.wpilib.networktables.NetworkTable;
import yams.core.exceptions.SmartMotorControllerConfigurationException;
import yams.core.motorcontrollers.SmartMotorController.ClosedLoopControllerSlot;
import yams.core.motorcontrollers.SmartMotorController;
import yams.core.motorcontrollers.SmartMotorControllerConfig;
import yams.core.motorcontrollers.enums.ControlMode;

/**
 * Smart motor controller telemetry.
 *
 * <p>Publishes motor controller state including duty-cycle output voltage, stator/supply current,
 * rotor/mechanism position and velocity, and motor temperature to NetworkTables so that tools
 * such as SmartDashboard, Elastic, and Advantage Scope can consume the data in real time. Tunable
 * fields (PID gains, setpoints, motion-profile limits) are additionally exposed on a separate
 * {@code Tuning} table so they can be adjusted without redeploying code.
 *
 * <p>This class is managed internally by {@link SmartMotorController}. You do not normally
 * instantiate it directly; instead call the methods on the motor controller itself:
 *
 * <h2>Basic usage (default NetworkTable path)</h2>
 *
 * <pre>{@code
 * // In robotInit() or subsystem constructor:
 * motor.setupTelemetry();   // publishes under Mechanisms/<motorName>
 *
 * // In robotPeriodic() or subsystemPeriodic():
 * motor.updateTelemetry();
 * }</pre>
 *
 * <h2>Custom NetworkTable path and telemetry config</h2>
 *
 * <pre>{@code
 * NetworkTable dataTable   =
 * NetworkTableInstance.getDefault().getTable("Mechanisms").getSubTable("Shooter"); NetworkTable
 * tuningTable = NetworkTableInstance.getDefault().getTable("Tuning").getSubTable("Shooter");
 *
 * motor.setupTelemetry(dataTable, tuningTable);
 *
 * // In periodic:
 * motor.updateTelemetry();
 * }</pre>
 */
public class SmartMotorControllerTelemetry {
  /** Double telemetry fields that will be outputted. */
  private Map<DoubleTelemetryField, DoubleTelemetry<DoubleTelemetryField>> doubleFields;
  /** Boolean telemetry fields that will be outputted. */
  private Map<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> boolFields;
  /** Network table to publish to. */
  private NetworkTable dataNetworkTable;
  /** Network table for tuning. */
  private NetworkTable tuningNetworkTable;
  /** Telemetry config */
  private SmartMotorControllerTelemetryConfig config;

  /** Create motor controller telemetry, publish it with {@link #setupTelemetry}. */
  public SmartMotorControllerTelemetry() {}

  /**
   * Setup Telemetry Pub/Sub fields.
   *
   * @param smartMotorController {@link SmartMotorController} used to determine what telemetry
   *                             features can and should be disabled bc they are not available.
   * @param publishTable         {@link NetworkTable} that holds all of the output fields.
   * @param tuningTable          {@link NetworkTable} that holds all of the tuning fields.
   * @param config               {@link SmartMotorControllerTelemetryConfig} to apply.
   */
  public void setupTelemetry(SmartMotorController smartMotorController, NetworkTable publishTable, NetworkTable tuningTable, SmartMotorControllerTelemetryConfig config) {
    if (!publishTable.equals(this.dataNetworkTable)) {
      dataNetworkTable = publishTable;
      tuningNetworkTable = tuningTable;
      SmartMotorControllerConfig<?> smcConfig = smartMotorController.getConfig();
      this.config = config;
      doubleFields = config.getDoubleFields(smartMotorController);
      boolFields = config.getBoolFields(smartMotorController);
      for (Map.Entry<DoubleTelemetryField, DoubleTelemetry<DoubleTelemetryField>> entry : doubleFields.entrySet()) {
        if (!entry.getValue().enabled)
          continue;
        if (config.getNT4Enabled()) {
          entry.getValue().transformUnit(smcConfig).setupNetworkTables(dataNetworkTable, tuningNetworkTable);
        }
        config.getDataLogName().ifPresent(name -> entry.getValue().transformUnit(smcConfig).setupDataLog(name));
      }
      for (Map.Entry<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> entry : boolFields.entrySet()) {
        if (!entry.getValue().enabled)
          continue;
        if (config.getNT4Enabled()) {
          entry.getValue().setupNetworkTables(dataNetworkTable, tuningNetworkTable);
        }
        config.getDataLogName().ifPresent(name -> entry.getValue().setupDataLog(name));
      }
    }
  }

  /**
   * Publish {@link SmartMotorController} telemetry to {@link NetworkTable}
   *
   * @param smc Smart motor controller to publish telemetry for.
   */
  public void publish(SmartMotorController smc) {
    SmartMotorControllerConfig<?> cfg = smc.getConfig();
    for (Map.Entry<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> entry : boolFields.entrySet()) {
      BooleanTelemetry<BooleanTelemetryField> bt = entry.getValue();
      if (!bt.enabled) {
        continue;
      }
      switch (bt.getField()) {
        case MechanismUpperLimit -> cfg.getMechanismUpperLimit().ifPresent(upperLimit -> bt.set(smc.getMechanismPosition().gte(upperLimit)));
        case MechanismLowerLimit -> cfg.getMechanismLowerLimit().ifPresent(lowerLimit -> bt.set(smc.getMechanismPosition().lte(lowerLimit)));
        case TemperatureLimit -> cfg.getTemperatureCutoff().ifPresent(temperatureCutoff -> bt.set(smc.getTemperature().gte(temperatureCutoff)));
        case VelocityControl -> bt.set(smc.getMechanismSetpointVelocity().isPresent());
        case ElevatorFeedForward -> bt.set(cfg.getElevatorFeedforward(smc.getClosedLoopControllerSlot()).isPresent());
        case ArmFeedForward -> bt.set(cfg.getArmFeedforward(smc.getClosedLoopControllerSlot()).isPresent());
        case SimpleMotorFeedForward -> bt.set(cfg.getSimpleFeedforward(smc.getClosedLoopControllerSlot()).isPresent());
        case MotionProfile -> bt.set(cfg.getExponentialProfile().isPresent() || cfg.getTrapezoidProfile().isPresent());
      }
    }
    for (Map.Entry<DoubleTelemetryField, DoubleTelemetry<DoubleTelemetryField>> entry : doubleFields.entrySet()) {
      DoubleTelemetry<DoubleTelemetryField> dt = entry.getValue();
      if (!dt.enabled) {
        continue;
      }
      switch (dt.getField()) {
        case SetpointPosition -> {
          smc.getMechanismPositionSetpoint().ifPresent(mechSetpoint -> dt.set(cfg.getLinearClosedLoopControllerUse() ? cfg.convertFromMechanism(mechSetpoint).in(Meters) : mechSetpoint.in(Rotations)));
          break;
        }
        case SetpointVelocity -> {
          smc.getMechanismSetpointVelocity().ifPresent(mechSetpoint -> dt.set(cfg.getLinearClosedLoopControllerUse() ? cfg.convertFromMechanism(mechSetpoint).in(MetersPerSecond) : mechSetpoint.in(RotationsPerSecond)));
        }
        case SetpointForce -> dt.set(smc.getSetpointFeedforwardForce().orElse(Newtons.zero()).in(Newtons));
        case ClosedLoopPeriod -> dt.set(smc.getClosedLoopControllerPeriod().in(Seconds));
        case VelocityMeasurementDelay -> smc.getVelocityMeasurementDelay().ifPresent(delay -> dt.set(delay.in(Seconds)));
        case OutputVoltage -> dt.set(smc.getVoltage().in(Volts));
        case StatorCurrent -> dt.set(smc.getStatorCurrent().in(Amps));
        case SupplyCurrent -> smc.getSupplyCurrent().ifPresent(current -> dt.set(current.in(Amps)));
        case MotorTemperature -> dt.set(smc.getTemperature().in(Fahrenheit));
        case MeasurementPosition -> cfg.getMechanismCircumference().ifPresent(circumference -> dt.set(smc.getMeasurementPosition().in(Meters)));
        case MeasurementVelocity -> cfg.getMechanismCircumference().ifPresent(circumference -> dt.set(smc.getMeasurementVelocity().in(MetersPerSecond)));
        case MeasurementAcceleration -> cfg.getMechanismCircumference().ifPresent(c -> dt.set(smc.getMeasurementAcceleration().in(MetersPerSecondPerSecond)));
        case MechanismPosition -> dt.set(smc.getMechanismPosition().in(Rotations));
        case MechanismVelocity -> dt.set(smc.getMechanismVelocity().in(RotationsPerSecond));
        case MechanismAcceleration -> dt.set(smc.getMechanismAcceleration().in(RotationsPerSecondPerSecond));
        case RotorPosition -> dt.set(smc.getRotorPosition().in(Rotations));
        case RotorVelocity -> dt.set(smc.getRotorVelocity().in(RotationsPerSecond));
        case ExternalEncoderPosition -> dt.set(smc.getExternalEncoderMechanismPosition().orElse(Rotations.zero()).in(Rotations));
        case ExternalEncoderVelocity -> dt.set(smc.getExternalEncoderMechanismVelocity().orElse(RotationsPerSecond.zero()).in(RotationsPerSecond));
        case ActiveClosedLoopControllerSlot -> dt.set(smc.getClosedLoopControllerSlot().ordinal());
      }
    }
  }

  /**
   * Apply the tuning values from {@link NetworkTable} to the {@link SmartMotorController}
   *
   * @param smartMotorController {@link SmartMotorController} to control.
   * @throws SmartMotorControllerConfigurationException if the controller's control mode is not
   *                                                    {@code CLOSED_LOOP}.
   * @throws SmartMotorControllerConfigurationException if the underlying motor controller
   *                                                    implementation rejects a tuned gain (for
   *                                                    example, a gain applied while slot 3 is
   *                                                    active on a TalonFX).
   * @throws SmartMotorControllerConfigurationException if the underlying motor controller
   *                                                    implementation rejects an unsupported
   *                                                    vendor control request when applying a
   *                                                    setpoint or slot.
   * @throws IllegalArgumentException                   if the tuned closed loop controller slot is
   *                                                    not supported by the underlying motor
   *                                                    controller implementation (for example, slot
   *                                                    3 on a TalonFX or TalonFXS).
   */
  public void applyTuningValues(SmartMotorController smartMotorController) {
    SmartMotorControllerConfig<?> cfg = smartMotorController.getConfig();
    if (cfg.getMotorControllerMode() != ControlMode.CLOSED_LOOP) {
      throw new SmartMotorControllerConfigurationException("Live tuning does not work in OPEN_LOOP", "Cannot apply setpoints for Live Tuning.", ".withControlMode(ControlMode.CLOSED_LOOP) instead of " + ".withControlMode(ControlMode.OPEN_LOOP)");
    }
    boolean closedloop = true;
    for (Map.Entry<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> entry : boolFields.entrySet()) {
      BooleanTelemetry<BooleanTelemetryField> bt = entry.getValue();
      boolean tunable = bt.tunable();
      if (!bt.enabled || !config.getNT4Enabled())
        continue;
      switch (bt.getField()) {
        case TunableVoltageEnabled -> closedloop = !bt.get();
      }

      if (tunable) {
        switch (bt.getField()) {
          case MotorInversion -> smartMotorController.setMotorInverted(bt.get());
          case EncoderInversion -> smartMotorController.setEncoderInverted(bt.get());
          case TunableVoltageEnabled -> {
            if (closedloop) {
              smartMotorController.setVoltage(Volts.zero());
              smartMotorController.getLooselyCoupledFollowers().ifPresent(followers -> {
                for (var follower : followers) {
                  follower.setVoltage(Volts.zero());
                }
              });
              smartMotorController.startClosedLoopController();
              // The voltage replaced the setpoint on a closed loop controller run on the motor controller, so it
              // must be sent again. This sends it to the loosely coupled followers too.
              var position = smartMotorController.getMechanismPositionSetpoint();
              if (position.isPresent()) {
                smartMotorController.setPosition(position.get());
              } else {
                smartMotorController.getMechanismSetpointVelocity().ifPresent(smartMotorController::setVelocity);
              }
            } else {
              smartMotorController.stopClosedLoopController();
              // Start at 0 V, with voltage/setpoint set back to 0 on the dashboard too.
              doubleFields.get(DoubleTelemetryField.TunableVoltage).forceSet(0);
              smartMotorController.getLooselyCoupledFollowers().ifPresent(followers -> {
                for (var follower : followers) {
                  follower.setVoltage(Volts.zero());
                }
              });
              smartMotorController.setVoltage(Volts.zero());
            }
          }
        }
      }
    }
    for (Map.Entry<DoubleTelemetryField, DoubleTelemetry<DoubleTelemetryField>> entry : doubleFields.entrySet()) {
      DoubleTelemetry<DoubleTelemetryField> dt = entry.getValue();
      if (!dt.enabled)
        continue;

      // Fields that must be set regularly.
      switch (dt.getField()) {
        case TunableVoltage -> {
          if (closedloop)
            continue;

          smartMotorController.getLooselyCoupledFollowers().ifPresent(followers -> {
            for (SmartMotorController follower : followers) {
              follower.setVoltage(Volts.of(dt.get()));
            }
          });
          smartMotorController.setVoltage(Volts.of(dt.get()));
        }
      }
      if (dt.tunable()) {
        switch (dt.getField()) {
          case TunableClosedLoopControllerSlot -> {
            if (dt.get() >= 0 && dt.get() < ClosedLoopControllerSlot.values().length) {
              var slot = ClosedLoopControllerSlot.values()[(int) dt.get()];
              if (!smartMotorController.getClosedLoopControllerSlot().equals(slot)) {
                smartMotorController.setClosedLoopSlot(slot);
              }
            }
          }
          case TunableSetpointPosition -> {
            if (!closedloop) {
              continue;
            }
            if (cfg.getLinearClosedLoopControllerUse()) {
              smartMotorController.setPosition(Meters.of(dt.get()));
            } else {
              smartMotorController.setPosition(Degrees.of(dt.get()));
            }
            break;
          }
          case TunableSetpointVelocity -> {
            if (dt.get() == 0 || !closedloop) {
              continue;
            }
            if (cfg.getLinearClosedLoopControllerUse()) {
              smartMotorController.setVelocity(MetersPerSecond.of(dt.get()));
            } else {
              smartMotorController.setVelocity(dt.get() == 0 ? null : RPM.of(dt.get()));
            }
            break;
          }
          case kP -> smartMotorController.setKp(dt.get());
          case kI -> smartMotorController.setKi(dt.get());
          case kD -> smartMotorController.setKd(dt.get());
          case kS -> smartMotorController.setKs(dt.get());
          case kV -> smartMotorController.setKv(dt.get());
          case kA -> smartMotorController.setKa(dt.get());
          case kG -> smartMotorController.setKg(dt.get());
          case ClosedloopRampRate -> smartMotorController.setClosedLoopRampRate(Seconds.of(dt.get()));
          case OpenloopRampRate -> smartMotorController.setOpenLoopRampRate(Seconds.of(dt.get()));
          case SupplyCurrentLimit -> smartMotorController.setSupplyCurrentLimit(Amps.of(dt.get()));
          case StatorCurrentLimit -> smartMotorController.setStatorCurrentLimit(Amps.of(dt.get()));
          case MeasurementUpperLimit -> smartMotorController.setMeasurementUpperLimit(Meters.of(dt.get()));
          case MeasurementLowerLimit -> smartMotorController.setMeasurementLowerLimit(Meters.of(dt.get()));
          case MechanismUpperLimit -> smartMotorController.setMechanismUpperLimit(Degrees.of(dt.get()));
          case MechanismLowerLimit -> smartMotorController.setMechanismLowerLimit(Degrees.of(dt.get()));
          case TrapezoidalProfileMaxAcceleration -> {
            if (cfg.getLinearClosedLoopControllerUse()) {
              smartMotorController.setMotionProfileMaxAcceleration(MetersPerSecondPerSecond.of(dt.get()));

            } else {
              smartMotorController.setMotionProfileMaxAcceleration(RPM.per(Second).of(dt.get()));
            }
            break;
          }
          case TrapezoidalProfileMaxVelocity -> {
            if (cfg.getLinearClosedLoopControllerUse()) {
              smartMotorController.setMotionProfileMaxVelocity(MetersPerSecond.of(dt.get()));
            } else {
              smartMotorController.setMotionProfileMaxVelocity(RPM.of(dt.get()));
            }
            break;
          }
          case TrapezoidalProfileMaxJerk -> {
            smartMotorController.setMotionProfileMaxJerk(RPM.per(Second).per(Second).of(dt.get()));
          }
          case ExponentialProfileKA -> {
            smartMotorController.setExponentialProfile(OptionalDouble.empty(), OptionalDouble.of(dt.get()), Optional.empty());
          }
          case ExponentialProfileKV -> {
            smartMotorController.setExponentialProfile(OptionalDouble.of(dt.get()), OptionalDouble.empty(), Optional.empty());
          }
          case ExponentialProfileMaxInput -> {
            smartMotorController.setExponentialProfile(OptionalDouble.empty(), OptionalDouble.empty(), Optional.of(Volts.of(dt.get())));
          }
        }
      }
    }
  }

  /**
   * Stop live tuning, as when the "Live Tuning" command ends. A tuning voltage stops and the closed
   * loop controller holds the setpoint again. The voltage is turned off in the Tuning table too, so
   * it is not applied again as soon as live tuning starts again.
   *
   * @param smartMotorController {@link SmartMotorController} being tuned.
   */
  public void stopTuning(SmartMotorController smartMotorController) {
    if (boolFields == null) {
      return;
    }
    for (Map.Entry<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> entry : boolFields.entrySet()) {
      BooleanTelemetry<BooleanTelemetryField> bt = entry.getValue();
      switch (bt.getField()) {
        case TunableVoltageEnabled -> {
          if (bt.enabled && config.getNT4Enabled() && bt.get()) {
            bt.forceSet(false);
            applyTuningValues(smartMotorController);
          }
        }
      }
    }
  }

  /** Close and unpublish telemetry. */
  public void close() {
    if (doubleFields != null) {
      for (Map.Entry<DoubleTelemetryField, DoubleTelemetry<DoubleTelemetryField>> entry : doubleFields.entrySet()) {
        entry.getValue().close();
      }
    }
    if (boolFields != null) {
      for (Map.Entry<BooleanTelemetryField, BooleanTelemetry<BooleanTelemetryField>> entry : boolFields.entrySet()) {
        entry.getValue().close();
      }
    }
  }

  /**
   * Whether or not tuning is enabled.
   *
   * @return Checks if {@link DoubleTelemetryField#TunableSetpointPosition} or
   *         {@link DoubleTelemetryField#TunableSetpointVelocity} are enabled.
   */
  public boolean tuningEnabled() {
    return doubleFields.get(DoubleTelemetryField.TunableSetpointPosition).enabled || doubleFields.get(DoubleTelemetryField.TunableSetpointVelocity).enabled;
  }

  /** Boolean telemetry for {@link SmartMotorController}s */
  public enum BooleanTelemetryField {
    /** Mechanism upper limit */
    MechanismUpperLimit("limits/mechanism/upper", false, false),
    /** Mechanism lower limit. */
    MechanismLowerLimit("limits/mechanism/lower", false, false),
    /** Temperature limit if available. */
    TemperatureLimit("limits/temperature", false, false),
    /** Velocity control currently getting used. */
    VelocityControl("control/closedloop/velocity", false, false),
    /** Elevator feedforward currently getting used. */
    ElevatorFeedForward("control/feedforward/elevator", false, false),
    /** Arm feedforward currently getting used. */
    ArmFeedForward("control/feedforward/arm", false, false),
    /** Simple motor feedforward currently getting used. */
    SimpleMotorFeedForward("control/feedforward/simple", false, false),
    /** Motion profile currently getting used. */
    MotionProfile("control/closedloop/profiled", false, false),
    /** Motor inversion. */
    MotorInversion("motor/inverted", false, true),
    /** Encoder inversion. */
    EncoderInversion("encoder/inverted", false, true),
    /**
     * Drive the motor and its loosely coupled followers at {@link DoubleTelemetryField#TunableVoltage}
     * instead of the closed loop controller while on.
     */
    TunableVoltageEnabled("voltage/enabled", false, true);

    /** Default value of the boolean telemetry field. */
    private final boolean currentValue;

    /** Key that the telemetry is stored at. */
    private final String key;

    /** Tunable field? */
    private final boolean tunable;

    /**
     * Create a boolean telemetry field.
     *
     * @param fieldName    Field for {@link NetworkTable}
     * @param defaultValue Default value in NT.
     * @param tunable      Tunable field.
     */
    BooleanTelemetryField(String fieldName, boolean defaultValue, boolean tunable) {
      key = fieldName;
      currentValue = defaultValue;
      this.tunable = tunable;
    }

    /**
     * Create a {@link BooleanTelemetry} object for non-static usage.
     *
     * @return {@link BooleanTelemetry}
     */
    public BooleanTelemetry<BooleanTelemetryField> create() {
      return new BooleanTelemetry<>(key, currentValue, this, tunable);
    }
  }


  /** Double telemetry field. */
  public enum DoubleTelemetryField {
    /** Exponential profile kV */
    ExponentialProfileKV("closedloop/motionprofile/kV", 0, true, "none"),
    /** Exponential profile kA */
    ExponentialProfileKA("closedloop/motionprofile/kA", 0, true, "none"),
    /** Exponential profile maxInput */
    ExponentialProfileMaxInput("closedloop/motionprofile/maxInput", 12, true, "volts"),
    /** Motion profile maximum velocity, could be in MPS or RPM */
    TrapezoidalProfileMaxVelocity("closedloop/motionprofile/maxVelocity", 0, true, "tunable_velocity"),
    /** Motion profile maximum accelerartion, could be in MPS^2 or RPM/s */
    TrapezoidalProfileMaxAcceleration("closedloop/motionprofile/maxAcceleration", 0, true, "tunable_acceleration"),
    /** Trapezoidal profile maximum jerk, could be in MPS^3 or RPM/s^2 */
    TrapezoidalProfileMaxJerk("closedloop/motionprofile/maxJerk", 0, true, "rotations_per_minute_per_second_per_second"),
    /** Closed loop controller slot. */
    TunableClosedLoopControllerSlot("closedloop/slot", 0, true, "none"),
    /** Active closed loop controller slot. */
    ActiveClosedLoopControllerSlot("closedloop/slot", 0, false, "none"),
    /** kS */
    kS("closedloop/feedforward/kS", 0, true, "none"),
    /** kV */
    kV("closedloop/feedforward/kV", 0, true, "none"),
    /** kA */
    kA("closedloop/feedforward/kA", 0, true, "none"),
    /** kG */
    kG("closedloop/feedforward/kG", 0, true, "none"),
    /** kP */
    kP("closedloop/feedback/kP", 0, true, "none"),
    /** kI */
    kI("closedloop/feedback/kI", 0, true, "none"),
    /** kD */
    kD("closedloop/feedback/kD", 0, true, "none"),
    /** Setpoint position */
    TunableSetpointPosition("closedloop/setpoint/position", 0, true, "tunable_position"),
    /** Setpoint position */
    SetpointPosition("closedloop/setpoint/position", 0, false, "position"),
    /** Setpoint velocity */
    TunableSetpointVelocity("closedloop/setpoint/velocity", 0, true, "tunable_velocity"),
    /** Setpoint velocity */
    SetpointVelocity("closedloop/setpoint/velocity", 0, false, "velocity"),
    /** Setpoint feedforward force, e.g. from a PathPlanner set-point generator. */
    SetpointForce("closedloop/setpoint/force", 0, false, "newtons"),
    /**
     * Period the closed loop controller runs at: 1 ms on the motor controller, or the closed loop
     * control period on the SystemCore.
     */
    ClosedLoopPeriod("closedloop/period", 0.02, false, "seconds"),
    /**
     * How far behind the mechanism the measured velocity is, from how the motor controller filters it,
     * when it is known.
     */
    VelocityMeasurementDelay("closedloop/measurementDelay", 0, false, "seconds"),
    /**
     * Tunable voltage applied to the motor and its loosely coupled followers, without the closed loop
     * controller, while {@link BooleanTelemetryField#TunableVoltageEnabled} is on.
     */
    TunableVoltage("voltage/setpoint", 0, true, "volts"),
    /** Voltage supplied to the motor. */
    OutputVoltage("motor/outputVoltage", 0, false, "volts"),
    /** Stator current. */
    StatorCurrent("current/stator", 0, false, "amps"),
    /** Supply current limit. */
    StatorCurrentLimit("current/limit/stator", 0, true, "amps"),
    /** Supply current. */
    SupplyCurrent("current/supply", 0, false, "amps"),
    /** Supply current limit. */
    SupplyCurrentLimit("current/limit/supply", 0, true, "amps"),
    /** Motor temperature */
    MotorTemperature("motor/temperature", 0, false, "fahrenheit"),
    /** Measurement position */
    MeasurementPosition("measurement/position", 0, false, "meters"),
    /** Measurement velocity. */
    MeasurementVelocity("measurement/velocity", 0, false, "meters_per_second"),
    /** Measurement acceleration. */
    MeasurementAcceleration("measurement/acceleration", 0, false, "meters_per_second_per_second"),
    /** Measurement lower limit. */
    MeasurementLowerLimit("measurement/limit/lower", 0, true, "meters"),
    /** Measurement upper limit. */
    MeasurementUpperLimit("measurement/limit/upper", 0, true, "meters"),
    /** Mechanism position in rotations. */
    MechanismPosition("mechanism/position", 0, false, "rotations"),
    /** Mechanism velocity in rotations per second. */
    MechanismVelocity("mechanism/velocity", 0, false, "rotations_per_second"),
    /** Mechanism acceleration in rotations per second per second. */
    MechanismAcceleration("mechanism/acceleration", 0, false, "rotations_per_second_per_second"),
    /** Mechanism lower limit in rotations. */
    MechanismLowerLimit("mechanism/limit/lower", 0, true, "degrees"),
    /** Mechanism upper limit in rotations. */
    MechanismUpperLimit("mechanism/limit/upper", 0, true, "degrees"),
    /** Rotor position in rotations. */
    RotorPosition("rotor/position", 0, false, "rotations"),
    /** Rotor velocity in rotations. */
    RotorVelocity("rotor/velocity", 0, false, "rotations_per_second"),
    /** External encoder's mechanism position in rotations, published only when an external encoder is defined. */
    ExternalEncoderPosition("externalencoder/position", 0, false, "rotations"),
    /** External encoder's mechanism velocity in rotations per second, published only when an external encoder is defined. */
    ExternalEncoderVelocity("externalencoder/velocity", 0, false, "rotations_per_second"),
    /** Closed loop dutycyle ramp rate. */
    ClosedloopRampRate("ramprate/dutycycle/closedloop", 0, true, "seconds"),
    /** Open loop dutycycle ramp rate. */
    OpenloopRampRate("ramprate/dutycycle/openloop", 0, true, "seconds");

    private final double  defaultVal;
    private final String  key;
    private final boolean tunable;
    private final String  unit;

    /**
     * Create double telemetry field.
     *
     * @param fieldName    NT Field Name
     * @param defaultValue Default value
     * @param tunable      Tunable places it only in the Tuning Table.
     * @param unit         Unit of the telemetry field. Special types are "position", velocity", and
     *                     "acceleration".
     */
    DoubleTelemetryField(String fieldName, double defaultValue, boolean tunable, String unit) {
      key = fieldName;
      defaultVal = defaultValue;
      this.tunable = tunable;
      this.unit = unit;
    }

    /**
     * Create double telemetry field.
     *
     * @return Double telemetry field.
     */
    public DoubleTelemetry<DoubleTelemetryField> create() {
      return new DoubleTelemetry<>(key, defaultVal, this, tunable, unit);
    }
  }
}
