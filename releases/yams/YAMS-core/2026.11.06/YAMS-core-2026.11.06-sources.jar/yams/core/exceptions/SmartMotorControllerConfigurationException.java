// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.core.exceptions;

/**
 * Thrown by {@link yams.core.motorcontrollers.SmartMotorControllerConfig} or a
 * {@link yams.core.motorcontrollers.SmartMotorController} wrapper when the applied configuration contains
 * conflicting, incomplete, or incompatible settings.
 *
 * <p>Common triggers include:
 *
 * <ul>
 * <li>{@code withSubsystem(Subsystem)} called more than once on the same config
 * <li>Auto-synchronization threshold set while a distance-based (linear) mechanism circumference
 * is configured the two options are mutually exclusive
 * <li>Mechanism circumference undefined when a conversion method (e.g., {@code withZeroOffset()},
 * {@code withSoftLimits()}, or linear unit conversions) requires it fix with
 * {@code withMechanismCircumference(Distance)} <li>Continuous wrapping range an absolute external
 * encoder cannot read, or an absolute encoder geared to the mechanism <li>Continuous
 * wrapping requested while soft limits are also set, or while a distance-based (linear) mechanism
 * circumference is configured <li>Continuous wrapping or closed-loop tolerance requested without a
 * PID controller ({@code withClosedLoopController()}) <li>Distance-based tolerance setter called on
 * an angular controller (missing {@code withLinearClosedLoopController(true)}) <li>MOI parameters
 * ({@code withMOI(Distance, Mass)}) called with {@code null} length or mass <li>NEO 550 motor used
 * without a stator current limit, or with a limit exceeding 40 A <li>Vendor-specific control
 * request type incompatible with the underlying motor controller (e.g., a TalonFXS control request
 * not supported by the configured motor type) <li>Required basic or external-encoder options not
 * all provided before calling {@code get()} <li>Live tuning requested while the control mode is
 * {@code OPEN_LOOP} requires {@code withControlMode(ControlMode.CLOSED_LOOP)}
 * </ul>
 *
 * <p><b>Resolution:</b> Read the exception message; it always names the specific
 * {@code SmartMotorControllerConfig} method to call (or to remove) to resolve the conflict.
 *
 * <p>Example triggering continuous-wrapping conflict:
 *
 * <pre>{@code
 * // WRONG soft limits and continuous wrapping cannot coexist
 * SmartMotorControllerConfig config = new SmartMotorControllerConfig()
 *     .withSoftLimits(Degrees.of(-90), Degrees.of(90))
 *     .withContinuousWrapping(Rotations.of(0), Rotations.of(1)); // throws
 *
 * // CORRECT remove withSoftLimits() when using continuous wrapping
 * SmartMotorControllerConfig config = new SmartMotorControllerConfig()
 *     .withContinuousWrapping(Rotations.of(0), Rotations.of(1));
 * }</pre>
 *
 * @see yams.core.motorcontrollers.SmartMotorControllerConfig
 * @see yams.core.motorcontrollers.SmartMotorController
 */
public class SmartMotorControllerConfigurationException extends RuntimeException {
  /**
   * SmartMotorControllerConfigurationException constructor.
   *
   * @param message        Message to display.
   * @param result         Result of the configuration.
   * @param remedyFunction Remedy function to use.
   */
  public SmartMotorControllerConfigurationException(String message, String result, String remedyFunction) {
    super(message + "!\n" + result + "\nPlease use SmartMotorControllerConfig." + remedyFunction + " to fix this error.");
  }
}
