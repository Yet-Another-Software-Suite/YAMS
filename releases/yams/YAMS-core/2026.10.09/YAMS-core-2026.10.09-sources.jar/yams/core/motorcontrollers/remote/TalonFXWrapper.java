// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.core.motorcontrollers.remote;

import static org.wpilib.units.Units.Meters;
import static org.wpilib.units.Units.MetersPerSecond;
import static org.wpilib.units.Units.MetersPerSecondPerSecond;
import static org.wpilib.units.Units.Milliseconds;
import static org.wpilib.units.Units.Rotations;
import static org.wpilib.units.Units.RotationsPerSecond;
import static org.wpilib.units.Units.RotationsPerSecondPerSecond;
import static org.wpilib.units.Units.Second;
import static org.wpilib.units.Units.Seconds;
import static org.wpilib.units.Units.Volts;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.configs.CANcoderConfiguration;
import com.ctre.phoenix6.configs.CANdiConfiguration;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.configs.TalonFXConfigurator;
import com.ctre.phoenix6.controls.ControlRequest;
import com.ctre.phoenix6.controls.DutyCycleOut;
import com.ctre.phoenix6.controls.Follower;
import com.ctre.phoenix6.controls.MotionMagicDutyCycle;
import com.ctre.phoenix6.controls.MotionMagicExpoDutyCycle;
import com.ctre.phoenix6.controls.MotionMagicExpoVoltage;
import com.ctre.phoenix6.controls.MotionMagicTorqueCurrentFOC;
import com.ctre.phoenix6.controls.MotionMagicVelocityDutyCycle;
import com.ctre.phoenix6.controls.MotionMagicVelocityTorqueCurrentFOC;
import com.ctre.phoenix6.controls.MotionMagicVelocityVoltage;
import com.ctre.phoenix6.controls.MotionMagicVoltage;
import com.ctre.phoenix6.controls.PositionDutyCycle;
import com.ctre.phoenix6.controls.PositionTorqueCurrentFOC;
import com.ctre.phoenix6.controls.PositionVoltage;
import com.ctre.phoenix6.controls.VelocityDutyCycle;
import com.ctre.phoenix6.controls.VelocityTorqueCurrentFOC;
import com.ctre.phoenix6.controls.VelocityVoltage;
import com.ctre.phoenix6.hardware.CANcoder;
import com.ctre.phoenix6.hardware.CANdi;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.hardware.TalonFXS;
import com.ctre.phoenix6.signals.FeedbackSensorSourceValue;
import com.ctre.phoenix6.signals.GravityTypeValue;
import com.ctre.phoenix6.signals.InvertedValue;
import com.ctre.phoenix6.signals.MagnetHealthValue;
import com.ctre.phoenix6.signals.MotorAlignmentValue;
import com.ctre.phoenix6.signals.NeutralModeValue;
import com.ctre.phoenix6.signals.SensorDirectionValue;
import com.ctre.phoenix6.signals.StaticFeedforwardSignValue;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.Supplier;
import org.wpilib.framework.RobotBase;
import org.wpilib.math.controller.ArmFeedforward;
import org.wpilib.math.controller.ElevatorFeedforward;
import org.wpilib.math.controller.SimpleMotorFeedforward;
import org.wpilib.math.system.DCMotor;
import org.wpilib.math.system.Models;
import org.wpilib.math.trajectory.ExponentialProfile;
import org.wpilib.math.trajectory.TrapezoidProfile;
import org.wpilib.math.trajectory.TrapezoidProfile.Constraints;
import org.wpilib.simulation.DCMotorSim;
import org.wpilib.system.Notifier;
import org.wpilib.system.Timer;
import org.wpilib.units.AngularAccelerationUnit;
import org.wpilib.units.measure.Angle;
import org.wpilib.units.measure.AngularAcceleration;
import org.wpilib.units.measure.AngularVelocity;
import org.wpilib.units.measure.Current;
import org.wpilib.units.measure.Distance;
import org.wpilib.units.measure.Force;
import org.wpilib.units.measure.Frequency;
import org.wpilib.units.measure.LinearAcceleration;
import org.wpilib.units.measure.LinearVelocity;
import org.wpilib.units.measure.Temperature;
import org.wpilib.units.measure.Time;
import org.wpilib.units.measure.Velocity;
import org.wpilib.units.measure.Voltage;
import org.wpilib.util.Alert;
import org.wpilib.util.Pair;
import yams.core.exceptions.SmartMotorControllerConfigurationException;
import yams.core.gearing.MechanismGearing;
import yams.core.motorcontrollers.SmartMotorController;
import yams.core.motorcontrollers.SmartMotorControllerConfig;
import yams.core.motorcontrollers.enums.ControlMode;
import yams.core.motorcontrollers.enums.MotorMode;
import yams.core.motorcontrollers.simulation.BatterySim;
import yams.core.motorcontrollers.simulation.DCMotorSimSupplier;
import yams.core.telemetry.SmartMotorControllerTelemetry.BooleanTelemetryField;
import yams.core.telemetry.SmartMotorControllerTelemetry.DoubleTelemetryField;

/**
 * TalonFX wrapper for a CTRE TalonFX motor controller.
 *
 * <p><b>External encoder discontinuity point support (CANcoder):</b>
 *
 * <ul>
 * <li>{@code 0.5} rotations maps to {@code AbsoluteSensorDiscontinuityPoint = 0.5}, sensor
 * range is [-0.5, 0.5)
 * <li>{@code 1.0} rotations maps to {@code AbsoluteSensorDiscontinuityPoint = 1.0}, sensor
 * range is [0, 1)
 * </ul>
 *
 * Configuring a discontinuity point is optional for CANcoder; when omitted the CANcoder default is
 * used. Set via {@link yams.core.motorcontrollers.SmartMotorControllerConfig#withExternalEncoderDiscontinuityPoint}.
 *
 * <h2>Example</h2>
 *
 * <pre>{@code
 * // Configure and create a Kraken X60 TalonFX on CAN ID 5
 * SmartMotorControllerConfig config = new SmartMotorControllerConfig()
 *     .withMotorInverted(false)
 *     .withStatorCurrentLimit(Amps.of(60))
 *     .withSupplyCurrentLimit(Amps.of(80))
 *     .withClosedLoopController(0.3, 0.1, 0.12);
 * SmartMotorController motor = new TalonFXWrapper(
 *     new TalonFX(5), DCMotor.getKrakenX60(1), config);
 * Elevator elevator = new Elevator(new ElevatorConfig(motor).withDrumRadius(Inches.of(1)));
 * }</pre>
 */
public class TalonFXWrapper extends SmartMotorController {
  /** {@link TalonFX} motor controller */
  private final TalonFX m_talonfx;
  /** {@link DCMotor} controlled by {@link TalonFX} */
  private final DCMotor m_dcmotor;
  /** Configurator */
  private final TalonFXConfigurator m_configurator;
  /** Control request slot. */
  private final int m_controlReqSlot = 0;
  /** Velocity control request */
  private final VelocityVoltage m_simpleVelocityReq = new VelocityVoltage(0).withSlot(m_controlReqSlot);
  /** Position control request. */
  private final PositionVoltage m_simplePositionReq = new PositionVoltage(0).withSlot(m_controlReqSlot);
  /** Position with trapezoidal profiling request. */
  private final MotionMagicVoltage m_trapPositionReq = new MotionMagicVoltage(0).withSlot(m_controlReqSlot);
  /** Velocity with trapezoidal profiling request. */
  private final MotionMagicVelocityVoltage m_trapVelocityReq = new MotionMagicVelocityVoltage(0).withSlot(m_controlReqSlot);
  /** Position with exponential profiling request. */
  private final MotionMagicExpoVoltage m_expoPositionReq = new MotionMagicExpoVoltage(0).withSlot(m_controlReqSlot);
  /** Position control request to use. */
  private ControlRequest m_positionReq = m_simplePositionReq;
  /** Velocity control request to use. */
  private ControlRequest m_velocityReq = m_simpleVelocityReq;
  /** Configuration of the motor */
  private final TalonFXConfiguration m_talonConfig;
  /** Mechanism position in rotations. */
  private final StatusSignal<Angle> m_mechanismPosition;
  /** Mechanism velocity in rotations per second. */
  private final StatusSignal<AngularVelocity> m_mechanismVelocity;
  /** Mechanism acceleration in rotations per second squared. */
  private final StatusSignal<AngularAcceleration> m_mechanismAcceleration;
  /** Supply current of the motor controller. */
  private final StatusSignal<Current> m_supplyCurrent;
  /** Stator current of the motor controller. */
  private final StatusSignal<Current> m_statorCurrent;
  /** DutyCycle of the motor controller. */
  private final StatusSignal<Double> m_dutyCycle;
  /** The motor voltage. */
  private final StatusSignal<Voltage> m_outputVoltage;
  /** Rotor position. */
  private final StatusSignal<Angle> m_rotorPosition;
  /** Rotor velocity. */
  private final StatusSignal<AngularVelocity> m_rotorVelocity;
  /** Temperature status */
  private final StatusSignal<Temperature> m_deviceTemperature;
  /** {@link CANcoder} to use as external feedback sensor. */
  private Optional<CANcoder> m_cancoder = Optional.empty();
  /** {@link CANdi} to use as external feedback sensor. */
  private Optional<CANdi> m_candi = Optional.empty();
  /** Exponential profiled velocity control request enabled. */
  private boolean expEnabled = false;
  /** {@link DCMotorSim} for the {@link TalonFX}. */
  private Optional<DCMotorSim> m_dcmotorSim = Optional.empty();
  /** Alert shown when the starting position is not applied because an external encoder is used. */
  private Alert m_startingPositionExternalEncoderAlert;
  /** Alert shown when a zero offset is set without an external encoder present. */
  private Alert m_zeroOffsetNoExternalEncoderAlert;
  /** Alert shown when a discontinuity point is set without an external encoder present. */
  private Alert m_discontinuityPointNoExternalEncoderAlert;
  /**
   * Whether {@link StatusSignal} refreshes should report errors; false in simulation, where status
   * signals are not always updated before they are read.
   */
  private final boolean m_reportStatusSignalErrors = !RobotBase.isSimulation();

  /**
   * Create the {@link TalonFX} wrapper
   *
   * @param controller  {@link TalonFX}
   * @param motor       {@link DCMotor}
   * @param smartConfig {@link SmartMotorControllerConfig}
   * @throws SmartMotorControllerConfigurationException if the vendor config is not a
   *                                                    TalonFXConfiguration.
   * @throws SmartMotorControllerConfigurationException if
   *                                                    {@link #applyConfig(SmartMotorControllerConfig)}
   *                                                    rejects the config.
   * @throws SmartMotorControllerConfigurationException if the motor is a single NEO 550 without
   *                                                    a stator current limit of at most 40A.
   * @throws IllegalArgumentException                   if
   *                                                    {@link #applyConfig(SmartMotorControllerConfig)}
   *                                                    rejects an unsupported option (see its
   *                                                    documentation).
   */
  public TalonFXWrapper(TalonFX controller, DCMotor motor, SmartMotorControllerConfig<?> smartConfig) {
    this.m_talonfx = controller;
    this.m_dcmotor = motor;
    this.m_config = smartConfig;
    m_systemCoreClosedLoopAlert = Optional.of(new Alert("YAMS", buildAlertId("TalonFX", m_talonfx.getDeviceID(), "ClosedLoop"), getName() + " closed loop controller is running on the SystemCore.", Alert.Level.MEDIUM));
    m_startingPositionExternalEncoderAlert = new Alert("YAMS", buildAlertId("TalonFX", m_talonfx.getDeviceID(), "StartingPosition"), getName() + " starting position is not applied because an external encoder is used!", Alert.Level.HIGH);
    m_zeroOffsetNoExternalEncoderAlert = new Alert("YAMS", buildAlertId("TalonFX", m_talonfx.getDeviceID(), "ZeroOffset"), getName() + " zero offset is not supported without an external encoder.", Alert.Level.HIGH);
    m_discontinuityPointNoExternalEncoderAlert = new Alert("YAMS", buildAlertId("TalonFX", m_talonfx.getDeviceID(), "DiscontinuityPoint"), getName() + " discontinuity point is not supported without an external encoder.", Alert.Level.HIGH);
    m_configurator = m_talonfx.getConfigurator();
    if (smartConfig.getVendorConfig().isPresent()) {
      var genCfg = smartConfig.getVendorConfig().get();
      if (genCfg instanceof TalonFXConfiguration) {
        m_talonConfig = (TalonFXConfiguration) genCfg;
      } else {
        throw new SmartMotorControllerConfigurationException("TalonFXConfiguration is the only acceptable vendor config type for TalonFXWrapper", "Vendor config is unable to be applied", ".withVendorConfig(new TalonFXConfiguration())");
      }
    } else {
      m_talonConfig = new TalonFXConfiguration();
      if (!m_config.getResetPreviousConfig()) {
        m_configurator.refresh(m_talonConfig);
      }
    }
    m_mechanismPosition = m_talonfx.getPosition(false);
    m_mechanismVelocity = m_talonfx.getVelocity(false);
    m_mechanismAcceleration = m_talonfx.getAcceleration(false);
    m_dutyCycle = m_talonfx.getDutyCycle(false);
    m_statorCurrent = m_talonfx.getStatorCurrent(false);
    m_supplyCurrent = m_talonfx.getSupplyCurrent(false);
    m_outputVoltage = m_talonfx.getMotorVoltage(false);
    m_rotorPosition = m_talonfx.getRotorPosition(false);
    m_rotorVelocity = m_talonfx.getRotorVelocity(false);
    m_deviceTemperature = m_talonfx.getDeviceTemp(false);
    m_closedLoopControllerThread = null;

    setupSimulation();
    try {
      applyConfig(smartConfig);
      checkConfigSafety();
    } catch (RuntimeException e) {
      // Release what applying the config started, such as the closed loop controller's Notifier,
      // which would otherwise keep running for a motor controller that was never made.
      close();
      throw e;
    }
  }

  /**
   * Configure FOC for the current position and velocity control requests.
   *
   * @param foc FOC state.
   * @throws SmartMotorControllerConfigurationException if the position or velocity control request
   *                                                    is a TorqueCurrentFOC request (set through
   *                                                    withVendorControlRequest), which does not
   *                                                    support toggling FOC.
   */
  private void setFOC(boolean foc) {
    switch (m_positionReq.getName()) {
      case "MotionMagicDutyCycle":
        ((MotionMagicDutyCycle) m_positionReq).withEnableFOC(foc);
        break;
      case "MotionMagicExpoDutyCycle":
        ((MotionMagicExpoDutyCycle) m_positionReq).withEnableFOC(foc);
        break;
      case "MotionMagicExpoVoltage":
        ((MotionMagicExpoVoltage) m_positionReq).withEnableFOC(foc);
        break;
      case "MotionMagicVoltage":
        ((MotionMagicVoltage) m_positionReq).withEnableFOC(foc);
        break;
      case "PositionDutyCycle":
        ((PositionDutyCycle) m_positionReq).withEnableFOC(foc);
        break;
      case "PositionVoltage":
        ((PositionVoltage) m_positionReq).withEnableFOC(foc);
        break;
      default:
        throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + m_positionReq.getName() + "' control request!", "Cannot use given control request", "withVendorControlRequest()");
    }
    switch (m_velocityReq.getName()) {
      case "MotionMagicVelocityDutyCycle":
        ((MotionMagicVelocityDutyCycle) m_velocityReq).withEnableFOC(foc);
        break;
      case "MotionMagicVelocityVoltage":
        ((MotionMagicVelocityVoltage) m_velocityReq).withEnableFOC(foc);
        break;
      case "VelocityDutyCycle":
        ((VelocityDutyCycle) m_velocityReq).withEnableFOC(foc);
        break;
      case "VelocityVoltage":
        ((VelocityVoltage) m_velocityReq).withEnableFOC(foc);
        break;
      default:
        throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + m_velocityReq.getName() + "' control request!", "Cannot use given control request", "withVendorControlRequest()");
    }
  }

  /**
   * Enable FOC control, ignored if the device isn't PRO licensed.
   *
   * @return {@link TalonFXWrapper} for ease of use.
   * @throws SmartMotorControllerConfigurationException if the position or velocity control request
   *                                                    is a TorqueCurrentFOC request (set through
   *                                                    withVendorControlRequest), which does not
   *                                                    support toggling FOC.
   */
  public TalonFXWrapper enableFOC() {
    setFOC(true);
    return this;
  }

  /**
   * Disable FOC control, ignored if the device isn't PRO licensed.
   *
   * @return {@link TalonFXWrapper} for ease of use.
   * @throws SmartMotorControllerConfigurationException if the position or velocity control request
   *                                                    is a TorqueCurrentFOC request (set through
   *                                                    withVendorControlRequest), which does not
   *                                                    support toggling FOC.
   */
  public TalonFXWrapper disableFOC() {
    setFOC(false);
    return this;
  }

  @Override
  public void setupSimulation() {
    if (RobotBase.isSimulation()) {
      var setupRan = m_dcmotorSim.isPresent();
      if (!setupRan) {
        m_dcmotorSim = Optional.of(new DCMotorSim(Models.singleJointedArmFromPhysicalConstants(m_dcmotor, m_config.getMOI(), m_config.getGearing().getMechanismToRotorRatio()), m_dcmotor));
        setSimSupplier(new DCMotorSimSupplier(m_dcmotorSim.get(), this));
      }
      m_config.getStartingPosition().ifPresent(mechPos -> {
        m_simSupplier.get().setMechanismPosition(mechPos);
      });
    }
  }

  @Override
  public void seedRelativeEncoder() {
    // throw new RuntimeException("Unsupported operation");
  }

  /**
   * {@inheritDoc}
   *
   * @implNote Does nothing, the TalonFX fuses its feedback sources on the device, so there is no
   *           relative encoder to resynchronize.
   */
  @Override
  public void synchronizeRelativeEncoder() {
  }

  @Override
  public void simIterate() {
    if (RobotBase.isSimulation() && m_simSupplier.isPresent()) {
      var talonFXSim = m_talonfx.getSimState();

      // set the supply voltage of the TalonFX
      talonFXSim.setSupplyVoltage(m_simSupplier.get().getMechanismSupplyVoltage());

      // get the motor voltage of the TalonFX
      var motorVoltage = talonFXSim.getMotorVoltageMeasure();

      m_simSupplier.ifPresent(simSupplier -> {
        simSupplier.setMechanismStatorVoltage(motorVoltage); // dcmotorSim.setInputVoltage(motorVoltage)
        simSupplier.updateSimState(); // dcmotorSim.update(0.020)
        simSupplier.starveUpdateSim(); // clear update once atomic
        BatterySim.calculateVoltage(m_batterySimUUID, simSupplier.getSupplyCurrent());
      });

      // apply the new rotor position and velocity to the TalonFX;
      // note that this is rotor position/velocity (before gear ratio), but
      // DCMotorSim returns mechanism position/velocity (after gear ratio)
      talonFXSim.setRawRotorPosition(m_simSupplier.get().getRotorPosition());
      talonFXSim.setRotorVelocity(m_simSupplier.get().getRotorVelocity());
      talonFXSim.setRotorAcceleration(m_simSupplier.get().getRotorAcceleration());

      if (m_cancoder.isPresent()) {
        var cancoderSim = m_cancoder.get().getSimState();
        cancoderSim.setSupplyVoltage(m_simSupplier.get().getMechanismSupplyVoltage());
        cancoderSim.setVelocity(m_simSupplier.get().getMechanismVelocity().times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getMechanismToRotorRatio()));
        cancoderSim.setRawPosition(m_simSupplier.get().getMechanismPosition().times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getMechanismToRotorRatio()).minus(m_config.getExternalEncoderZeroOffset().orElse(Rotations
            .zero())));
        cancoderSim.setMagnetHealth(MagnetHealthValue.Magnet_Green);
      }
      if (m_candi.isPresent()) {
        var candiSim = m_candi.get().getSimState();
        candiSim.setSupplyVoltage(m_simSupplier.get().getMechanismSupplyVoltage());
        if (useCANdiPWM1()) {
          candiSim.setPwm1Connected(true);
          candiSim.setPwm1Position(m_simSupplier.get().getMechanismPosition().times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getMechanismToRotorRatio()).minus(m_config.getExternalEncoderZeroOffset().orElse(Rotations
              .zero())));
          candiSim.setPwm1Velocity(m_simSupplier.get().getMechanismVelocity().times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getMechanismToRotorRatio()));
        } else if (useCANdiPWM2()) {
          candiSim.setPwm2Connected(true);
          candiSim.setPwm2Position(m_simSupplier.get().getMechanismPosition().times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getMechanismToRotorRatio()).minus(m_config.getExternalEncoderZeroOffset().orElse(Rotations
              .zero())));
          candiSim.setPwm2Velocity(m_simSupplier.get().getMechanismVelocity().times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getMechanismToRotorRatio()));
        }
      }
      // TODO: Uncomment after the 2026 season
      //      m_looseFollowers.ifPresent(smcs -> {for(var f : smcs){f.simIterate();}});
    }
  }

  @Override
  public void setZeroPower(MotorMode mode) {
    m_talonConfig.MotorOutput.withNeutralMode(mode == MotorMode.BRAKE ? NeutralModeValue.Brake : NeutralModeValue.Coast);
    forceConfigApply();
  }

  @Override
  public void setEncoderVelocity(AngularVelocity velocity) {
  }

  /**
   * Check if {@link CANdi} PWM1 is used as the
   * {@link com.ctre.phoenix6.configs.ExternalFeedbackConfigs#ExternalFeedbackSensorSource} in
   * {@link TalonFXConfiguration#Feedback}.
   *
   * @return True if CANdi PWM1 is the feedback sensor source of the configuration being applied.
   * @throws IllegalArgumentException if the feedback sensor source is set to a CANdi PWM1 source
   *                                  but no CANdi is configured as the external encoder in the
   *                                  SmartMotorControllerConfig.
   */
  public boolean useCANdiPWM1() {
    // Read the configuration being applied instead of refreshing it from the device, which would
    // discard its unapplied changes. YAMS applies the Fused source; Sync and Remote are the ones
    // users select with a vendor config.
    final var source = m_talonConfig.Feedback.FeedbackSensorSource;
    boolean configured = source == FeedbackSensorSourceValue.FusedCANdiPWM1 || source == FeedbackSensorSourceValue.SyncCANdiPWM1 || source == FeedbackSensorSourceValue.RemoteCANdiPWM1;
    if (configured && m_candi.isEmpty()) {
      throw new IllegalArgumentException("[ERROR] CANdi PWM1 has been configured but is not " + "present in SmartMotorControllerConfig!");
    }
    return configured;
  }

  /**
   * Check if {@link CANdi} PWM2 is used as the
   * {@link com.ctre.phoenix6.configs.ExternalFeedbackConfigs#ExternalFeedbackSensorSource} in
   * {@link TalonFXConfiguration#Feedback}.
   *
   * @return True if CANdi PWM2 is the feedback sensor source of the configuration being applied.
   * @throws IllegalArgumentException if the feedback sensor source is set to a CANdi PWM2 source
   *                                  but no CANdi is configured as the external encoder in the
   *                                  SmartMotorControllerConfig.
   */
  public boolean useCANdiPWM2() {
    // Read the configuration being applied instead of refreshing it from the device, which would
    // discard its unapplied changes. YAMS applies the Fused source; Sync and Remote are the ones
    // users select with a vendor config.
    final var source = m_talonConfig.Feedback.FeedbackSensorSource;
    boolean configured = source == FeedbackSensorSourceValue.FusedCANdiPWM2 || source == FeedbackSensorSourceValue.SyncCANdiPWM2 || source == FeedbackSensorSourceValue.RemoteCANdiPWM2;
    if (configured && m_candi.isEmpty()) {
      throw new IllegalArgumentException("[ERROR] CANdi PWM2 has been configured but is not " + "present in SmartMotorControllerConfig!");
    }
    return configured;
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public void setEncoderVelocity(LinearVelocity velocity) {
    setEncoderVelocity(m_config.convertToMechanism(velocity));
  }

  @Override
  public void setEncoderPosition(Angle angle) {
    m_talonfx.setPosition(angle);
    m_cancoder.ifPresent(caNcoder -> caNcoder.setPosition(angle.in(Rotations)));
    m_simSupplier.ifPresent(mSim -> {
      m_talonfx.getSimState().setRawRotorPosition(angle.times(m_config.getGearing().getMechanismToRotorRatio()));
      mSim.setMechanismPosition(angle);
    });
    // TODO: Set external encoders other than CANCoders
    //    m_dcmotorSim.ifPresent(dcMotorSim -> dcMotorSim.setAngle(angle.in(Radians)));

    // Might want to set absolute encoder position in the future
    /*
     * if (m_candi.isPresent())
     * {
     * CANdiConfigurator configurator = m_candi.get().getConfigurator();
     * CANdiConfiguration cfg = new CANdiConfiguration();
     * configurator.refresh(cfg);
     *
     * if (useCANdiPWM1())
     * {
     * Angle newOffset = m_candi.get().getPWM1Position().getValue()
     * .plus(Rotations.of(cfg.PWM1.AbsoluteSensorOffset))
     * .minus(angle);
     * cfg.PWM1.withAbsoluteSensorOffset(newOffset);
     * }
     * if (useCANdiPWM2())
     * {
     * Angle newOffset = m_candi.get().getPWM2Position().getValue()
     * .plus(Rotations.of(cfg.PWM2.AbsoluteSensorOffset))
     * .minus(angle);
     * cfg.PWM2.withAbsoluteSensorOffset(newOffset);
     * }
     * configurator.apply(cfg);
     * }
     * if (m_cancoder.isPresent())
     * {
     * var configurator = m_cancoder.get().getConfigurator();
     * var cfg = new CANcoderConfiguration();
     * configurator.refresh(cfg);
     * Angle newOffset = m_cancoder.get().getPosition().getValue()
     * .plus(Rotations.of(cfg.MagnetSensor.MagnetOffset))
     * .minus(angle);
     * cfg.MagnetSensor.withMagnetOffset(newOffset);
     * configurator.apply(cfg);
     * }
     */
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public void setEncoderPosition(Distance distance) {
    setEncoderPosition(m_config.convertToMechanism(distance));
  }

  /**
   * Ensure the controls request is sent successfully.
   *
   * @param controlRequest Control request to send.
   */
  private void ensureRequest(Supplier<StatusCode> controlRequest) {
    for (int i = 0; i < 8; i++) {
      if (controlRequest.get() == StatusCode.OK) {
        return;
      }
      Timer.delay(Milliseconds.of(1));
    }
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the configured position control request
   *                                                    is not a supported Phoenix 6 position
   *                                                    request.
   */
  @Override
  public void setPosition(Angle angle) {
    setpointVelocity = Optional.empty();
    setpointFeedforwardForce = Optional.empty();
    setpointPosition = Optional.ofNullable(angle);
    if (angle != null && m_lqr.isEmpty()) {
      switch (m_positionReq.getName()) {
        case "MotionMagicDutyCycle":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicDutyCycle) m_positionReq).withPosition(angle)));
          break;
        case "MotionMagicExpoDutyCycle":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicExpoDutyCycle) m_positionReq).withPosition(angle)));
          break;
        case "MotionMagicExpoVoltage":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicExpoVoltage) m_positionReq).withPosition(angle)));
          break;
        case "MotionMagicTorqueCurrentFOC":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicTorqueCurrentFOC) m_positionReq).withPosition(angle)));
          break;
        case "MotionMagicVoltage":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicVoltage) m_positionReq).withPosition(angle)));
          break;
        case "PositionDutyCycle":
          ensureRequest(() -> m_talonfx.setControl(((PositionDutyCycle) m_positionReq).withPosition(angle)));
          break;
        case "PositionTorqueCurrentFOC":
          ensureRequest(() -> m_talonfx.setControl(((PositionTorqueCurrentFOC) m_positionReq).withPosition(angle)));
          break;
        case "PositionVoltage":
          ensureRequest(() -> m_talonfx.setControl(((PositionVoltage) m_positionReq).withPosition(angle)));
          break;
        default:
          throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + m_positionReq.getName() + "' control request!", "Cannot use given control request", "withVendorControlRequest()");
      }
      m_looseFollowers.ifPresent(smcs -> {
        for (var f : smcs) {
          f.setPosition(angle);
        }
      });
    }
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   * @throws SmartMotorControllerConfigurationException if the configured position control request
   *                                                    is not a supported Phoenix 6 position
   *                                                    request.
   */
  @Override
  public void setPosition(Distance distance) {
    setPosition(m_config.convertToMechanism(distance));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   * @throws SmartMotorControllerConfigurationException if the configured velocity control request
   *                                                    is not a supported Phoenix 6 velocity
   *                                                    request.
   */
  @Override
  public void setVelocity(LinearVelocity velocity) {
    setVelocity(m_config.convertToMechanism(velocity));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the configured velocity control request
   *                                                    is not a supported Phoenix 6 velocity
   *                                                    request.
   */
  @Override
  public void setVelocity(AngularVelocity angularVelocity) {
    setpointPosition = Optional.empty();
    setpointVelocity = Optional.ofNullable(angularVelocity);
    setpointFeedforwardForce = Optional.empty();
    if (angularVelocity != null && m_lqr.isEmpty()) {
      // The request objects are reused, so clear any feedforward left by setVelocity(velocity, force).
      switch (m_velocityReq.getName()) {
        case "MotionMagicVelocityDutyCycle":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicVelocityDutyCycle) m_velocityReq).withVelocity(angularVelocity).withFeedForward(0)));
          break;
        case "MotionMagicVelocityTorqueCurrentFOC":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicVelocityTorqueCurrentFOC) m_velocityReq).withVelocity(angularVelocity).withFeedForward(0)));
          break;
        case "MotionMagicVelocityVoltage":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicVelocityVoltage) m_velocityReq).withVelocity(angularVelocity).withFeedForward(0)));
          break;
        case "VelocityDutyCycle":
          ensureRequest(() -> m_talonfx.setControl(((VelocityDutyCycle) m_velocityReq).withVelocity(angularVelocity).withFeedForward(0)));
          break;
        case "VelocityTorqueCurrentFOC":
          ensureRequest(() -> m_talonfx.setControl(((VelocityTorqueCurrentFOC) m_velocityReq).withVelocity(angularVelocity).withFeedForward(0)));
          break;
        case "VelocityVoltage":
          ensureRequest(() -> m_talonfx.setControl(((VelocityVoltage) m_velocityReq).withVelocity(angularVelocity).withFeedForward(0)));
          break;
        default:
          throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + m_velocityReq.getName() + "' control request!", "Cannot use given control request", "withVendorControlRequest()");
      }
      m_looseFollowers.ifPresent(smcs -> {
        for (var f : smcs) {
          f.setVelocity(angularVelocity);
        }
      });
      //      m_simSupplier.ifPresent(simSupplier ->
      //      simSupplier.setMechanismVelocity(angularVelocity));
    }
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if a feedforward force is given without an
   *                                                    LQR controller and the mechanism
   *                                                    circumference is not configured.
   * @throws SmartMotorControllerConfigurationException if the configured velocity control request
   *                                                    is not a supported Phoenix 6 velocity
   *                                                    request.
   */
  @Override
  public void setVelocity(AngularVelocity angularVelocity, Force feedforwardForce) {
    setpointPosition = Optional.empty();
    setpointVelocity = Optional.ofNullable(angularVelocity);
    setpointFeedforwardForce = Optional.ofNullable(feedforwardForce);
    if (angularVelocity != null && m_lqr.isEmpty() && setpointFeedforwardForce.isPresent()) {
      Voltage feedforwardVoltage = m_config.convertToVoltage(m_dcmotor, feedforwardForce);
      Current feedforwardCurrent = m_config.convertToCurrent(m_dcmotor, feedforwardForce);
      switch (m_velocityReq.getName()) {
        case "MotionMagicVelocityDutyCycle":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicVelocityDutyCycle) m_velocityReq).withVelocity(angularVelocity).withFeedForward(feedforwardVoltage.in(Volts) / m_dcmotor.nominalVoltage)));
          break;
        case "MotionMagicVelocityTorqueCurrentFOC":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicVelocityTorqueCurrentFOC) m_velocityReq).withVelocity(angularVelocity).withFeedForward(feedforwardCurrent)));
          break;
        case "MotionMagicVelocityVoltage":
          ensureRequest(() -> m_talonfx.setControl(((MotionMagicVelocityVoltage) m_velocityReq).withVelocity(angularVelocity).withFeedForward(feedforwardVoltage)));
          break;
        case "VelocityDutyCycle":
          ensureRequest(() -> m_talonfx.setControl(((VelocityDutyCycle) m_velocityReq).withVelocity(angularVelocity).withFeedForward(feedforwardVoltage.in(Volts) / m_dcmotor.nominalVoltage)));
          break;
        case "VelocityTorqueCurrentFOC":
          ensureRequest(() -> m_talonfx.setControl(((VelocityTorqueCurrentFOC) m_velocityReq).withVelocity(angularVelocity).withFeedForward(feedforwardCurrent)));
          break;
        case "VelocityVoltage":
          ensureRequest(() -> m_talonfx.setControl(((VelocityVoltage) m_velocityReq).withVelocity(angularVelocity).withFeedForward(feedforwardVoltage)));
          break;
        default:
          throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + m_velocityReq.getName() + "' control request!", "Cannot use given control request", "withVendorControlRequest()");
      }
      m_looseFollowers.ifPresent(smcs -> {
        for (var f : smcs) {
          f.setVelocity(angularVelocity, feedforwardForce);
        }
      });
      //      m_simSupplier.ifPresent(simSupplier ->
      //      simSupplier.setMechanismVelocity(angularVelocity));
    } else {
      setVelocity(angularVelocity);
    }
  }

  @Override
  public double getDutyCycle() {
    return m_dutyCycle.refresh(m_reportStatusSignalErrors).getValue();
  }

  @Override
  public void setDutyCycle(double dutyCycle) {
    m_talonfx.setControl(new DutyCycleOut(dutyCycle));
    if (dutyCycle == 0.0) {
      m_looseFollowers.ifPresent(looseFollower -> {
        for (var follower : looseFollower) {
          follower.setDutyCycle(dutyCycle);
        }
      });
    }
    // m_simSupplier.ifPresent(simSupplier -> simSupplier.setMechanismStatorDutyCycle(dutyCycle));
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if a closed loop tolerance is configured
   *                                                    without an LQR controller.
   * @throws SmartMotorControllerConfigurationException if a feedforward is configured for SLOT_3.
   * @throws SmartMotorControllerConfigurationException if an external encoder inversion or gearing
   *                                                    is set while no external encoder is used.
   * @throws SmartMotorControllerConfigurationException if an integrated encoder inversion is set.
   * @throws SmartMotorControllerConfigurationException if the vendor control request is not a
   *                                                    supported Phoenix 6 position or velocity
   *                                                    request.
   * @throws SmartMotorControllerConfigurationException if the continuous wrapping bounds are not
   *                                                    exactly one rotation apart.
   * @throws SmartMotorControllerConfigurationException if not every required config option was
   *                                                    read during validation.
   * @throws IllegalArgumentException                   if an LQR controller is configured together
   *                                                    with a closed loop tolerance.
   * @throws IllegalArgumentException                   if a follower is neither a TalonFX nor a
   *                                                    TalonFXS.
   * @throws IllegalArgumentException                   if a closed loop control period is
   *                                                    configured.
   * @throws IllegalArgumentException                   if a temperature cutoff is configured.
   * @throws IllegalArgumentException                   if a feedback synchronization threshold is
   *                                                    configured.
   * @throws IllegalArgumentException                   if voltage compensation is configured.
   */
  @Override
  public boolean applyConfig(SmartMotorControllerConfig<?> config) {
    config.resetValidationCheck();
    this.m_config = config;
    if (!m_config.getResetPreviousConfig()) {
      m_configurator.refresh(m_talonConfig);
    }
    m_systemCoreClosedLoopAlert.ifPresent(alert -> alert.set(false));
    m_startingPositionExternalEncoderAlert.set(false);
    m_zeroOffsetNoExternalEncoderAlert.set(false);
    m_discontinuityPointNoExternalEncoderAlert.set(false);
    this.m_looseFollowers = config.getLooselyCoupledFollowers();
    m_lqr = config.getLQRClosedLoopController();

    // Sim periodic
    if (RobotBase.isSimulation() && !m_config.getSimulationPeriod().isEquivalent(Milliseconds.of(20)))
      setUpdateFrequency(m_config.getSimulationPeriod().asFrequency());

    // Closed loop controllers.
    for (var closedLoopControlSlot : ClosedLoopControllerSlot.values()) {
      m_config.getPID(closedLoopControlSlot).ifPresent(pid -> {
        // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
        final double gainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(1)).in(Rotations) : 1.0;
        switch (closedLoopControlSlot) {
          case SLOT_0 -> m_talonConfig.Slot0.withKP(pid.getP() / gainUnitsPerRotation).withKI(pid.getI() / gainUnitsPerRotation).withKD(pid.getD() / gainUnitsPerRotation);
          case SLOT_1 -> m_talonConfig.Slot1.withKP(pid.getP() / gainUnitsPerRotation).withKI(pid.getI() / gainUnitsPerRotation).withKD(pid.getD() / gainUnitsPerRotation);
          case SLOT_2 -> m_talonConfig.Slot2.withKP(pid.getP() / gainUnitsPerRotation).withKI(pid.getI() / gainUnitsPerRotation).withKD(pid.getD() / gainUnitsPerRotation);
        }
      });
    }
    m_config.getExponentialProfile().ifPresent(exp -> {
      m_expoProfile = Optional.of(new ExponentialProfile(exp));
      // A linear profile is in meters; Motion Magic Expo gains are per mechanism rotation.
      final boolean linear = m_config.getLinearClosedLoopControllerUse();
      m_talonConfig.MotionMagic.MotionMagicExpo_kV = (linear ? (-exp.A / exp.B) / m_config.convertToMechanism(MetersPerSecond.of(1)).in(RotationsPerSecond) : (-exp.A / exp.B));
      m_talonConfig.MotionMagic.MotionMagicExpo_kA = (linear ? (1.0 / exp.B) / m_config.convertToMechanism(MetersPerSecondPerSecond.of(1)).in(RotationsPerSecondPerSecond) : (1.0 / exp.B));

      m_positionReq = m_expoPositionReq;
    });
    m_config.getTrapezoidProfile().ifPresent(trap -> {
      m_trapezoidProfile = Optional.of(new TrapezoidProfile(trap));
      if (m_config.getVelocityTrapezoidalProfileInUse()) {
        m_talonConfig.MotionMagic.MotionMagicAcceleration = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(trap.maxVelocity)).in(Rotations) : trap.maxVelocity;
        m_talonConfig.MotionMagic.MotionMagicJerk = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(trap.maxAcceleration)).in(Rotations) : trap.maxAcceleration;
      } else {
        m_talonConfig.MotionMagic.MotionMagicCruiseVelocity = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(trap.maxVelocity)).in(Rotations) : trap.maxVelocity;
        m_talonConfig.MotionMagic.MotionMagicAcceleration = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(trap.maxAcceleration)).in(Rotations) : trap.maxAcceleration;
      }
      m_positionReq = m_trapPositionReq;
      m_velocityReq = m_trapVelocityReq;
    });

    // Configure kS to work correctly when no profile is provided.
    if (m_config.getTrapezoidProfile().isEmpty() && m_config.getExponentialProfile().isEmpty()) {
      m_talonConfig.Slot0.StaticFeedforwardSign = StaticFeedforwardSignValue.UseClosedLoopSign;
    }

    if (m_lqr.isPresent()) {
      if (m_config.getClosedLoopTolerance().isPresent()) {
        throw new IllegalArgumentException("[ERROR] Cannot set closed-loop controller error tolerance on " + (config.getTelemetryName().isPresent() ? getName() : "TalonFX(" + m_talonfx.getDeviceID() + ")"));
      }
      m_systemCoreClosedLoopAlert.ifPresent(alert -> alert.set(true));

      iterateClosedLoopController();

      if (m_closedLoopControllerThread == null) {
        m_closedLoopControllerThread = new Notifier(this::iterateClosedLoopController);
      } else {
        stopClosedLoopController();
        m_closedLoopControllerThread.stop();
        m_closedLoopControllerThread.close();
        m_closedLoopControllerThread = new Notifier(this::iterateClosedLoopController);
      }

      if (config.getTelemetryName().isPresent()) {
        m_closedLoopControllerThread.setName(config.getTelemetryName().get());
      }
      if (config.getMotorControllerMode() == ControlMode.CLOSED_LOOP) {
        startClosedLoopController();
      } else {
        m_closedLoopControllerThread.stop();
        if (config.getClosedLoopControlPeriod().isPresent()) {
          throw new IllegalArgumentException("[Error] Closed loop control period is only supported in closed loop mode.");
        }
      }
    }

    if (config.getClosedLoopTolerance().isPresent()) {
      throw new SmartMotorControllerConfigurationException("Closed loop tolerance is not available on TalonFX", "Cannot set closed loop tolerance on TalonFX", ".withClosedLoopTolerance");
    }

    // Fetch the controller mode to satisfy the requirement of knowing the control mode.
    config.getMotorControllerMode();

    // Feedforwards
    for (var closedLoopControlSlot : ClosedLoopControllerSlot.values()) {
      Optional<ArmFeedforward> armFeedforward = m_config.getArmFeedforward(closedLoopControlSlot);
      Optional<ElevatorFeedforward> elevatorFeedforward = m_config.getElevatorFeedforward(closedLoopControlSlot);
      Optional<SimpleMotorFeedforward> simpleMotorFeedforward = m_config.getSimpleFeedforward(closedLoopControlSlot);
      if (armFeedforward.isPresent() || elevatorFeedforward.isPresent() || simpleMotorFeedforward.isPresent()) {
        double kS = 0, kV = 0, kA = 0, kG = 0;
        if (armFeedforward.isPresent()) {
          var ff = armFeedforward.get();
          kS = ff.getKs();
          kV = ff.getKv();
          kA = ff.getKa();
          kG = ff.getKg();
          switch (closedLoopControlSlot) {
            case SLOT_0 -> m_talonConfig.Slot0.GravityType = GravityTypeValue.Arm_Cosine;
            case SLOT_1 -> m_talonConfig.Slot1.GravityType = GravityTypeValue.Arm_Cosine;
            case SLOT_2 -> m_talonConfig.Slot2.GravityType = GravityTypeValue.Arm_Cosine;
            case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
          }
        } else if (elevatorFeedforward.isPresent()) {
          var ff = elevatorFeedforward.get();
          kS = ff.getKs();
          kV = ff.getKv();
          kA = ff.getKa();
          kG = ff.getKg();
          switch (closedLoopControlSlot) {
            case SLOT_0 -> m_talonConfig.Slot0.GravityType = GravityTypeValue.Elevator_Static;
            case SLOT_1 -> m_talonConfig.Slot1.GravityType = GravityTypeValue.Elevator_Static;
            case SLOT_2 -> m_talonConfig.Slot2.GravityType = GravityTypeValue.Elevator_Static;
            case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
          }
        } else {
          var ff = simpleMotorFeedforward.get();
          kS = ff.getKs();
          kV = ff.getKv();
          kA = ff.getKa();
        }
        // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
        final double velocityGainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(MetersPerSecond.of(1)).in(RotationsPerSecond) : 1.0;
        final double accelerationGainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(MetersPerSecondPerSecond.of(1)).in(RotationsPerSecondPerSecond) : 1.0;
        switch (closedLoopControlSlot) {
          case SLOT_0 -> m_talonConfig.Slot0.withKS(kS).withKV(kV / velocityGainUnitsPerRotation).withKA(kA / accelerationGainUnitsPerRotation).withKG(kG);
          case SLOT_1 -> m_talonConfig.Slot1.withKS(kS).withKV(kV / velocityGainUnitsPerRotation).withKA(kA / accelerationGainUnitsPerRotation).withKG(kG);
          case SLOT_2 -> m_talonConfig.Slot2.withKS(kS).withKV(kV / velocityGainUnitsPerRotation).withKA(kA / accelerationGainUnitsPerRotation).withKG(kG);
          case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
        }
      }
    }

    // Motor inversion
    config.getMotorInverted().ifPresent(inverted -> {
      m_talonConfig.MotorOutput.Inverted = inverted ? InvertedValue.Clockwise_Positive : InvertedValue.CounterClockwise_Positive;
    });
    // Zero power mode
    if (config.getZeroPower().isPresent()) {
      m_talonConfig.MotorOutput.NeutralMode = config.getZeroPower().get() == MotorMode.BRAKE ? NeutralModeValue.Brake : NeutralModeValue.Coast;
    }
    // Maximum and minimum voltage
    if (config.getClosedLoopControllerMaximumVoltage().isPresent()) {
      m_talonConfig.Voltage.withPeakForwardVoltage(config.getClosedLoopControllerMaximumVoltage().get());
      m_talonConfig.Voltage.withPeakReverseVoltage(config.getClosedLoopControllerMaximumVoltage().get().times(-1));
    }
    // Ramp rates
    config.getClosedLoopRampRate().ifPresent(rampRate -> {
      m_talonConfig.ClosedLoopRamps.withDutyCycleClosedLoopRampPeriod(rampRate).withVoltageClosedLoopRampPeriod(rampRate).withTorqueClosedLoopRampPeriod(rampRate);
    });
    config.getOpenLoopRampRate().ifPresent(rampRate -> {
      m_talonConfig.OpenLoopRamps.withDutyCycleOpenLoopRampPeriod(rampRate).withVoltageOpenLoopRampPeriod(rampRate).withTorqueOpenLoopRampPeriod(rampRate);
    });
    // Current limits
    if (config.getStatorStallCurrentLimit().isPresent()) {
      m_talonConfig.CurrentLimits.withStatorCurrentLimitEnable(true).withStatorCurrentLimit(config.getStatorStallCurrentLimit().getAsInt());
    }
    if (config.getSupplyStallCurrentLimit().isPresent()) {
      m_talonConfig.CurrentLimits.withSupplyCurrentLimitEnable(true).withSupplyCurrentLimit(config.getSupplyStallCurrentLimit().getAsInt());
    }
    // Soft limit
    if (config.getMechanismUpperLimit().isPresent()) {
      m_talonConfig.SoftwareLimitSwitch.withForwardSoftLimitEnable(config.getMotorControllerMode() == ControlMode.CLOSED_LOOP).withForwardSoftLimitThreshold(config.getMechanismUpperLimit().get());
    }
    if (config.getMechanismLowerLimit().isPresent()) {
      m_talonConfig.SoftwareLimitSwitch.withReverseSoftLimitEnable(config.getMotorControllerMode() == ControlMode.CLOSED_LOOP).withReverseSoftLimitThreshold(config.getMechanismLowerLimit().get());
    }

    // Configure external encoders
    boolean useExternalEncoder = config.getUseExternalFeedback();
    if (config.getExternalEncoder().isPresent() && useExternalEncoder) {
      // Starting position
      if (config.getStartingPosition().isPresent()) {
        m_startingPositionExternalEncoderAlert.set(true);
      }
      // Set the gear ratio for external encoders.
      m_talonConfig.Feedback.RotorToSensorRatio = config.getGearing().getMechanismToRotorRatio() * config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getRotorToMechanismRatio();
      m_talonConfig.Feedback.SensorToMechanismRatio = config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getMechanismToRotorRatio();
      if (config.getExternalEncoder().get() instanceof CANcoder encoder) {
        m_cancoder = Optional.of((CANcoder) config.getExternalEncoder().get());
        var configurator = encoder.getConfigurator();
        var cfg = new CANcoderConfiguration();
        configurator.refresh(cfg);
        m_talonConfig.Feedback.FeedbackRemoteSensorID = encoder.getDeviceID();
        config.getExternalEncoderInverted().ifPresent(inversion -> {
          cfg.MagnetSensor.withSensorDirection(inversion ? SensorDirectionValue.Clockwise_Positive : SensorDirectionValue.CounterClockwise_Positive);
        });

        // Configure feedback source for CANCoder
        m_talonConfig.Feedback.FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANcoder;
        // Zero offset
        if (config.getExternalEncoderZeroOffset().isPresent()) {
          cfg.MagnetSensor.withMagnetOffset(config.getExternalEncoderZeroOffset().get());
          m_talonConfig.Feedback.FeedbackRotorOffset = 0;
        }
        // Discontinuity Point
        if (config.getExternalEncoderDiscontinuityPoint().isPresent()) {
          cfg.MagnetSensor.withAbsoluteSensorDiscontinuityPoint(config.getExternalEncoderDiscontinuityPoint().get());
        }
        configurator.apply(cfg);
      } else if (config.getExternalEncoder().get() instanceof CANdi encoder) {
        m_candi = Optional.of((CANdi) config.getExternalEncoder().get());
        var configurator = encoder.getConfigurator();
        var cfg = new CANdiConfiguration();
        configurator.refresh(cfg);
        m_talonConfig.Feedback.FeedbackRemoteSensorID = encoder.getDeviceID();
        // Ensure pro uses best option.
        if (useCANdiPWM2()) {
          m_talonConfig.Feedback.FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANdiPWM2;
        }
        if (useCANdiPWM1()) {
          m_talonConfig.Feedback.FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANdiPWM1;
        }
        if (useCANdiPWM1()) {
          config.getExternalEncoderInverted().ifPresent(cfg.PWM1::withSensorDirection);

          // Zero offset
          if (config.getExternalEncoderZeroOffset().isPresent()) {
            cfg.PWM1.withAbsoluteSensorOffset(config.getExternalEncoderZeroOffset().get());
            m_talonConfig.Feedback.FeedbackRotorOffset = 0;
          }
          // Discontinuity point
          if (config.getExternalEncoderDiscontinuityPoint().isPresent()) {
            cfg.PWM1.withAbsoluteSensorDiscontinuityPoint(config.getExternalEncoderDiscontinuityPoint().get());
          }
        } else if (useCANdiPWM2()) {
          config.getExternalEncoderInverted().ifPresent(cfg.PWM2::withSensorDirection);
          // Zero offset
          if (config.getExternalEncoderZeroOffset().isPresent()) {
            cfg.PWM2.withAbsoluteSensorOffset(config.getExternalEncoderZeroOffset().get());
            m_talonConfig.Feedback.FeedbackRotorOffset = 0;
          }
          // Discontinuity point
          if (config.getExternalEncoderDiscontinuityPoint().isPresent()) {
            cfg.PWM2.withAbsoluteSensorDiscontinuityPoint(config.getExternalEncoderDiscontinuityPoint().get());
          }
        } else {
          throw new SmartMotorControllerConfigurationException("CANdi is the external feedback encoder but no PWM input is selected", "The CANdi cannot be used as the feedback sensor!", "withVendorConfig() with the feedback sensor source set to SyncCANdiPWM1 or SyncCANdiPWM2");
        }
        configurator.apply(cfg);
      }

    } else {
      if (config.getExternalEncoderInverted().isPresent()) {
        throw new SmartMotorControllerConfigurationException("External Encoder cannot be inverted if not present!", "External encoder is not inverted!", "withExternalEncoderInverted(false)");
      }

      if (config.getExternalEncoderGearing().isPresent()) {
        throw new SmartMotorControllerConfigurationException("External Encoder cannot be set if not present!", "External encoder gearing is not 1.0!", "withExternalEncoderGearing(Rotations.of(1.0))");
      }

      // Zero offset.
      if (config.getExternalEncoderZeroOffset().isPresent()) {
        m_zeroOffsetNoExternalEncoderAlert.set(true);
      }

      m_talonConfig.Feedback.FeedbackSensorSource = FeedbackSensorSourceValue.RotorSensor;
      m_talonConfig.Feedback.RotorToSensorRatio = 1.0;
      m_talonConfig.Feedback.SensorToMechanismRatio = config.getGearing().getMechanismToRotorRatio();

      // Starting position
      if (config.getStartingPosition().isPresent()) {
        m_configurator.apply(m_talonConfig);
        if (RobotBase.isSimulation()) {
          m_talonfx.getSimState().setRawRotorPosition(config.getStartingPosition().get().times(config.getGearing().getMechanismToRotorRatio()));
        }
        StatusCode applied;
        int iterations = 0;
        do {
          applied = m_talonfx.setPosition(config.getStartingPosition().get());
          Timer.delay(Milliseconds.of(10).in(Seconds));
          iterations++;
          if (iterations > 100) {
            break;
          }
        } while (!applied.isOK());
      }
      // Discontinuity point
      if (config.getExternalEncoderDiscontinuityPoint().isPresent()) {
        m_discontinuityPointNoExternalEncoderAlert.set(true);
      }
    }

    // Continuous wrapping. Set either way: the configuration starts from the device's previous one.
    m_talonConfig.ClosedLoopGeneral.ContinuousWrap = config.getContinuousWrapping().isPresent();

    // Invert the encoder.
    if (config.getEncoderInverted().isPresent()) {
      throw new SmartMotorControllerConfigurationException("Integrated encoder phase cannot be set", "Cannot configure TalonFX!", "withEncoderInverted(false)");
    }

    // Configure follower motors
    if (config.getFollowers().isPresent()) {
      for (Pair<Object, Boolean> follower : config.getFollowers().get()) {
        StatusCode applied;
        do {
          if (follower.getFirst() instanceof TalonFXS) {
            config.getZeroPower().ifPresent(mode -> ((TalonFXS) follower.getFirst()).configNeutralMode(mode == MotorMode.BRAKE ? NeutralModeValue.Brake : NeutralModeValue.Coast));
            applied = ((TalonFXS) follower.getFirst()).setControl(new Follower(m_talonfx.getDeviceID(), follower.getSecond() ? MotorAlignmentValue.Opposed : MotorAlignmentValue.Aligned));

          } else if (follower.getFirst() instanceof TalonFX) {
            config.getZeroPower().ifPresent(mode -> ((TalonFX) follower.getFirst()).configNeutralMode(mode == MotorMode.BRAKE ? NeutralModeValue.Brake : NeutralModeValue.Coast));
            applied = ((TalonFX) follower.getFirst()).setControl(new Follower(m_talonfx.getDeviceID(), follower.getSecond() ? MotorAlignmentValue.Opposed : MotorAlignmentValue.Aligned));
          } else {
            throw new IllegalArgumentException("[ERROR] Unknown follower type: " + follower.getFirst().getClass().getSimpleName());
          }
          Timer.delay(Milliseconds.of(10).in(Seconds));
        } while (!applied.equals(StatusCode.OK));
      }
      config.clearFollowers();
    }

    if (config.getVendorControlRequest().isPresent()) {
      var req = config.getVendorControlRequest().get();
      if (req instanceof ControlRequest) {
        switch (((ControlRequest) req).getName()) {
          case "MotionMagicDutyCycle":
          case "MotionMagicExpoDutyCycle":
          case "MotionMagicExpoVoltage":
          case "MotionMagicTorqueCurrentFOC":
          case "MotionMagicVoltage":
          case "PositionDutyCycle":
          case "PositionTorqueCurrentFOC":
          case "PositionVoltage":
            m_positionReq = ((ControlRequest) req);
            break;
          case "MotionMagicVelocityDutyCycle":
          case "MotionMagicVelocityTorqueCurrentFOC":
          case "MotionMagicVelocityVoltage":
          case "VelocityDutyCycle":
          case "VelocityTorqueCurrentFOC":
          case "VelocityVoltage":
            m_velocityReq = ((ControlRequest) req);
            break;
          default:
            throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + ((ControlRequest) req).getName() + "' control request!", "Cannot use given control request",
                "withVendorControlRequest()");
        }
      } else {
        throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + req + "' control request!", "Cannot use given control request",
            "withVendorControlRequest()");
      }
    }

    // Unsupported options.
    // TODO: This isn't really unsupported but needs to be adjusted to 1microsecond since the
    // control loop runs at that speed
    if (config.getClosedLoopControlPeriod().isPresent()) {
      throw new IllegalArgumentException("[ERROR] ClosedLoopControlPeriod is not supported");
    }
    if (config.getTemperatureCutoff().isPresent()) {
      throw new IllegalArgumentException("[ERROR] TemperatureCutoff is not supported");
    }
    if (config.getFeedbackSynchronizationThreshold().isPresent()) {
      throw new IllegalArgumentException("[ERROR] FeedbackSynchronizationThreshold is not supported");
    }
    if (config.getVoltageCompensation().isPresent()) {
      throw new IllegalArgumentException("[ERROR] VoltageCompensation is not supported");
    }

    config.validateBasicOptions();
    config.validateExternalEncoderOptions();

    return forceConfigApply().isOK();
  }

  /**
   * Set the update frequency of the {@link StatusSignal}s used by this {@link SmartMotorController}
   *
   * @param freq {@link Frequency} to use.
   */
  public void setUpdateFrequency(Frequency freq) {
    m_mechanismPosition.setUpdateFrequency(freq);
    m_mechanismVelocity.setUpdateFrequency(freq);
    m_mechanismAcceleration.setUpdateFrequency(freq);
    m_dutyCycle.setUpdateFrequency(freq);
    m_statorCurrent.setUpdateFrequency(freq);
    m_supplyCurrent.setUpdateFrequency(freq);
    m_outputVoltage.setUpdateFrequency(freq);
    m_rotorPosition.setUpdateFrequency(freq);
    m_rotorVelocity.setUpdateFrequency(freq);
    m_deviceTemperature.setUpdateFrequency(freq);
  }

  @Override
  public Optional<Current> getSupplyCurrent() {
    return Optional.of(m_supplyCurrent.refresh(m_reportStatusSignalErrors).getValue());
  }

  @Override
  public Current getStatorCurrent() {
    return m_statorCurrent.refresh(m_reportStatusSignalErrors).getValue();
  }

  @Override
  public Voltage getVoltage() {
    return m_outputVoltage.refresh(m_reportStatusSignalErrors).getValue();
  }

  @Override
  public void setVoltage(Voltage voltage) {
    m_talonfx.setVoltage(voltage.in(Volts));
    //    if (voltage.in(Volts) == 0.0)
    //    {m_looseFollowers.ifPresent(looseFollower -> {for (var follower : looseFollower)
    //    {follower.setVoltage(voltage);}});}
  }

  @Override
  public DCMotor getDCMotor() {
    return m_dcmotor;
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public LinearVelocity getMeasurementVelocity() {
    return m_config.convertFromMechanism(getMechanismVelocity());
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public Distance getMeasurementPosition() {
    return m_config.convertFromMechanism(getMechanismPosition());
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public LinearAcceleration getMeasurementAcceleration() {
    return m_config.convertFromMechanism(getMechanismAcceleration());
  }

  @Override
  public AngularVelocity getMechanismVelocity() {
    if (m_config.getUseExternalFeedback()) {
      final Optional<AngularVelocity> externalEncoderVelocity = getExternalEncoderMechanismVelocity();
      if (externalEncoderVelocity.isPresent()) {
        return externalEncoderVelocity.get();
      }
    }
    return getRelativeMechanismVelocity();
  }

  @Override
  public AngularAcceleration getMechanismAcceleration() {
    return m_mechanismAcceleration.refresh(m_reportStatusSignalErrors).getValue();
  }

  @Override
  public Angle getMechanismPosition() {
    if (m_config.getUseExternalFeedback()) {
      final Optional<Angle> externalEncoderPosition = getExternalEncoderMechanismPosition();
      if (externalEncoderPosition.isPresent()) {
        return externalEncoderPosition.get();
      }
    }
    return getRelativeMechanismPosition();
  }

  @Override
  public AngularVelocity getRotorVelocity() {
    return m_rotorVelocity.refresh(m_reportStatusSignalErrors).getValue();
  }

  @Override
  public Angle getRotorPosition() {
    return m_rotorPosition.refresh(m_reportStatusSignalErrors).getValue();
  }

  @Override
  public AngularVelocity getRelativeMechanismVelocity() {
    return getRotorVelocity().times(m_config.getGearing().getRotorToMechanismRatio());
  }

  @Override
  public Angle getRelativeMechanismPosition() {
    return getRotorPosition().times(m_config.getGearing().getRotorToMechanismRatio());
  }

  /**
   * Get the position of the external encoder's shaft, before the external encoder gearing.
   *
   * @return Angle of the external encoder, or empty if none is attached.
   */
  private Optional<Angle> getExternalEncoderSensorPosition() {
    if (m_cancoder.isPresent()) {
      return Optional.ofNullable(m_cancoder.get().getPosition(false).refresh(m_reportStatusSignalErrors).getValue());
    }
    if (m_candi.isPresent()) {
      if (useCANdiPWM1()) {
        return Optional.ofNullable(m_candi.get().getPWM1Position(false).refresh(m_reportStatusSignalErrors).getValue());
      }
      if (useCANdiPWM2()) {
        return Optional.ofNullable(m_candi.get().getPWM2Position(false).refresh(m_reportStatusSignalErrors).getValue());
      }
    }
    return Optional.empty();
  }

  /**
   * Get the velocity of the external encoder's shaft, before the external encoder gearing.
   *
   * @return AngularVelocity of the external encoder, or empty if none is attached.
   */
  private Optional<AngularVelocity> getExternalEncoderSensorVelocity() {
    if (m_cancoder.isPresent()) {
      return Optional.ofNullable(m_cancoder.get().getVelocity(false).refresh(m_reportStatusSignalErrors).getValue());
    }
    if (m_candi.isPresent()) {
      if (useCANdiPWM1()) {
        return Optional.ofNullable(m_candi.get().getPWM1Velocity(false).refresh(m_reportStatusSignalErrors).getValue());
      }
      if (useCANdiPWM2()) {
        return Optional.ofNullable(m_candi.get().getPWM2Velocity(false).refresh(m_reportStatusSignalErrors).getValue());
      }
    }
    return Optional.empty();
  }

  @Override
  public Optional<Angle> getExternalEncoderMechanismPosition() {
    return getExternalEncoderSensorPosition().map(angle -> angle.times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getRotorToMechanismRatio()));
  }

  @Override
  public Optional<AngularVelocity> getExternalEncoderMechanismVelocity() {
    return getExternalEncoderSensorVelocity().map(velocity -> velocity.times(m_config.getExternalEncoderGearing().orElse(MechanismGearing.kOne).getRotorToMechanismRatio()));
  }

  @Override
  public void setMotorInverted(boolean inverted) {
    m_config.withMotorInverted(inverted);
    m_talonConfig.MotorOutput.Inverted = inverted ? InvertedValue.Clockwise_Positive : InvertedValue.CounterClockwise_Positive;
    forceConfigApply();
  }

  @Override
  public void setEncoderInverted(boolean inverted) {
    //    config.withEncoderInverted(inverted);
    // TODO: Support other encoders.
    //    m_talonConfig.ExternalFeedback.withSensorPhase(inverted ? SensorPhaseValue.Opposed :
    //    SensorPhaseValue.Aligned); m_configurator.apply(m_talonConfig);
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public void setMotionProfileMaxVelocity(LinearVelocity maxVelocity) {
    if (m_trapezoidProfile.isPresent()) {
      final Constraints constraints = new Constraints(maxVelocity.in(MetersPerSecond), m_config.getTrapezoidProfile().orElseThrow().maxAcceleration);
      // Keep the tuned constraints in the config, so tuning the next one keeps this one.
      m_config.withTrapezoidalProfileConstraints(constraints);
      m_trapezoidProfile = Optional.of(new TrapezoidProfile(constraints));
    }
    if (m_config.getVelocityTrapezoidalProfileInUse()) {
      m_talonConfig.MotionMagic.MotionMagicAcceleration = m_config.convertToMechanism(maxVelocity).in(RotationsPerSecond);
    } else {
      m_talonConfig.MotionMagic.withMotionMagicCruiseVelocity(m_config.convertToMechanism(maxVelocity));
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMotionProfileMaxVelocity(maxVelocity);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference is not
   *                                                    configured.
   */
  @Override
  public void setMotionProfileMaxAcceleration(LinearAcceleration maxAcceleration) {
    if (m_trapezoidProfile.isPresent()) {
      final Constraints constraints = new Constraints(m_config.getTrapezoidProfile().orElseThrow().maxVelocity, maxAcceleration.in(MetersPerSecondPerSecond));
      // Keep the tuned constraints in the config, so tuning the next one keeps this one.
      m_config.withTrapezoidalProfileConstraints(constraints);
      m_trapezoidProfile = Optional.of(new TrapezoidProfile(constraints));
    }
    if (m_config.getVelocityTrapezoidalProfileInUse()) {
      m_talonConfig.MotionMagic.MotionMagicJerk = m_config.convertToMechanism(maxAcceleration).in(RotationsPerSecondPerSecond);
    } else {
      m_talonConfig.MotionMagic.withMotionMagicAcceleration(m_config.convertToMechanism(maxAcceleration));
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMotionProfileMaxAcceleration(maxAcceleration);
      }
    });
  }

  @Override
  public void setMotionProfileMaxVelocity(AngularVelocity maxVelocity) {
    if (m_trapezoidProfile.isPresent()) {
      final Constraints constraints = new Constraints(maxVelocity.in(RotationsPerSecond), m_config.getTrapezoidProfile().orElseThrow().maxAcceleration);
      // Keep the tuned constraints in the config, so tuning the next one keeps this one.
      m_config.withTrapezoidalProfileConstraints(constraints);
      m_trapezoidProfile = Optional.of(new TrapezoidProfile(constraints));
    }
    if (m_config.getVelocityTrapezoidalProfileInUse()) {
      m_talonConfig.MotionMagic.MotionMagicAcceleration = maxVelocity.in(RotationsPerSecond);
    } else {
      m_talonConfig.MotionMagic.withMotionMagicCruiseVelocity(maxVelocity);
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMotionProfileMaxVelocity(maxVelocity);
      }
    });
  }

  @Override
  public void setMotionProfileMaxAcceleration(AngularAcceleration maxAcceleration) {
    if (m_trapezoidProfile.isPresent()) {
      final Constraints constraints = new Constraints(m_config.getTrapezoidProfile().orElseThrow().maxVelocity, maxAcceleration.in(RotationsPerSecondPerSecond));
      // Keep the tuned constraints in the config, so tuning the next one keeps this one.
      m_config.withTrapezoidalProfileConstraints(constraints);
      m_trapezoidProfile = Optional.of(new TrapezoidProfile(constraints));
    }
    if (m_config.getVelocityTrapezoidalProfileInUse()) {
      m_talonConfig.MotionMagic.MotionMagicJerk = maxAcceleration.in(RotationsPerSecondPerSecond);
    } else {
      m_talonConfig.MotionMagic.withMotionMagicAcceleration(maxAcceleration);
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMotionProfileMaxAcceleration(maxAcceleration);
      }
    });
  }

  @Override
  public void setMotionProfileMaxJerk(Velocity<AngularAccelerationUnit> maxJerk) {
    if (m_trapezoidProfile.isPresent()) {
      final Constraints constraints = new Constraints(m_config.getTrapezoidProfile().orElseThrow().maxVelocity, maxJerk.in(RotationsPerSecondPerSecond.per(Second)));
      // Keep the tuned constraints in the config, so tuning the next one keeps this one.
      m_config.withTrapezoidalProfileConstraints(constraints);
      m_trapezoidProfile = Optional.of(new TrapezoidProfile(constraints));
    }
    m_talonConfig.MotionMagic.MotionMagicJerk = maxJerk.in(RotationsPerSecondPerSecond.per(Second));
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMotionProfileMaxJerk(maxJerk);
      }
    });
  }

  @Override
  public void setExponentialProfile(OptionalDouble kV, OptionalDouble kA, Optional<Voltage> maxInput) {
    if (m_expoProfile.isPresent() && m_config.getExponentialProfile().isPresent()) {
      var exp = m_config.getExponentialProfile().get();
      // kV and kA are in the profile's units, like its constraints.
      var defaultkV = -exp.A / exp.B;
      var defaultkA = 1.0 / exp.B;
      var defaultMaxInput = exp.maxInput;
      final ExponentialProfile.Constraints constraints = ExponentialProfile.Constraints.fromCharacteristics(maxInput.orElse(Volts.of(defaultMaxInput)).in(Volts), kV.orElse(defaultkV), kA.orElse(defaultkA));
      // Keep the tuned constraints in the config, so tuning the next one keeps this one.
      m_config.withExponentialProfile(constraints);
      m_expoProfile = Optional.of(new ExponentialProfile(constraints));

      // A linear profile is in meters; Motion Magic Expo gains are per mechanism rotation.
      final boolean linear = m_config.getLinearClosedLoopControllerUse();
      m_talonConfig.MotionMagic.MotionMagicExpo_kV = (linear ? kV.orElse(defaultkV) / m_config.convertToMechanism(MetersPerSecond.of(1)).in(RotationsPerSecond) : kV.orElse(defaultkV));
      m_talonConfig.MotionMagic.MotionMagicExpo_kA = (linear ? kA.orElse(defaultkA) / m_config.convertToMechanism(MetersPerSecondPerSecond.of(1)).in(RotationsPerSecondPerSecond) : kA.orElse(defaultkA));
      forceConfigApply();
      m_looseFollowers.ifPresent(smcs -> {
        for (var f : smcs) {
          f.setExponentialProfile(kV, kA, maxInput);
        }
      });
    }
  }

  /**
   * Ensure setting is applied, retries every 10ms.
   *
   * @return {@link StatusCode} from the device.
   */
  public StatusCode forceConfigApply() {
    StatusCode status = m_configurator.apply(m_talonConfig);

    for (int i = 0; i < 10 && !status.isOK(); i++) {
      Timer.delay(Milliseconds.of(10).in(Seconds));
      status = m_configurator.apply(m_talonConfig);
    }
    return status;
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setKp(double kP) {
    m_config.getPID(m_slot).ifPresent(pidController -> {
      pidController.setP(kP);
    });
    // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
    final double gainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(1)).in(Rotations) : 1.0;
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.kP = kP / gainUnitsPerRotation;
      case SLOT_1 -> m_talonConfig.Slot1.kP = kP / gainUnitsPerRotation;
      case SLOT_2 -> m_talonConfig.Slot2.kP = kP / gainUnitsPerRotation;
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setKp(kP);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setKi(double kI) {
    m_config.getPID(m_slot).ifPresent(pidController -> {
      pidController.setI(kI);
    });
    // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
    final double gainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(1)).in(Rotations) : 1.0;
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.kI = kI / gainUnitsPerRotation;
      case SLOT_1 -> m_talonConfig.Slot1.kI = kI / gainUnitsPerRotation;
      case SLOT_2 -> m_talonConfig.Slot2.kI = kI / gainUnitsPerRotation;
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setKi(kI);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setKd(double kD) {
    m_config.getPID(m_slot).ifPresent(pidController -> {
      pidController.setD(kD);
    });
    // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
    final double gainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(1)).in(Rotations) : 1.0;
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.kD = kD / gainUnitsPerRotation;
      case SLOT_1 -> m_talonConfig.Slot1.kD = kD / gainUnitsPerRotation;
      case SLOT_2 -> m_talonConfig.Slot2.kD = kD / gainUnitsPerRotation;
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setKd(kD);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setFeedback(double kP, double kI, double kD) {
    m_config.getPID(m_slot).ifPresent(pidController -> {
      pidController.setP(kP);
      pidController.setI(kI);
      pidController.setD(kD);
    });
    m_pid.ifPresent(simplePidController -> {
      simplePidController.setP(kP);
      simplePidController.setI(kI);
      simplePidController.setD(kD);
    });
    // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
    final double gainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(Meters.of(1)).in(Rotations) : 1.0;
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.withKP(kP / gainUnitsPerRotation).withKI(kI / gainUnitsPerRotation).withKD(kD / gainUnitsPerRotation);
      case SLOT_1 -> m_talonConfig.Slot1.withKP(kP / gainUnitsPerRotation).withKI(kI / gainUnitsPerRotation).withKD(kD / gainUnitsPerRotation);
      case SLOT_2 -> m_talonConfig.Slot2.withKP(kP / gainUnitsPerRotation).withKI(kI / gainUnitsPerRotation).withKD(kD / gainUnitsPerRotation);
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setFeedback(kP, kI, kD);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setKs(double kS) {
    m_config.getSimpleFeedforward(m_slot).ifPresent(simpleMotorFeedforward -> {
      simpleMotorFeedforward.setKs(kS);
    });
    m_config.getArmFeedforward(m_slot).ifPresent(armFeedforward -> {
      armFeedforward.setKs(kS);
    });
    m_config.getElevatorFeedforward(m_slot).ifPresent(elevatorFeedforward -> {
      elevatorFeedforward.setKs(kS);
    });
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.withKS(kS);
      case SLOT_1 -> m_talonConfig.Slot1.withKS(kS);
      case SLOT_2 -> m_talonConfig.Slot2.withKS(kS);
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setKs(kS);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setKv(double kV) {
    m_config.getSimpleFeedforward(m_slot).ifPresent(simpleMotorFeedforward -> {
      simpleMotorFeedforward.setKv(kV);
    });
    m_config.getArmFeedforward(m_slot).ifPresent(armFeedforward -> {
      armFeedforward.setKv(kV);
    });
    m_config.getElevatorFeedforward(m_slot).ifPresent(elevatorFeedforward -> {
      elevatorFeedforward.setKv(kV);
    });
    // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
    final double velocityGainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(MetersPerSecond.of(1)).in(RotationsPerSecond) : 1.0;
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.withKV(kV / velocityGainUnitsPerRotation);
      case SLOT_1 -> m_talonConfig.Slot1.withKV(kV / velocityGainUnitsPerRotation);
      case SLOT_2 -> m_talonConfig.Slot2.withKV(kV / velocityGainUnitsPerRotation);
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setKv(kV);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setKa(double kA) {
    m_config.getSimpleFeedforward(m_slot).ifPresent(simpleMotorFeedforward -> {
      simpleMotorFeedforward.setKa(kA);
    });
    m_config.getArmFeedforward(m_slot).ifPresent(armFeedforward -> {
      armFeedforward.setKa(kA);
    });
    m_config.getElevatorFeedforward(m_slot).ifPresent(elevatorFeedforward -> {
      elevatorFeedforward.setKa(kA);
    });
    // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
    final double accelerationGainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(MetersPerSecondPerSecond.of(1)).in(RotationsPerSecondPerSecond) : 1.0;
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.withKA(kA / accelerationGainUnitsPerRotation);
      case SLOT_1 -> m_talonConfig.Slot1.withKA(kA / accelerationGainUnitsPerRotation);
      case SLOT_2 -> m_talonConfig.Slot2.withKA(kA / accelerationGainUnitsPerRotation);
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setKa(kA);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setKg(double kG) {
    m_config.getArmFeedforward(m_slot).ifPresent(armFeedforward -> {
      armFeedforward.setKg(kG);
    });
    m_config.getElevatorFeedforward(m_slot).ifPresent(elevatorFeedforward -> {
      elevatorFeedforward.setKg(kG);
    });
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.withKG(kG);
      case SLOT_1 -> m_talonConfig.Slot1.withKG(kG);
      case SLOT_2 -> m_talonConfig.Slot2.withKG(kG);
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setKg(kG);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the active closed loop slot is SLOT_3,
   *                                                    which the TalonFX does not support.
   */
  @Override
  public void setFeedforward(double kS, double kV, double kA, double kG) {
    m_config.getSimpleFeedforward(m_slot).ifPresent(simpleMotorFeedforward -> {
      simpleMotorFeedforward.setKs(kS);
      simpleMotorFeedforward.setKv(kV);
      simpleMotorFeedforward.setKa(kA);
    });
    m_config.getArmFeedforward(m_slot).ifPresent(armFeedforward -> {
      armFeedforward.setKs(kS);
      armFeedforward.setKv(kV);
      armFeedforward.setKa(kA);
      armFeedforward.setKg(kG);
      switch (m_slot) {
        case SLOT_0 -> m_talonConfig.Slot0.GravityType = GravityTypeValue.Arm_Cosine;
        case SLOT_1 -> m_talonConfig.Slot1.GravityType = GravityTypeValue.Arm_Cosine;
        case SLOT_2 -> m_talonConfig.Slot2.GravityType = GravityTypeValue.Arm_Cosine;
        case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
      }
    });
    m_config.getElevatorFeedforward(m_slot).ifPresent(elevatorFeedforward -> {
      elevatorFeedforward.setKs(kS);
      elevatorFeedforward.setKv(kV);
      elevatorFeedforward.setKa(kA);
      elevatorFeedforward.setKg(kG);
      switch (m_slot) {
        case SLOT_0 -> m_talonConfig.Slot0.GravityType = GravityTypeValue.Elevator_Static;
        case SLOT_1 -> m_talonConfig.Slot1.GravityType = GravityTypeValue.Elevator_Static;
        case SLOT_2 -> m_talonConfig.Slot2.GravityType = GravityTypeValue.Elevator_Static;
        case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
      }
    });
    // Gains of a linear mechanism are per meter; the Talon's are per mechanism rotation.
    final double velocityGainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(MetersPerSecond.of(1)).in(RotationsPerSecond) : 1.0;
    final double accelerationGainUnitsPerRotation = m_config.getLinearClosedLoopControllerUse() ? m_config.convertToMechanism(MetersPerSecondPerSecond.of(1)).in(RotationsPerSecondPerSecond) : 1.0;
    switch (m_slot) {
      case SLOT_0 -> m_talonConfig.Slot0.withKS(kS).withKV(kV / velocityGainUnitsPerRotation).withKA(kA / accelerationGainUnitsPerRotation).withKG(kG);
      case SLOT_1 -> m_talonConfig.Slot1.withKS(kS).withKV(kV / velocityGainUnitsPerRotation).withKA(kA / accelerationGainUnitsPerRotation).withKG(kG);
      case SLOT_2 -> m_talonConfig.Slot2.withKS(kS).withKV(kV / velocityGainUnitsPerRotation).withKA(kA / accelerationGainUnitsPerRotation).withKG(kG);
      case SLOT_3 -> throw new SmartMotorControllerConfigurationException("Slot 3 is not available on TalonFX", "Cannot use Slot 3 on TalonFX", "");
    }
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setFeedforward(kS, kV, kA, kG);
      }
    });
  }

  @Override
  public void setStatorCurrentLimit(Current currentLimit) {
    m_config.withStatorCurrentLimit(currentLimit);
    m_talonConfig.CurrentLimits.withStatorCurrentLimit(currentLimit).withStatorCurrentLimitEnable(true);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setStatorCurrentLimit(currentLimit);
      }
    });
  }

  @Deprecated
  public void setSupplyCurrentLimit(Current currentLimit) {
    m_talonConfig.CurrentLimits.withSupplyCurrentLimit(currentLimit).withSupplyCurrentLimitEnable(true);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setSupplyCurrentLimit(currentLimit);
      }
    });
  }

  @Override
  public void setClosedLoopRampRate(Time rampRate) {
    m_config.withClosedLoopRampRate(rampRate);
    m_talonConfig.ClosedLoopRamps.withDutyCycleClosedLoopRampPeriod(rampRate).withVoltageClosedLoopRampPeriod(rampRate).withTorqueClosedLoopRampPeriod(rampRate);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setClosedLoopRampRate(rampRate);
      }
    });
  }

  @Override
  public void setOpenLoopRampRate(Time rampRate) {
    m_config.withOpenLoopRampRate(rampRate);
    m_talonConfig.OpenLoopRamps.withDutyCycleOpenLoopRampPeriod(rampRate).withVoltageOpenLoopRampPeriod(rampRate).withTorqueOpenLoopRampPeriod(rampRate);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setOpenLoopRampRate(rampRate);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference and lower
   *                                                    limit are configured and the lower limit is
   *                                                    greater than or equal to upperLimit.
   */
  @Override
  public void setMeasurementUpperLimit(Distance upperLimit) {
    if (m_config.getMechanismCircumference().isPresent() && m_config.getMechanismLowerLimit().isPresent()) {
      m_config.withSoftLimits(m_config.convertFromMechanism(m_config.getMechanismLowerLimit().get()), upperLimit);
      m_talonConfig.SoftwareLimitSwitch.withForwardSoftLimitThreshold(m_config.convertToMechanism(upperLimit)).withForwardSoftLimitEnable(true);
      forceConfigApply();
      m_looseFollowers.ifPresent(smcs -> {
        for (var f : smcs) {
          f.setMeasurementUpperLimit(upperLimit);
        }
      });
    }
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if the mechanism circumference and upper
   *                                                    limit are configured and lowerLimit is
   *                                                    greater than or equal to the upper limit.
   */
  @Override
  public void setMeasurementLowerLimit(Distance lowerLimit) {
    if (m_config.getMechanismCircumference().isPresent() && m_config.getMechanismUpperLimit().isPresent()) {
      m_config.withSoftLimits(lowerLimit, m_config.convertFromMechanism(m_config.getMechanismUpperLimit().get()));
      m_talonConfig.SoftwareLimitSwitch.withReverseSoftLimitThreshold(m_config.convertToMechanism(lowerLimit)).withReverseSoftLimitEnable(true);
      forceConfigApply();
      m_looseFollowers.ifPresent(smcs -> {
        for (var f : smcs) {
          f.setMeasurementLowerLimit(lowerLimit);
        }
      });
    }
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if a lower limit is configured and it is
   *                                                    greater than or equal to upperLimit.
   */
  @Override
  public void setMechanismUpperLimit(Angle upperLimit) {
    m_config.getMechanismLowerLimit().ifPresent(lowerLimit -> {
      m_config.withSoftLimits(lowerLimit, upperLimit);
    });
    m_talonConfig.SoftwareLimitSwitch.withForwardSoftLimitEnable(true).withForwardSoftLimitThreshold(upperLimit);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMechanismUpperLimit(upperLimit);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if an upper limit is configured and
   *                                                    lowerLimit is greater than or equal to it.
   */
  @Override
  public void setMechanismLowerLimit(Angle lowerLimit) {
    m_config.getMechanismUpperLimit().ifPresent(upperLimit -> {
      m_config.withSoftLimits(lowerLimit, upperLimit);
    });
    m_talonConfig.SoftwareLimitSwitch.withReverseSoftLimitEnable(true).withReverseSoftLimitThreshold(lowerLimit);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMechanismLowerLimit(lowerLimit);
      }
    });
  }

  /**
   * {@inheritDoc}
   *
   * @throws SmartMotorControllerConfigurationException if lower is greater than or equal to upper.
   */
  @Override
  public void setMechanismLimits(Angle lower, Angle upper) {
    m_config.withSoftLimits(lower, upper);
    m_talonConfig.SoftwareLimitSwitch.withForwardSoftLimitThreshold(upper).withReverseSoftLimitThreshold(lower);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMechanismLimits(lower, upper);
      }
    });
  }

  @Override
  public void setMechanismLimitsEnabled(boolean enabled) {
    m_talonConfig.SoftwareLimitSwitch.withForwardSoftLimitEnable(enabled).withReverseSoftLimitEnable(enabled);
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMechanismLimitsEnabled(enabled);
      }
    });
  }

  @Override
  public void setMechanismGearing(MechanismGearing gearing) {
    m_config.withGearing(gearing);
    m_talonConfig.Feedback.SensorToMechanismRatio = gearing.getMechanismToRotorRatio();
    forceConfigApply();
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMechanismGearing(gearing);
      }
    });
  }

  @Override
  public void setMechanismCircumference(Distance circumference) {
    m_config.withMechanismCircumference(circumference);
    m_looseFollowers.ifPresent(smcs -> {
      for (var f : smcs) {
        f.setMechanismCircumference(circumference);
      }
    });
  }

  /**
   * Set the closed loop controller slot to use.
   *
   * @param slot Slot to use.
   * @implNote The TalonFX supports 3 slots, not 4!
   * @throws IllegalArgumentException                   if slot is SLOT_3, since the TalonFX only
   *                                                    supports slots 0 through 2.
   * @throws SmartMotorControllerConfigurationException if the position or velocity control request
   *                                                    is a TorqueCurrentFOC request (set through
   *                                                    withVendorControlRequest), which this method
   *                                                    does not handle.
   */
  @Override
  public void setClosedLoopSlot(ClosedLoopControllerSlot slot) {
    if (slot.ordinal() >= ClosedLoopControllerSlot.SLOT_3.ordinal()) {
      throw new IllegalArgumentException("Invalid slot: " + slot);
    }
    m_slot = slot;
    switch (m_positionReq.getName()) {
      case "MotionMagicDutyCycle":
        ((MotionMagicDutyCycle) m_positionReq).withSlot(slot.ordinal());
        break;
      case "MotionMagicExpoDutyCycle":
        ((MotionMagicExpoDutyCycle) m_positionReq).withSlot(slot.ordinal());
        break;
      case "MotionMagicExpoVoltage":
        ((MotionMagicExpoVoltage) m_positionReq).withSlot(slot.ordinal());
        break;
      case "MotionMagicVoltage":
        ((MotionMagicVoltage) m_positionReq).withSlot(slot.ordinal());
        break;
      case "PositionDutyCycle":
        ((PositionDutyCycle) m_positionReq).withSlot(slot.ordinal());
        break;
      case "PositionVoltage":
        ((PositionVoltage) m_positionReq).withSlot(slot.ordinal());
        break;
      default:
        throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + m_positionReq.getName() + "' control request!", "Cannot use given control request", "withVendorControlRequest()");
    }
    switch (m_velocityReq.getName()) {
      case "MotionMagicVelocityDutyCycle":
        ((MotionMagicVelocityDutyCycle) m_velocityReq).withSlot(slot.ordinal());
        break;
      case "MotionMagicVelocityVoltage":
        ((MotionMagicVelocityVoltage) m_velocityReq).withSlot(slot.ordinal());
        break;
      case "VelocityDutyCycle":
        ((VelocityDutyCycle) m_velocityReq).withSlot(slot.ordinal());
        break;
      case "VelocityVoltage":
        ((VelocityVoltage) m_velocityReq).withSlot(slot.ordinal());
        break;
      default:
        throw new SmartMotorControllerConfigurationException("TalonFX(" + m_talonfx.getDeviceID() + ") does not support the '" + m_velocityReq.getName() + "' control request!", "Cannot use given control request", "withVendorControlRequest()");
    }
  }

  @Override
  public Temperature getTemperature() {
    return m_deviceTemperature.refresh(m_reportStatusSignalErrors).getValue();
  }

  @Override
  public SmartMotorControllerConfig<?> getConfig() {
    return m_config;
  }

  @Override
  public Object getMotorController() {
    return m_talonfx;
  }

  @Override
  public Object getMotorControllerConfig() {
    return m_talonConfig;
  }

  @Override
  public Pair<Optional<List<BooleanTelemetryField>>, Optional<List<DoubleTelemetryField>>> getUnsupportedTelemetryFields() {
    return Pair.of(Optional.empty(), Optional.empty());
  }

  @Override
  public void close() {
    super.close();
    m_startingPositionExternalEncoderAlert.close();
    m_zeroOffsetNoExternalEncoderAlert.close();
    m_discontinuityPointNoExternalEncoderAlert.close();
  }
}
