// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.commands3.swerve;

import static org.wpilib.units.Units.MetersPerSecond;
import static org.wpilib.units.Units.Radians;
import static org.wpilib.units.Units.RadiansPerSecond;
import static org.wpilib.units.Units.RotationsPerSecond;

import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import org.wpilib.driverstation.Alliance;
import org.wpilib.driverstation.DriverStationErrors;
import org.wpilib.driverstation.MatchState;
import org.wpilib.driverstation.NiDsXboxController;
import org.wpilib.math.controller.PIDController;
import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.geometry.Translation2d;
import org.wpilib.math.kinematics.ChassisVelocities;
import org.wpilib.math.util.MathUtil;
import org.wpilib.units.measure.Angle;
import org.wpilib.units.measure.AngularVelocity;
import org.wpilib.units.measure.LinearVelocity;
import yams.core.exceptions.SwerveDriveConfigurationException;
import yams.core.mechanisms.config.SwerveDriveConfig;
import yams.core.mechanisms.swerve.SwerveDrive;

/**
 * Helper class to easily transform Controller inputs into workable Chassis speeds. Intended to
 * easily create an interface that generates {@link ChassisVelocities} from
 * {@link NiDsXboxController}
 *
 * <p>Inspired by SciBorgs FRC 1155.
 *
 * <h2>Joystick-to-{@link yams.core.mechanisms.swerve.SwerveDrive} adapter</h2>
 * <p>
 * {@link SwerveInputStream} acts as a bridge between raw controller axis suppliers (in the range
 * {@code [-1, 1]}) and the {@link ChassisVelocities} that
 * {@link yams.core.mechanisms.swerve.SwerveDrive} expects. It handles deadbands, axis scaling, non-linear
 * (cubed) response curves, field-relative / alliance-relative flipping, and multiple drive modes
 * (angular-velocity, heading-snap, translation-only, aim-at-target). Because it implements
 * {@link java.util.function.Supplier}{@code <}{@link ChassisVelocities}{@code >} it can be passed
 * directly to a command or called in a coroutine loop via {@link #get()}.
 * </p>
 *
 * <h2>Typical usage</h2>
 * <pre>{@code
 * NiDsXboxController driver = new NiDsXboxController(0);
 *
 * // Angular-velocity stream: left stick translates, right stick X rotates
 * SwerveInputStream angularVelocityStream =
 *     SwerveInputStream.of(swerveDrive,
 *                          () -> -driver.getLeftY(),   // forward/back
 *                          () -> -driver.getLeftX())   // strafe
 *                      .withControllerRotationAxis(() -> -driver.getRightX())
 *                      .withDeadband(0.05)
 *                      .withScaleTranslation(0.8)
 *                      .withScaleRotation(0.6)
 *                      .setAllianceRelativeControl(true)  // auto-flip for Red alliance
 *                      .setCubeTranslationControllerAxis(true); // non-linear response
 *
 * // In your coroutine or command, call .get() to obtain ChassisVelocities:
 * swerveDrive.setFieldRelativeChassisSpeeds(angularVelocityStream.get());
 * }</pre>
 */
public class SwerveInputStream implements Supplier<ChassisVelocities>, Cloneable {
  /**
   * Translation suppliers.
   */
  private final DoubleSupplier            controllerTranslationX;
  /**
   * Translational supplier.
   */
  private final DoubleSupplier            controllerTranslationY;
  /**
   * {@link SwerveDrive} object for transformations.
   */
  private final SwerveDrive               swerveDrive;
  /**
   * Rotation supplier as angular velocity.
   */
  private       Optional<DoubleSupplier>  controllerOmega                 = Optional.empty();
  /**
   * Rotation supplier as heading X axis.
   */
  private       Optional<DoubleSupplier>  controllerHeadingX              = Optional.empty();
  /**
   * Rotation supplier as heading Y axis.
   */
  private       Optional<DoubleSupplier>  controllerHeadingY              = Optional.empty();
  /**
   * Axis deadband to apply to all inputs.
   */
  private       Optional<Double>          axisDeadband                    = Optional.empty();
  /**
   * Scalar value for the translation axis.
   */
  private       Optional<DoubleSupplier>  translationAxisScale            = Optional.empty();
  /**
   * Scalar value for the rotation axis.
   */
  private       Optional<DoubleSupplier>  omegaAxisScale                  = Optional.empty();
  /**
   * Aim target {@link Pose2d} to aim at.
   */
  private       Optional<Supplier<Pose2d>> aimTarget                      = Optional.empty();
  /**
   * Supplier to enable heading based control.
   */
  private       Optional<BooleanSupplier> headingEnabled                  = Optional.empty();
  /**
   * Field relative heading to face in heading mode.
   */
  private       Optional<Supplier<Angle>> headingSupplier                 = Optional.empty();
  /**
   * Supplier to enable aiming at target.
   */
  private       Optional<BooleanSupplier> aimEnabled                      = Optional.empty();
  /**
   * Current mode of the {@link SwerveInputStream}
   */
  private       SwerveInputMode           currentMode                     = SwerveInputMode.ANGULAR_VELOCITY;
  /**
   * Enable translation only and lock rotation.
   */
  private       Optional<BooleanSupplier> translationOnlyEnabled          = Optional.empty();
  /**
   * Rotation to maintain while {@link SwerveInputStream#translationOnlyEnabled} is True.
   */
  private       Optional<Rotation2d>      lockedHeading                   = Optional.empty();
  /**
   * Cube the angular velocity axis.
   */
  private       Optional<BooleanSupplier> omegaCube                       = Optional.empty();
  /**
   * Cube the translation axis.
   */
  private       Optional<BooleanSupplier> translationCube                 = Optional.empty();
  /**
   * Output robot relative speeds instead of field relative speeds.
   */
  private       Optional<BooleanSupplier> robotRelative                   = Optional.empty();
  /**
   * Invert translation when on the red alliance.
   */
  private       Optional<BooleanSupplier> allianceRelative                = Optional.empty();
  /**
   * Offset heading of translation.
   */
  private       Optional<BooleanSupplier> translationHeadingOffsetEnabled = Optional.empty();
  /**
   * Offset of translation.
   */
  private       Optional<Rotation2d>      translationHeadingOffset        = Optional.empty();
  /**
   * Maximum chassis linear velocity, defaults to 4 Meters per Second.
   */
  private       LinearVelocity            maximumChassisLinearVelocity    = MetersPerSecond.of(4);
  /**
   * Maximum chassis angular velocity, defaults to 1 Rotation per Second.
   */
  private       AngularVelocity           maximumChassisAngularVelocity   = RotationsPerSecond.of(1);

  /**
   * Create a {@link SwerveInputStream} for an easy way to generate {@link ChassisVelocities} from a
   * driver controller.
   *
   * @param drive {@link SwerveDrive} object for transformation.
   * @param x     Translation X input in range of [-1, 1]
   * @param y     Translation Y input in range of [-1, 1]
   */
  public SwerveInputStream(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y) {
    controllerTranslationX = x;
    controllerTranslationY = y;
    swerveDrive = drive;
  }

  /**
   * Create a {@link SwerveInputStream} for an easy way to generate {@link ChassisVelocities} from a
   * driver controller.
   *
   * @param drive {@link SwerveDrive} object for transformation.
   * @param x     Translation X input in range of [-1, 1]
   * @param y     Translation Y input in range of [-1, 1]
   * @param rot   Rotation input in range of [-1, 1]
   */
  public SwerveInputStream(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y, DoubleSupplier rot) {
    this(drive, x, y);
    controllerOmega = Optional.of(rot);
  }

  /**
   * Create a {@link SwerveInputStream} for an easy way to generate {@link ChassisVelocities} from a
   * driver controller.
   *
   * @param drive    {@link SwerveDrive} object for transformation.
   * @param x        Translation X input in range of [-1, 1]
   * @param y        Translation Y input in range of [-1, 1]
   * @param headingX Heading X input in range of [-1, 1]
   * @param headingY Heading Y input in range of [-1, 1]
   */
  public SwerveInputStream(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y, DoubleSupplier headingX, DoubleSupplier headingY) {
    this(drive, x, y);
    withControllerHeadingAxis(headingX, headingY);
  }

  /**
   * Create basic {@link SwerveInputStream} without any rotation components.
   *
   * @param drive {@link SwerveDrive} object for transformation.
   * @param x     {@link DoubleSupplier} of the translation X axis of the controller joystick to
   *              use.
   * @param y     {@link DoubleSupplier} of the translation Y axis of the controller joystick to
   *              use.
   * @return {@link SwerveInputStream} to use as you see fit.
   */
  public static SwerveInputStream of(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y) {
    return new SwerveInputStream(drive, x, y);
  }

  /**
   * Create basic {@link SwerveInputStream} with angular velocity rotation component.
   *
   * @param drive {@link SwerveDrive} object for transformation.
   * @param x     {@link DoubleSupplier} of the translation X axis of the controller joystick to
   *              use.
   * @param y     {@link DoubleSupplier} of the translation Y axis of the controller joystick to
   *              use.
   * @param rot   {@link DoubleSupplier} of the rotation axis of the controller joystick to use.
   * @return {@link SwerveInputStream} to use as you see fit.
   */
  public static SwerveInputStream of(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y, DoubleSupplier rot) {
    return new SwerveInputStream(drive, x, y, rot);
  }

  /**
   * Clone the {@link SwerveInputStream} object.
   *
   * @param cfg {@link SwerveInputStream} to clone.
   */
  private SwerveInputStream(SwerveInputStream cfg) {
    swerveDrive = cfg.swerveDrive;
    controllerTranslationX = cfg.controllerTranslationX;
    controllerTranslationY = cfg.controllerTranslationY;
    controllerOmega = cfg.controllerOmega;
    controllerHeadingX = cfg.controllerHeadingX;
    controllerHeadingY = cfg.controllerHeadingY;
    axisDeadband = cfg.axisDeadband;
    translationAxisScale = cfg.translationAxisScale;
    omegaAxisScale = cfg.omegaAxisScale;
    aimTarget = cfg.aimTarget;
    headingEnabled = cfg.headingEnabled;
    headingSupplier = cfg.headingSupplier;
    aimEnabled = cfg.aimEnabled;
    currentMode = cfg.currentMode;
    translationOnlyEnabled = cfg.translationOnlyEnabled;
    lockedHeading = cfg.lockedHeading;
    omegaCube = cfg.omegaCube;
    translationCube = cfg.translationCube;
    robotRelative = cfg.robotRelative;
    allianceRelative = cfg.allianceRelative;
    translationHeadingOffsetEnabled = cfg.translationHeadingOffsetEnabled;
    translationHeadingOffset = cfg.translationHeadingOffset;
    maximumChassisLinearVelocity = cfg.maximumChassisLinearVelocity;
    maximumChassisAngularVelocity = cfg.maximumChassisAngularVelocity;
  }

  /**
   * Copy the {@link SwerveInputStream} object.
   *
   * @return Clone of current {@link SwerveInputStream}
   */
  @Override
  public SwerveInputStream clone() {
    return new SwerveInputStream(this);
  }

  /**
   * Copy the {@link SwerveInputStream} object.
   *
   * @return Clone of current {@link SwerveInputStream}
   */
  public SwerveInputStream copy() {
    return clone();
  }

  /**
   * Maximum linear velocity to use for the {@link SwerveDrive} object, will be translated to Meters
   * per Second. Default is 4 Meters per Second.
   *
   * @param velocity Linear velocity to use.
   * @return {@link SwerveInputStream} to use as you see fit.
   */
  public SwerveInputStream withMaximumLinearVelocity(LinearVelocity velocity) {
    maximumChassisLinearVelocity = velocity;
    return this;
  }

  /**
   * Maximum angular velocity to use for the {@link SwerveDrive} object, will be translated to
   * Rotations per Second. Default is 1 Rotation per Second.
   *
   * @param velocity Angular velocity to use.
   * @return {@link SwerveInputStream} to use as you see fit.
   */
  public SwerveInputStream withMaximumAngularVelocity(AngularVelocity velocity) {
    maximumChassisAngularVelocity = velocity;
    return this;
  }

  /**
   * Set the stream to output robot relative {@link ChassisVelocities}
   *
   * @param enabled Robot-Relative {@link ChassisVelocities} output.
   * @return self
   */
  public SwerveInputStream setRobotRelative(BooleanSupplier enabled) {
    robotRelative = Optional.ofNullable(enabled);
    return this;
  }

  /**
   * Set the stream to output robot relative {@link ChassisVelocities}
   *
   * @param enabled Robot-Relative {@link ChassisVelocities} output.
   * @return self
   */
  public SwerveInputStream setRobotRelative(boolean enabled) {
    return setRobotRelative(() -> enabled);
  }

  /**
   * Set the stream to output robot relative {@link ChassisVelocities}
   *
   * @return self
   */
  public SwerveInputStream setRobotRelative() {
    return setRobotRelative(() -> true);
  }

  /**
   * Set the translation heading offset angle.
   *
   * @param angle {@link Rotation2d} offset to apply
   * @return self
   */
  public SwerveInputStream withTranslationHeadingOffset(Rotation2d angle) {
    translationHeadingOffset = Optional.ofNullable(angle);
    return this;
  }

  /**
   * Set the translation heading offset enabled state.
   *
   * @param enabled Enable state
   * @return self
   */
  public SwerveInputStream setTranslationHeadingOffset(BooleanSupplier enabled) {
    translationHeadingOffsetEnabled = Optional.ofNullable(enabled);
    return this;
  }

  /**
   * Set the translation heading offset enabled state.
   *
   * @param enabled Enable state
   * @return self
   */
  public SwerveInputStream setTranslationHeadingOffset(boolean enabled) {
    return setTranslationHeadingOffset(() -> enabled);
  }

  /**
   * Enable translation heading offset.
   *
   * @return self
   */
  public SwerveInputStream setTranslationHeadingOffset() {
    return setTranslationHeadingOffset(() -> true);
  }

  /**
   * Modify the output {@link ChassisVelocities} so that it is always relative to your alliance.
   * Has no effect while robot relative control is enabled.
   *
   * @return self
   */
  public SwerveInputStream setAllianceRelativeControl() {
    return setAllianceRelativeControl(() -> true);
  }

  /**
   * Modify the output {@link ChassisVelocities} so that it is always relative to your alliance.
   * Has no effect while robot relative control is enabled.
   *
   * @param enabled Alliance aware {@link ChassisVelocities} output.
   * @return self
   */
  public SwerveInputStream setAllianceRelativeControl(BooleanSupplier enabled) {
    allianceRelative = Optional.ofNullable(enabled);
    return this;
  }

  /**
   * Modify the output {@link ChassisVelocities} so that it is always relative to your alliance.
   * Has no effect while robot relative control is enabled.
   *
   * @param enabled Alliance aware {@link ChassisVelocities} output.
   * @return self
   */
  public SwerveInputStream setAllianceRelativeControl(boolean enabled) {
    return setAllianceRelativeControl(() -> enabled);
  }

  /**
   * Cube the angular velocity controller axis for a non-linear controls scheme.
   *
   * @param enabled Enabled state for the stream.
   * @return self.
   */
  public SwerveInputStream setCubeRotationControllerAxis(BooleanSupplier enabled) {
    omegaCube = Optional.ofNullable(enabled);
    return this;
  }

  /**
   * Cube the angular velocity controller axis for a non-linear controls scheme.
   *
   * @param enabled Enabled state for the stream.
   * @return self.
   */
  public SwerveInputStream setCubeRotationControllerAxis(boolean enabled) {
    return setCubeRotationControllerAxis(() -> enabled);
  }

  /**
   * Cube the angular velocity controller axis for a non-linear controls scheme.
   *
   * @return self.
   */
  public SwerveInputStream setCubeRotationControllerAxis() {
    return setCubeRotationControllerAxis(() -> true);
  }

  /**
   * Cube the translation axis magnitude for a non-linear control scheme.
   *
   * @param enabled Enabled state for the stream
   * @return self
   */
  public SwerveInputStream setCubeTranslationControllerAxis(BooleanSupplier enabled) {
    translationCube = Optional.ofNullable(enabled);
    return this;
  }

  /**
   * Cube the translation axis magnitude for a non-linear control scheme.
   *
   * @param enabled Enabled state for the stream
   * @return self
   */
  public SwerveInputStream setCubeTranslationControllerAxis(boolean enabled) {
    return setCubeTranslationControllerAxis(() -> enabled);
  }

  /**
   * Cube the translation axis magnitude for a non-linear control scheme
   *
   * @return self
   */
  public SwerveInputStream setCubeTranslationControllerAxis() {
    return setCubeTranslationControllerAxis(() -> true);
  }

  /**
   * Add a rotation axis for Angular Velocity control
   *
   * @param rot Rotation axis with values from [-1, 1]
   * @return self
   */
  public SwerveInputStream withControllerRotationAxis(DoubleSupplier rot) {
    controllerOmega = Optional.ofNullable(rot);
    return this;
  }

  /**
   * Add heading axis for Heading based control.
   *
   * @param headingX Heading X axis with values from [-1, 1]
   * @param headingY Heading Y axis with values from [-1, 1]
   * @return self
   */
  public SwerveInputStream withControllerHeadingAxis(DoubleSupplier headingX, DoubleSupplier headingY) {
    // The stick points at the heading to face; atan2(x, y) turns it into that heading.
    withHeading(() -> Radians.of(Math.atan2(headingX.getAsDouble(), headingY.getAsDouble())));
    controllerHeadingX = Optional.of(headingX);
    controllerHeadingY = Optional.of(headingY);
    return this;
  }

  /**
   * Set a deadband for all controller axis.
   *
   * @param deadband Deadband to set, should be between [0, 1)
   * @return self
   */
  public SwerveInputStream deadband(double deadband) {
    axisDeadband = deadband == 0 ? Optional.empty() : Optional.of(deadband);
    return this;
  }

  /**
   * Set a deadband for all controller axis.
   *
   * @param deadband Deadband to set, should be between [0, 1)
   * @return self
   */
  public SwerveInputStream withDeadband(double deadband) {
    return deadband(deadband);
  }

  /**
   * Scale the translation axis for {@link SwerveInputStream} by a constant scalar value.
   *
   * @param scaleTranslation Translation axis scalar value. (0, 1]
   * @return this
   */
  public SwerveInputStream withScaleTranslation(double scaleTranslation) {
    return withScaleTranslation(() -> scaleTranslation);
  }

  /**
   * Scale the translation axis for {@link SwerveInputStream} by a supplier.
   *
   * @param scaleTranslation Translation axis scalar supplier.
   * @return this
   */
  public SwerveInputStream withScaleTranslation(DoubleSupplier scaleTranslation) {
    translationAxisScale = Optional.ofNullable(scaleTranslation);
    return this;
  }

  /**
   * Scale the rotation axis input for {@link SwerveInputStream} to reduce the range in which they
   * operate.
   *
   * @param scaleRotation Angular velocity axis scalar value. (0, 1]
   * @return this
   */
  public SwerveInputStream withScaleRotation(double scaleRotation) {
    return withScaleRotation(() -> scaleRotation);
  }

  /**
   * Scale the rotation axis input for {@link SwerveInputStream} to reduce the range in which they
   * operate.
   *
   * @param scaleRotation Angular velocity axis scalar supplier.
   * @return this
   */
  public SwerveInputStream withScaleRotation(DoubleSupplier scaleRotation) {
    omegaAxisScale = Optional.ofNullable(scaleRotation);
    return this;
  }

  /**
   * Output {@link ChassisVelocities} based on heading while the supplier is True.
   *
   * @param trigger Supplier to use.
   * @return this.
   */
  public SwerveInputStream setHeadingControl(BooleanSupplier trigger) {
    headingEnabled = Optional.ofNullable(trigger);
    return this;
  }

  /**
   * Output {@link ChassisVelocities} based on heading while the boolean is True.
   *
   * @param trigger Boolean to use.
   * @return this.
   */
  public SwerveInputStream setHeadingControl(boolean trigger) {
    return setHeadingControl(() -> trigger);
  }

  /**
   * Output {@link ChassisVelocities} based on heading.
   *
   * @return this.
   */
  public SwerveInputStream setHeadingControl() {
    return setHeadingControl(() -> true);
  }

  /**
   * Supply the field relative heading to face in heading mode, which is enabled with
   * {@link #setHeadingControl(BooleanSupplier)}. Replaces any controller heading axis.
   *
   * @param heading Field relative heading to face, blue-origin where 0 degrees faces the red
   *                alliance wall.
   * @return this.
   */
  public SwerveInputStream withHeading(Supplier<Angle> heading) {
    headingSupplier = Optional.ofNullable(heading);
    controllerHeadingX = Optional.empty();
    controllerHeadingY = Optional.empty();
    return this;
  }

  /**
   * Supply the field relative heading to face in heading mode.
   *
   * @param heading Field relative heading to face.
   * @return this.
   */
  public SwerveInputStream withHeading(Angle heading) {
    return withHeading(() -> heading);
  }

  /**
   * Set the target {@link Pose2d} to aim at.
   *
   * @param aimTarget Target pose supplier.
   * @return this
   */
  public SwerveInputStream withAimTarget(Supplier<Pose2d> aimTarget) {
    this.aimTarget = Optional.ofNullable(aimTarget);
    return this;
  }

  /**
   * Set the target {@link Pose2d} to aim at.
   *
   * @param aimTarget Target pose.
   * @return this
   */
  public SwerveInputStream withAimTarget(Pose2d aimTarget) {
    return withAimTarget(() -> aimTarget);
  }

  /**
   * Aim the {@link SwerveDrive} at the configured target while the trigger is True.
   *
   * @param trigger When True will enable aiming at the current target.
   * @return this
   */
  public SwerveInputStream setAim(BooleanSupplier trigger) {
    this.aimEnabled = Optional.ofNullable(trigger);
    return this;
  }

  /**
   * Aim the {@link SwerveDrive} at the configured target while the boolean is True.
   *
   * @param trigger When True will enable aiming at the current target.
   * @return this
   */
  public SwerveInputStream setAim(boolean trigger) {
    return setAim(() -> trigger);
  }

  /**
   * Enable aiming the {@link SwerveDrive} at the configured target.
   *
   * @return this
   */
  public SwerveInputStream setAim() {
    return setAim(() -> true);
  }

  /**
   * Enable locking of rotation and only translating, overrides everything.
   *
   * @param trigger Translation only while returns true.
   * @return this
   */
  public SwerveInputStream setTranslationOnly(BooleanSupplier trigger) {
    translationOnlyEnabled = Optional.ofNullable(trigger);
    return this;
  }

  /**
   * Enable locking of rotation and only translating, overrides everything.
   *
   * @param enabled Translation only while true.
   * @return this
   */
  public SwerveInputStream setTranslationOnly(boolean enabled) {
    return setTranslationOnly(() -> enabled);
  }

  /**
   * Enable locking of rotation and only translating, overrides everything.
   *
   * @return this
   */
  public SwerveInputStream setTranslationOnly() {
    return setTranslationOnly(() -> true);
  }

  /**
   * Find {@link SwerveInputMode} based off existing parameters of the {@link SwerveInputStream}
   *
   * @return The calculated {@link SwerveInputMode}, defaults to
   *         {@link SwerveInputMode#ANGULAR_VELOCITY}.
   */
  private SwerveInputMode findMode() {
    if (translationOnlyEnabled.isPresent() && translationOnlyEnabled.get().getAsBoolean()) {
      return SwerveInputMode.TRANSLATION_ONLY;
    } else if (aimEnabled.isPresent() && aimEnabled.get().getAsBoolean()) {
      if (aimTarget.isPresent()) {
        return SwerveInputMode.AIM;
      } else {
        DriverStationErrors.reportError("Attempting to enter AIM mode without target, please use " + "SwerveInputStream.withAimTarget() to select a target first!", false);
      }
    } else if (headingEnabled.isPresent() && headingEnabled.get().getAsBoolean()) {
      if (headingSupplier.isPresent()) {
        return SwerveInputMode.HEADING;
      } else {
        DriverStationErrors.reportError("Attempting to enter HEADING mode without a heading, please use " + "SwerveInputStream.withHeading or SwerveInputStream.withControllerHeadingAxis to add one!", false);
      }
    } else if (controllerOmega.isEmpty()) {
      DriverStationErrors.reportError("Attempting to enter ANGULAR_VELOCITY mode without a rotation axis, please use " + "SwerveInputStream.withControllerRotationAxis to add angular velocity axis!", false);
      return SwerveInputMode.TRANSLATION_ONLY;
    }
    return SwerveInputMode.ANGULAR_VELOCITY;
  }

  /**
   * Transition smoothly from one mode to another.
   *
   * @param newMode New mode to transition too.
   */
  private void transitionMode(SwerveInputMode newMode) {
    // Handle removing of current mode.
    switch (currentMode) {
      case TRANSLATION_ONLY -> {
        lockedHeading = Optional.empty();
        break;
      }
      case ANGULAR_VELOCITY -> {
        // Do nothing
        break;
      }
      case HEADING, AIM -> {
        swerveDrive.resetRotationPID();
        break;
      }
    }

    // Transitioning to new mode
    switch (newMode) {
      case TRANSLATION_ONLY -> {
        lockedHeading = Optional.of(swerveDrive.getGyroRotation3d().toRotation2d());
        swerveDrive.resetRotationPID();
        break;
      }
      case ANGULAR_VELOCITY -> {
        break;
      }
      case HEADING, AIM -> {
        swerveDrive.resetRotationPID();
        break;
      }
    }
  }

  /**
   * Apply the deadband if it exists.
   *
   * @param axisValue Axis value to apply the deadband too.
   * @return axis value with deadband, else axis value straight.
   */
  private double applyDeadband(double axisValue) {
    return axisDeadband.map(aDouble -> MathUtil.applyDeadband(axisValue, aDouble)).orElse(axisValue);
  }

  /**
   * Apply the scalar value if it exists.
   *
   * @param axisValue Axis value to apply the scalar to.
   * @return Axis value scaled by scalar value.
   */
  private double applyRotationalScalar(double axisValue) {
    return omegaAxisScale.map(supplier -> axisValue * supplier.getAsDouble()).orElse(axisValue);
  }

  /**
   * Scale the translational axis by the {@link SwerveInputStream#translationAxisScale} if it
   * exists.
   *
   * @param xAxis X axis to scale.
   * @param yAxis Y axis to scale.
   * @return Scaled {@link Translation2d}
   */
  private Translation2d applyTranslationScalar(double xAxis, double yAxis) {
    return translationAxisScale.map(supplier -> SwerveDriveConfig.scaleTranslation(new Translation2d(xAxis, yAxis), supplier.getAsDouble())).orElseGet(() -> new Translation2d(xAxis, yAxis));
  }

  /**
   * Apply the cube transformation on the given {@link Translation2d}
   *
   * @param translation {@link Translation2d} representing controller input
   * @return Cubed {@link Translation2d} if the {@link SwerveInputStream#translationCube} is
   *         present.
   */
  private Translation2d applyTranslationCube(Translation2d translation) {
    if (translationCube.isPresent() && translationCube.get().getAsBoolean()) {
      return SwerveDriveConfig.cubeTranslation(translation);
    }
    return translation;
  }

  /**
   * Apply the cube transformation on the given rotation controller axis
   *
   * @param rotationAxis Rotation controller axis to cube.
   * @return Cubed axis value if the {@link SwerveInputStream#omegaCube} is present.
   */
  private double applyOmegaCube(double rotationAxis) {
    if (omegaCube.isPresent() && omegaCube.get().getAsBoolean()) {
      return Math.pow(rotationAxis, 3);
    }
    return rotationAxis;
  }

  /**
   * Change {@link ChassisVelocities} from robot relative if enabled.
   *
   * @param fieldRelativeSpeeds Field or robot relative speeds to translate into robot-relative
   *                            speeds.
   * @return Field relative {@link ChassisVelocities}.
   */
  private ChassisVelocities applyRobotRelativeTranslation(ChassisVelocities fieldRelativeSpeeds) {
    if (robotRelative.isPresent() && robotRelative.get().getAsBoolean()) {
      return fieldRelativeSpeeds.toFieldRelative(swerveDrive.getGyroRotation3d().toRotation2d());
    }
    return fieldRelativeSpeeds;
  }

  /**
   * Apply alliance aware translation which flips the {@link Translation2d} if the robot is on the
   * Red alliance. Skipped while robot relative control is enabled, since robot relative translation
   * does not depend on the alliance.
   *
   * @param fieldRelativeTranslation Field-relative {@link Translation2d} to flip.
   * @return Alliance-oriented {@link Translation2d}
   */
  private Translation2d applyAllianceAwareTranslation(Translation2d fieldRelativeTranslation) {
    if (robotRelative.isPresent() && robotRelative.get().getAsBoolean()) {
      return fieldRelativeTranslation;
    }
    if (allianceRelative.isPresent() && allianceRelative.get().getAsBoolean()) {
      if (MatchState.getAlliance().isPresent() && MatchState.getAlliance().get() == Alliance.RED) {
        return fieldRelativeTranslation.rotateBy(Rotation2d.k180deg);
      }
    }
    return fieldRelativeTranslation;
  }

  /**
   * Adds offset to translation if one is set.
   *
   * @param speeds {@link ChassisVelocities} to offset
   * @return Offsetted {@link ChassisVelocities}
   */
  private ChassisVelocities applyTranslationHeadingOffset(ChassisVelocities speeds) {
    if (translationHeadingOffsetEnabled.isPresent() && translationHeadingOffsetEnabled.get().getAsBoolean()) {
      if (translationHeadingOffset.isPresent()) {
        Translation2d speedsTranslation = new Translation2d(speeds.vx, speeds.vy).rotateBy(translationHeadingOffset.get());
        return new ChassisVelocities(speedsTranslation.getX(), speedsTranslation.getY(), speeds.omega);
      }
    }
    return speeds;
  }

  /**
   * Get the rotation PID controller needed by the heading, aim, and translation only modes.
   *
   * @param config {@link SwerveDriveConfig} of the drive.
   * @return Rotation PID controller.
   * @throws SwerveDriveConfigurationException if no rotation PID controller is configured.
   */
  private static PIDController requireRotationPID(SwerveDriveConfig<?> config) {
    return config.getRotationPID().orElseThrow(() -> new SwerveDriveConfigurationException("No rotation PID controller configured", "Heading, aim, and translation only control are unavailable", "withRotationController(PIDController)"));
  }

  /**
   * Calculate the {@link ChassisVelocities} for the current controller inputs and active mode.
   *
   * @return Field relative {@link ChassisVelocities} for the current inputs.
   * @throws SwerveDriveConfigurationException if translation only mode is active (including the
   *                                           fallback to translation only mode when no
   *                                           controller rotation axis is set) and no rotation PID
   *                                           controller is configured.
   * @throws SwerveDriveConfigurationException if heading mode is active and no rotation PID
   *                                           controller is configured.
   * @throws SwerveDriveConfigurationException if aim mode is active and no rotation PID controller
   *                                           is configured.
   * @throws NoSuchElementException            if heading mode is requested without a heading
   *                                           configured and no controller rotation axis is set,
   *                                           so the stream falls back to angular velocity mode
   *                                           without an axis.
   * @throws NoSuchElementException            if aim mode is requested without an aim target
   *                                           configured and no controller rotation axis is set,
   *                                           so the stream falls back to angular velocity mode
   *                                           without an axis.
   */
  @Override
  public ChassisVelocities get() {
    var config = swerveDrive.getConfig();
    double maximumChassisVelocity = config.getMaximumChassisLinearVelocity().orElse(maximumChassisLinearVelocity).in(MetersPerSecond);
    double maximumChassisRotVelocity = config.getMaximumChassisAngularVelocity().orElse(maximumChassisAngularVelocity).in(RadiansPerSecond);
    Translation2d scaledTranslation = applyTranslationScalar(applyDeadband(controllerTranslationX.getAsDouble()), applyDeadband(controllerTranslationY.getAsDouble()));
    scaledTranslation = applyTranslationCube(scaledTranslation);
    scaledTranslation = applyAllianceAwareTranslation(scaledTranslation);

    double vxMetersPerSecond = scaledTranslation.getX() * maximumChassisVelocity;
    double vyMetersPerSecond = scaledTranslation.getY() * maximumChassisVelocity;
    double omegaRadiansPerSecond = 0;
    ChassisVelocities speeds = new ChassisVelocities();

    SwerveInputMode newMode = findMode();
    // Handle transitions here.
    if (currentMode != newMode) {
      transitionMode(newMode);
    }
    switch (newMode) {
      case TRANSLATION_ONLY -> {
        var azimuthPIDs = requireRotationPID(config);

        omegaRadiansPerSecond = azimuthPIDs.calculate(swerveDrive.getGyroRotation3d().getZ(), lockedHeading.orElseThrow().getRadians());
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
      case ANGULAR_VELOCITY -> {
        omegaRadiansPerSecond = applyOmegaCube(applyRotationalScalar(applyDeadband(controllerOmega.orElseThrow().getAsDouble()))) * maximumChassisRotVelocity;
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
      case HEADING -> {
        var azimuthPIDs = requireRotationPID(config);
        omegaRadiansPerSecond = azimuthPIDs.calculate(swerveDrive.getGyroRotation3d().getZ(), headingSupplier.orElseThrow().get().in(Radians));

        // Prevent rotation if controller heading inputs are not past axisDeadband
        if (controllerHeadingX.isPresent() && controllerHeadingY.isPresent() && axisDeadband.isPresent() &&
            Math.abs(controllerHeadingX.get().getAsDouble()) + Math.abs(controllerHeadingY.get().getAsDouble()) < axisDeadband.get()) {
          omegaRadiansPerSecond = 0;
        }
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
      case AIM -> {
        var azimuthPIDs = requireRotationPID(config);
        Rotation2d currentHeading = swerveDrive.getGyroRotation3d().toRotation2d();
        Translation2d relativeTrl = aimTarget.orElseThrow().get().relativeTo(swerveDrive.getPose()).getTranslation();
        Rotation2d target = new Rotation2d(relativeTrl.getX(), relativeTrl.getY()).plus(currentHeading);
        omegaRadiansPerSecond = azimuthPIDs.calculate(currentHeading.getRadians(), target.getRadians());
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
    }

    currentMode = newMode;

    return applyTranslationHeadingOffset(applyRobotRelativeTranslation(speeds));
  }

  /**
   * Drive modes to keep track of.
   */
  enum SwerveInputMode {
    /**
     * Translation only mode, does not allow for rotation and maintains current heading.
     */
    TRANSLATION_ONLY,
    /**
     * Output based off angular velocity
     */
    ANGULAR_VELOCITY,
    /**
     * Output based off of heading.
     */
    HEADING,
    /**
     * Output based off of targeting.
     */
    AIM
  }
}
