// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.commands3.swerve;

import java.util.function.Supplier;
import org.wpilib.command3.Command;
import org.wpilib.command3.Mechanism;
import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.kinematics.ChassisVelocities;
import org.wpilib.tunable.Tunables;
import org.wpilib.units.measure.Angle;
import org.wpilib.units.measure.Distance;
import yams.commands3.config.SwerveDriveConfig;
import yams.commands3.telemetry.CommandTunable;
import yams.core.exceptions.SmartMotorControllerConfigurationException;
import yams.core.exceptions.SwerveDriveConfigurationException;

/**
 * Command-based extension of {@link yams.core.mechanisms.swerve.SwerveDrive} that adds the
 * {@link Mechanism} binding and {@link Command} factories.
 *
 * <p>The typical pattern is to wrap {@code SwerveDrive} inside a class implementing
 * {@link Mechanism}.
 *
 * <pre>{@code
 * public class SwerveSubsystem implements Mechanism {
 *     private final SwerveDrive drive;
 *
 *     public SwerveSubsystem() {
 *         drive = new SwerveDrive(new SwerveDriveConfig(this, modules)....);
 *     }
 *
 *     public Command driveWithJoystick(CommandNiDsXboxController controller) {
 *         return drive.drive(() -> new ChassisVelocities(...));
 *     }
 *
 *     public Command driveFieldRelative(Supplier<ChassisVelocities> speedsSupplier) {
 *         return run(coroutine -> {
 *             while (true) {
 *                 drive.setFieldRelativeChassisSpeeds(speedsSupplier.get());
 *                 coroutine.yield();
 *             }
 *         }).named("Drive Field Relative");
 *     }
 * }
 * }</pre>
 */
public class SwerveDrive extends yams.core.mechanisms.swerve.SwerveDrive {
  /** Mechanism the drive's commands should require. */
  private final Mechanism mechanism;

  /**
   * Construct a {@link SwerveDrive}.
   *
   * @param config {@link SwerveDriveConfig} to use, with a {@link Mechanism} set via
   *               {@code withMechanism(Mechanism)}.
   * @throws IllegalStateException                      on a real robot (not in simulation), if no
   *                                                    gyro supplier was set with
   *                                                    {@code withGyro(Supplier)}.
   * @throws SmartMotorControllerConfigurationException if a module's drive motor has no mechanism
   *                                                    circumference configured (e.g. via
   *                                                    {@code SwerveModuleConfig.withWheelRadius(Distance)}).
   */
  public SwerveDrive(SwerveDriveConfig config) {
    super(config);
    this.mechanism = config.getMechanism();
    // Drive to pose tuning needs both controllers, so only offer it when they are configured.
    if (config.getTranslationPID().isPresent() && config.getRotationPID().isPresent()) {
      Tunables.publish("Mechanisms/" + getName() + "/tuning", new CommandTunable(Command.noRequirements(coroutine -> {
        startDriveToPoseTuning();
        while (true) {
          applyTuningValues();
          coroutine.yield();
        }
      }).named(getName() + " Tuning")));
    }
  }

  /**
   * Mechanism the drive's commands require.
   *
   * @return {@link Mechanism} for the drive.
   */
  public Mechanism getMechanism() {
    return mechanism;
  }

  /**
   * Create a {@link Command} to drive the swerve drive with robot relative chassis speeds.
   *
   * @param robotRelativeChassisSpeeds {@link Supplier} of {@link ChassisVelocities} for the robot
   *                                   relative chassis speeds. For driver input, use a
   *                                   {@link SwerveInputStream} (field relative) in your own drive
   *                                   loop instead.
   * @return {@link Command} to drive the swerve drive.
   * @implNote Not compatible with AdvantageKit
   * @throws IllegalStateException when the returned command runs, if a gyro angular velocity
   *                               scale factor is configured but no gyro supplier was set with
   *                               {@code withGyro(Supplier)}.
   */
  public Command drive(Supplier<ChassisVelocities> robotRelativeChassisSpeeds) {
    return mechanism.run(coroutine -> {
      while (true) {
        setRobotRelativeChassisSpeeds(robotRelativeChassisSpeeds.get());
        coroutine.yield();
      }
    }).named("Drive");
  }

  /**
   * Drive the robot to the given pose. The command runs until it is canceled and stops the drive
   * when it is.
   *
   * @param pose {@link Pose2d} to drive the robot to. Field relative, blue-origin where 0deg is
   *             facing towards RED
   * @return {@link Command} to drive the robot to the given pose.
   * @implNote Not compatible with AdvantageKit
   * @throws SwerveDriveConfigurationException when the returned command runs, if the
   *                                           translation PID controller is not configured.
   * @throws SwerveDriveConfigurationException when the returned command runs, if the rotation
   *                                           PID controller is not configured.
   * @throws IllegalStateException when the returned command runs, if a gyro angular velocity
   *                               scale factor is configured but no gyro supplier was set with
   *                               {@code withGyro(Supplier)}.
   */
  public Command driveToPose(Pose2d pose) {
    return mechanism.run(coroutine -> {
      startDriveToPoseTuning();
      while (true) {
        // driveToPoseSetpoint already returns robot relative speeds.
        setRobotRelativeChassisSpeeds(driveToPoseSetpoint(pose));
        coroutine.yield();
      }
    }).whenCanceled(this::stop).named("Drive to Pose");
  }

  /**
   * Drive the robot to the given pose, ending once the robot is within the given tolerances. The
   * drive is stopped when the command ends or is canceled.
   *
   * @param pose                 {@link Pose2d} to drive the robot to. Field relative, blue-origin
   *                             where 0deg is facing towards RED
   * @param translationTolerance Maximum distance from the pose to be considered at the pose.
   * @param rotationTolerance    Maximum heading error from the pose to be considered at the pose.
   * @return {@link Command} to drive the robot to the given pose.
   * @implNote Not compatible with AdvantageKit
   * @throws SwerveDriveConfigurationException when the returned command runs, if the
   *                                           translation PID controller is not configured.
   * @throws SwerveDriveConfigurationException when the returned command runs, if the rotation
   *                                           PID controller is not configured.
   * @throws IllegalStateException when the returned command runs, if a gyro angular velocity
   *                               scale factor is configured but no gyro supplier was set with
   *                               {@code withGyro(Supplier)}.
   */
  public Command driveToPose(Pose2d pose, Distance translationTolerance, Angle rotationTolerance) {
    return mechanism.run(coroutine -> {
      startDriveToPoseTuning();
      while (!isNear(pose, translationTolerance, rotationTolerance)) {
        // driveToPoseSetpoint already returns robot relative speeds.
        setRobotRelativeChassisSpeeds(driveToPoseSetpoint(pose));
        coroutine.yield();
      }
      stop();
    }).whenCanceled(this::stop).named("Drive to Pose");
  }
}
