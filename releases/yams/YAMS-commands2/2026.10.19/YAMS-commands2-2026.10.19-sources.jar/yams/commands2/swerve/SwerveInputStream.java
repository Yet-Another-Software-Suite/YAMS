// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

package yams.commands2.swerve;

import static org.wpilib.units.Units.Meters;
import static org.wpilib.units.Units.MetersPerSecond;
import static org.wpilib.units.Units.Radians;
import static org.wpilib.units.Units.RadiansPerSecond;
import static org.wpilib.units.Units.RotationsPerSecond;
import static org.wpilib.units.Units.Seconds;

import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import org.wpilib.driverstation.Alliance;
import org.wpilib.driverstation.DriverStationErrors;
import org.wpilib.driverstation.MatchState;
import org.wpilib.driverstation.NiDsXboxController;
import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.geometry.Translation2d;
import org.wpilib.math.kinematics.ChassisVelocities;
import org.wpilib.math.util.MathUtil;
import org.wpilib.units.measure.Angle;
import org.wpilib.units.measure.AngularVelocity;
import org.wpilib.units.measure.LinearVelocity;
import org.wpilib.units.measure.Time;
import org.wpilib.math.controller.PIDController;
import org.wpilib.math.controller.SimpleMotorFeedforward;
import org.wpilib.command2.button.Trigger;
import yams.commands2.telemetry.SwerveInputStreamTelemetry;
import yams.core.exceptions.SwerveDriveConfigurationException;
import yams.core.mechanisms.config.SwerveDriveConfig;
import yams.core.mechanisms.swerve.SwerveDrive;
import yams.core.telemetry.enums.TelemetryVerbosity;

/**
 * Helper class to easily transform controller inputs into workable chassis speeds. Inspired by SciBorgs FRC 1155.
 *
 * <h2>Joystick-to-{@link yams.core.mechanisms.swerve.SwerveDrive} adapter</h2>
 * <p>
 * {@link SwerveInputStream} acts as a bridge between raw controller axis values (in the range
 * {@code [-1, 1]}) and the {@link ChassisVelocities} that
 * {@link yams.core.mechanisms.swerve.SwerveDrive} expects. It handles deadbands, axis scaling, non-linear
 * (cubed) response curves, field-relative / alliance-relative flipping, and multiple drive modes
 * (angular-velocity, heading-snap, translation-only, aim-at-target). Because it
 * implements
 * {@link java.util.function.Supplier}{@code <}{@link ChassisVelocities}{@code >} it can be passed
 * directly to a command that calls {@code swerveDrive.drive(inputStream.get())}.
 * </p>
 *
 * <h2>Typical usage with an {@link NiDsXboxController}</h2>
 * <pre>{@code
 * NiDsXboxController driver = new NiDsXboxController(0);
 *
 * // Angular-velocity stream: left stick translates, right stick X rotates
 * SwerveInputStream angularVelocityStream =
 *     SwerveInputStream.of(swerveDrive,
 *                          () -> -driver.getLeftY(),   // forward/back
 *                          () -> -driver.getLeftX())   // strafe
 *                      .withControllerRotationAxis(driver::getRightX)
 *                      .withDeadband(0.05)
 *                      .withScaleTranslation(0.8)
 *                      .withScaleRotation(0.6)
 *                      .withAllianceRelativeControl()  // auto-flip for Red alliance
 *                      .withCubeTranslationControllerAxis(); // non-linear response
 *
 * // Heading-snap variant: right stick X/Y picks a desired heading angle
 * SwerveInputStream headingStream = angularVelocityStream.clone()
 *     .withControllerHeadingAxis(driver::getRightX, driver::getRightY)
 *     .withHeadingControl(() -> driver.getRightStickButton());
 *
 * // In your periodic or a command, call .get() to obtain field relative ChassisVelocities:
 * swerveDrive.setFieldRelativeChassisSpeeds(angularVelocityStream.get());
 * }</pre>
 */
public class SwerveInputStream implements Supplier<ChassisVelocities> {
  /** Translation suppliers. */
  private final DoubleSupplier controllerTranslationX;
  /** Translational supplier. */
  private final DoubleSupplier controllerTranslationY;
  /** {@link SwerveDrive} object for transformations. */
  private final SwerveDrive swerveDrive;
  /** Rotation supplier as angular velocity. */
  private Optional<DoubleSupplier> controllerOmega = Optional.empty();
  /** Controller heading axis X, kept to hold the heading while the stick is inside the deadband. */
  private Optional<DoubleSupplier> controllerHeadingX = Optional.empty();
  /** Controller heading axis Y, kept to hold the heading while the stick is inside the deadband. */
  private Optional<DoubleSupplier> controllerHeadingY = Optional.empty();
  /** Field relative heading to face in {@link SwerveInputMode#HEADING}. */
  private Optional<Supplier<Angle>> headingSupplier = Optional.empty();
  /** Axis deadband for the controller. */
  private Optional<Double> axisDeadband = Optional.empty();
  /** Translational axis scalar value, should be between (0, 1]. */
  private Optional<Double> translationAxisScale = Optional.empty();
  /** Angular velocity axis scalar value, should be between (0, 1] */
  private Optional<Double> omegaAxisScale = Optional.empty();
  /** Target to aim at. */
  private Optional<Supplier<Pose2d>> aimTarget = Optional.empty();
  /** Output {@link ChassisVelocities} based on heading while this is True. */
  private Optional<BooleanSupplier> headingEnabled = Optional.empty();
  /** Locked heading for {@link SwerveInputMode#TRANSLATION_ONLY} */
  private Optional<Rotation2d> lockedHeading = Optional.empty();
  /** Output {@link ChassisVelocities} based on aim while this is True. */
  private Optional<BooleanSupplier> aimEnabled = Optional.empty();
  /** Maintain current heading and drive without rotating, ideally. */
  private Optional<BooleanSupplier> translationOnlyEnabled = Optional.empty();
  /** Cube the translation magnitude from the controller. */
  private Optional<BooleanSupplier> translationCube = Optional.empty();
  /** Cube the angular velocity axis from the controller. */
  private Optional<BooleanSupplier> omegaCube = Optional.empty();
  /** Robot relative oriented output expected. */
  private Optional<BooleanSupplier> robotRelative = Optional.empty();
  /** Field oriented chassis output is relative to your current alliance. */
  private Optional<BooleanSupplier> allianceRelative = Optional.empty();
  /** Heading offset enable state. */
  private Optional<BooleanSupplier> translationHeadingOffsetEnabled = Optional.empty();
  /** Heading offset to apply during heading based control. */
  private Optional<Rotation2d> translationHeadingOffset = Optional.empty();
  /** Time to look ahead along the robot's velocity when aiming. */
  private Optional<Time> aimLookahead = Optional.empty();
  /** Feedforward added to the aim rotation. */
  private Optional<SimpleMotorFeedforward> aimFeedforward = Optional.empty();
  /** Offset applied to the aim heading. */
  private Optional<Rotation2d> aimHeadingOffset = Optional.empty();
  /** Aim heading offset enable state. */
  private Optional<BooleanSupplier> aimHeadingOffsetEnabled = Optional.empty();
  /** Heading the robot is turning to in {@link SwerveInputMode#AIM}, in the gyro's frame. */
  private Optional<Rotation2d> aimGoalHeading = Optional.empty();
  /** Current {@link SwerveInputMode} to use. */
  private SwerveInputMode currentMode = SwerveInputMode.ANGULAR_VELOCITY;
  /** Maximum chassis velocity, defaults to 4 Meters per Second */
  private LinearVelocity maximumChassisLinearVelocity = MetersPerSecond.of(4);
  /** Maximum chassis angular velocity, defaults to 1 Rotation per Second. */
  private AngularVelocity maximumChassisAngularVelocity = RotationsPerSecond.of(1);
  private Optional<SwerveInputStreamTelemetry> telemetry = Optional.empty();

  private SwerveInputStream(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y) {
    controllerTranslationX = x;
    controllerTranslationY = y;
    swerveDrive = drive;
    // Start from the drive's maximum chassis speeds; withMaximum*Velocity and live tuning override them.
    drive.getConfig().getMaximumChassisLinearVelocity().ifPresent(velocity -> maximumChassisLinearVelocity = velocity);
    drive.getConfig().getMaximumChassisAngularVelocity().ifPresent(velocity -> maximumChassisAngularVelocity = velocity);
  }

  /**
   * Create a {@link SwerveInputStream} that rotates the robot with an angular velocity axis.
   *
   * @param drive {@link SwerveDrive} the stream drives.
   * @param x     Field relative X (forward) translation axis, in [-1, 1].
   * @param y     Field relative Y (left) translation axis, in [-1, 1].
   * @param rot   Angular velocity axis, counter-clockwise positive, in [-1, 1].
   */
  public SwerveInputStream(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y, DoubleSupplier rot) {
    this(drive, x, y);
    controllerOmega = Optional.of(rot);
  }

  /**
   * Create a {@link SwerveInputStream} that turns the robot to face the direction a controller stick points.
   * Heading control is only used while {@link #withHeadingControl(BooleanSupplier)} is true.
   *
   * @param drive    {@link SwerveDrive} the stream drives.
   * @param x        Field relative X (forward) translation axis, in [-1, 1].
   * @param y        Field relative Y (left) translation axis, in [-1, 1].
   * @param headingX Heading stick X axis, in [-1, 1].
   * @param headingY Heading stick Y axis, in [-1, 1].
   */
  public SwerveInputStream(
      SwerveDrive drive,
      DoubleSupplier x,
      DoubleSupplier y,
      DoubleSupplier headingX,
      DoubleSupplier headingY) {
    this(drive, x, y);
    withControllerHeadingAxis(headingX, headingY);
  }

  /**
   * Create a {@link SwerveInputStream} with only translation axes. Add rotation with
   * {@link #withControllerRotationAxis(DoubleSupplier)} or
   * {@link #withControllerHeadingAxis(DoubleSupplier, DoubleSupplier)}.
   *
   * @param drive {@link SwerveDrive} the stream drives.
   * @param x     Field relative X (forward) translation axis, in [-1, 1].
   * @param y     Field relative Y (left) translation axis, in [-1, 1].
   * @return A new {@link SwerveInputStream}.
   */
  public static SwerveInputStream of(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y) {
    return new SwerveInputStream(drive, x, y);
  }

  /**
   * Create a {@link SwerveInputStream} that rotates the robot with an angular velocity axis.
   *
   * @param drive {@link SwerveDrive} the stream drives.
   * @param x     Field relative X (forward) translation axis, in [-1, 1].
   * @param y     Field relative Y (left) translation axis, in [-1, 1].
   * @param rot   Angular velocity axis, counter-clockwise positive, in [-1, 1].
   * @return A new {@link SwerveInputStream}.
   */
  public static SwerveInputStream of(SwerveDrive drive, DoubleSupplier x, DoubleSupplier y, DoubleSupplier rot) {
    return new SwerveInputStream(drive, x, y, rot);
  }

  private SwerveInputStream(SwerveInputStream cfg) {
    swerveDrive = cfg.swerveDrive;
    controllerTranslationX = cfg.controllerTranslationX;
    controllerTranslationY = cfg.controllerTranslationY;
    controllerOmega = cfg.controllerOmega;
    controllerHeadingX = cfg.controllerHeadingX;
    controllerHeadingY = cfg.controllerHeadingY;
    axisDeadband = cfg.axisDeadband;
    translationAxisScale = cfg.translationAxisScale;
    omegaAxisScale = cfg.omegaAxisScale;
    aimTarget = cfg.aimTarget;
    headingEnabled = cfg.headingEnabled;
    headingSupplier = cfg.headingSupplier;
    aimEnabled = cfg.aimEnabled;
    currentMode = cfg.currentMode;
    translationOnlyEnabled = cfg.translationOnlyEnabled;
    lockedHeading = cfg.lockedHeading;
    omegaCube = cfg.omegaCube;
    translationCube = cfg.translationCube;
    robotRelative = cfg.robotRelative;
    allianceRelative = cfg.allianceRelative;
    translationHeadingOffsetEnabled = cfg.translationHeadingOffsetEnabled;
    translationHeadingOffset = cfg.translationHeadingOffset;
    aimLookahead = cfg.aimLookahead;
    aimFeedforward = cfg.aimFeedforward;
    aimHeadingOffset = cfg.aimHeadingOffset;
    aimHeadingOffsetEnabled = cfg.aimHeadingOffsetEnabled;
    maximumChassisLinearVelocity = cfg.maximumChassisLinearVelocity;
    maximumChassisAngularVelocity = cfg.maximumChassisAngularVelocity;
    // Telemetry is bound to the stream it was created for, so a clone starts without any.
  }

  @Override
  public SwerveInputStream clone() {
    return new SwerveInputStream(this);
  }

  /**
   * Get the name of the drive mode used by the last {@link #get()} call.
   *
   * @return Mode name, e.g. {@code ANGULAR_VELOCITY}, {@code HEADING}, {@code AIM} or {@code TRANSLATION_ONLY}.
   */
  public String getCurrentModeName() {
    return currentMode.name();
  }

  /**
   * Get the controller axis deadband.
   *
   * @return Axis deadband, 0 when none is applied.
   */
  public double getAxisDeadband() {
    return axisDeadband.orElse(0.0);
  }

  /**
   * Set the controller axis deadband.
   *
   * @param deadband Deadband applied to every axis, 0 to disable.
   */
  public void setAxisDeadband(double deadband) {
    axisDeadband = deadband == 0 ? Optional.empty() : Optional.of(deadband);
  }

  /**
   * Get the translation axis scalar.
   *
   * @return Translation axis scalar, 1 when unscaled.
   */
  public double getTranslationAxisScale() {
    return translationAxisScale.orElse(1.0);
  }

  /**
   * Set the translation axis scalar.
   *
   * @param scale Scalar in (0, 1] applied to the translation axes, 0 to disable.
   */
  public void setTranslationAxisScale(double scale) {
    translationAxisScale = scale == 0 ? Optional.empty() : Optional.of(scale);
  }

  /**
   * Get the angular velocity axis scalar.
   *
   * @return Angular velocity axis scalar, 1 when unscaled.
   */
  public double getOmegaAxisScale() {
    return omegaAxisScale.orElse(1.0);
  }

  /**
   * Set the angular velocity axis scalar.
   *
   * @param scale Scalar in (0, 1] applied to the angular velocity axis, 0 to disable.
   */
  public void setOmegaAxisScale(double scale) {
    omegaAxisScale = scale == 0 ? Optional.empty() : Optional.of(scale);
  }

  /**
   * Get the chassis linear velocity a full translation axis maps to.
   *
   * @return Maximum chassis linear velocity.
   */
  public LinearVelocity getMaximumChassisLinearVelocity() {
    return maximumChassisLinearVelocity;
  }

  /**
   * Set the chassis linear velocity a full translation axis maps to.
   *
   * @param velocity Maximum chassis linear velocity.
   */
  public void setMaximumChassisLinearVelocity(LinearVelocity velocity) {
    maximumChassisLinearVelocity = velocity;
  }

  /**
   * Get the chassis angular velocity a full angular velocity axis maps to.
   *
   * @return Maximum chassis angular velocity.
   */
  public AngularVelocity getMaximumChassisAngularVelocity() {
    return maximumChassisAngularVelocity;
  }

  /**
   * Set the chassis angular velocity a full angular velocity axis maps to.
   *
   * @param velocity Maximum chassis angular velocity.
   */
  public void setMaximumChassisAngularVelocity(AngularVelocity velocity) {
    maximumChassisAngularVelocity = velocity;
  }

  /**
   * Check if the translation magnitude is cubed, for finer control near the center of the stick.
   *
   * @return True if translation cubing is enabled.
   */
  public boolean isTranslationCubeEnabled() {
    return translationCube.isPresent() && translationCube.get().getAsBoolean();
  }

  /**
   * Enable or disable cubing the translation magnitude.
   *
   * @param enabled True to cube the translation magnitude.
   */
  public void setTranslationCubeEnabled(boolean enabled) {
    translationCube = enabled ? Optional.of(() -> true) : Optional.empty();
  }

  /**
   * Check if the angular velocity axis is cubed, for finer control near the center of the stick.
   *
   * @return True if angular velocity cubing is enabled.
   */
  public boolean isOmegaCubeEnabled() {
    return omegaCube.isPresent() && omegaCube.get().getAsBoolean();
  }

  /**
   * Enable or disable cubing the angular velocity axis.
   *
   * @param enabled True to cube the angular velocity axis.
   */
  public void setOmegaCubeEnabled(boolean enabled) {
    omegaCube = enabled ? Optional.of(() -> true) : Optional.empty();
  }

  /**
   * Check if translation is flipped 180 degrees while on the red alliance.
   *
   * @return True if alliance relative control is enabled.
   */
  public boolean isAllianceRelativeEnabled() {
    return allianceRelative.isPresent() && allianceRelative.get().getAsBoolean();
  }

  /**
   * Enable or disable flipping translation 180 degrees while on the red alliance.
   *
   * @param enabled True to enable alliance relative control.
   */
  public void setAllianceRelativeEnabled(boolean enabled) {
    allianceRelative = enabled ? Optional.of(() -> true) : Optional.empty();
  }

  /**
   * Check if the translation axes are treated as robot relative.
   *
   * @return True if robot relative control is enabled.
   */
  public boolean isRobotRelativeEnabled() {
    return robotRelative.isPresent() && robotRelative.get().getAsBoolean();
  }

  /**
   * Enable or disable treating the translation axes as robot relative.
   *
   * @param enabled True to enable robot relative control.
   */
  public void setRobotRelativeEnabled(boolean enabled) {
    robotRelative = enabled ? Optional.of(() -> true) : Optional.empty();
  }

  /**
   * Publish this stream's telemetry under {@code SwerveInputStream/<name>}, updated every time the stream is read. At
   * {@link TelemetryVerbosity#HIGH} the stream is also live tunable: see {@link SwerveInputStreamTelemetry}. Replaces
   * any telemetry this stream already had. A {@link #clone()} does not copy the telemetry.
   *
   * @param name      Name of the stream in NetworkTables (e.g., "drive").
   * @param verbosity {@link TelemetryVerbosity} to publish at.
   * @return this, for chaining.
   */
  public SwerveInputStream withTelemetry(String name, TelemetryVerbosity verbosity) {
    telemetry.ifPresent(SwerveInputStreamTelemetry::close);
    telemetry = Optional.of(new SwerveInputStreamTelemetry(this, name, verbosity));
    return this;
  }

  /**
   * Get this stream's telemetry, created by {@link #withTelemetry(String, TelemetryVerbosity)}.
   *
   * @return The {@link SwerveInputStreamTelemetry}, or empty if telemetry is not enabled.
   */
  public Optional<SwerveInputStreamTelemetry> getTelemetry() {
    return telemetry;
  }

  /**
   * Set the chassis linear velocity a full translation axis maps to. Defaults to the drive's maximum chassis linear
   * velocity.
   *
   * @param velocity Maximum chassis linear velocity.
   * @return this, for chaining.
   */
  public SwerveInputStream withMaximumLinearVelocity(LinearVelocity velocity) {
    maximumChassisLinearVelocity = velocity;
    return this;
  }

  /**
   * Set the chassis angular velocity a full angular velocity axis maps to. Defaults to the drive's maximum chassis
   * angular velocity.
   *
   * @param velocity Maximum chassis angular velocity.
   * @return this, for chaining.
   */
  public SwerveInputStream withMaximumAngularVelocity(AngularVelocity velocity) {
    maximumChassisAngularVelocity = velocity;
    return this;
  }

  /**
   * Treat the translation axes as robot relative while enabled. The output is still field relative, and alliance
   * relative flipping is skipped.
   *
   * @param enabled Robot relative control is used while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withRobotRelative(BooleanSupplier enabled) {
    robotRelative = Optional.of(enabled);
    return this;
  }

  /**
   * Always treat the translation axes as robot relative.
   *
   * @return this, for chaining.
   */
  public SwerveInputStream withRobotRelative() {
    return withRobotRelative(() -> true);
  }

  /**
   * Rotate the output translation by an offset while enabled.
   *
   * @param angle   Offset to rotate the translation by.
   * @param enabled The offset is applied while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withTranslationHeadingOffset(Rotation2d angle, BooleanSupplier enabled) {
    translationHeadingOffset = Optional.of(angle);
    translationHeadingOffsetEnabled = Optional.of(enabled);
    return this;
  }

  /**
   * Always rotate the output translation by an offset.
   *
   * @param angle Offset to rotate the translation by.
   * @return this, for chaining.
   */
  public SwerveInputStream withTranslationHeadingOffset(Rotation2d angle) {
    return withTranslationHeadingOffset(angle, () -> true);
  }

  /**
   * Always flip translation 180 degrees while on the red alliance, so forward is away from the driver station.
   *
   * @return this, for chaining.
   */
  public SwerveInputStream withAllianceRelativeControl() {
    return withAllianceRelativeControl(() -> true);
  }

  /**
   * Flip translation 180 degrees while on the red alliance, so forward is away from the driver station.
   *
   * @param enabled Alliance relative control is used while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withAllianceRelativeControl(BooleanSupplier enabled) {
    allianceRelative = Optional.ofNullable(enabled);
    return this;
  }

  /**
   * Cube the angular velocity axis while enabled, for finer control near the center of the stick.
   *
   * @param enabled The axis is cubed while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withCubeRotationControllerAxis(BooleanSupplier enabled) {
    omegaCube = Optional.of(enabled);
    return this;
  }

  /**
   * Always cube the angular velocity axis, for finer control near the center of the stick.
   *
   * @return this, for chaining.
   */
  public SwerveInputStream withCubeRotationControllerAxis() {
    return withCubeRotationControllerAxis(() -> true);
  }

  /**
   * Cube the translation magnitude while enabled, for finer control near the center of the stick.
   *
   * @param enabled The magnitude is cubed while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withCubeTranslationControllerAxis(BooleanSupplier enabled) {
    translationCube = Optional.of(enabled);
    return this;
  }

  /**
   * Always cube the translation magnitude, for finer control near the center of the stick.
   *
   * @return this, for chaining.
   */
  public SwerveInputStream withCubeTranslationControllerAxis() {
    return withCubeTranslationControllerAxis(() -> true);
  }

  /**
   * Set the axis used for angular velocity control.
   *
   * @param rot Angular velocity axis, counter-clockwise positive, in [-1, 1].
   * @return this, for chaining.
   */
  public SwerveInputStream withControllerRotationAxis(DoubleSupplier rot) {
    controllerOmega = Optional.of(rot);
    return this;
  }

  /**
   * Face the direction a controller stick points while heading control is enabled. The robot stops turning while
   * the stick is inside the deadband. Replaces any heading from {@link #withHeading(Supplier)}.
   *
   * @param headingX Heading stick X axis, in [-1, 1].
   * @param headingY Heading stick Y axis, in [-1, 1].
   * @return this, for chaining.
   */
  public SwerveInputStream withControllerHeadingAxis(DoubleSupplier headingX, DoubleSupplier headingY) {
    withHeading(() -> Radians.of(Math.atan2(headingX.getAsDouble(), headingY.getAsDouble())));
    controllerHeadingX = Optional.of(headingX);
    controllerHeadingY = Optional.of(headingY);
    return this;
  }

  /**
   * Set the deadband applied to every controller axis.
   *
   * @param deadband Axis deadband, 0 to disable.
   * @return this, for chaining.
   */
  public SwerveInputStream deadband(double deadband) {
    axisDeadband = deadband == 0 ? Optional.empty() : Optional.of(deadband);
    return this;
  }

  /**
   * Set the deadband applied to every controller axis.
   *
   * @param deadband Axis deadband, 0 to disable.
   * @return this, for chaining.
   */
  public SwerveInputStream withDeadband(double deadband) {
    return deadband(deadband);
  }

  /**
   * Scale the translation axes.
   *
   * @param scaleTranslation Scalar in (0, 1], 0 to disable.
   * @return this, for chaining.
   */
  public SwerveInputStream withScaleTranslation(double scaleTranslation) {
    translationAxisScale = scaleTranslation == 0 ? Optional.empty() : Optional.of(scaleTranslation);
    return this;
  }

  /**
   * Scale the angular velocity axis.
   *
   * @param scaleRotation Scalar in (0, 1], 0 to disable.
   * @return this, for chaining.
   */
  public SwerveInputStream withScaleRotation(double scaleRotation) {
    omegaAxisScale = scaleRotation == 0 ? Optional.empty() : Optional.of(scaleRotation);
    return this;
  }

  /**
   * Face the heading from {@link #withHeading(Supplier)} or
   * {@link #withControllerHeadingAxis(DoubleSupplier, DoubleSupplier)} while enabled. Requires a rotation controller
   * on the {@link SwerveDrive}.
   *
   * @param trigger Heading control is used while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withHeadingControl(BooleanSupplier trigger) {
    headingEnabled = Optional.of(trigger);
    return this;
  }

  /**
   * Set the field relative heading to face while heading control is enabled. Replaces any controller heading axis.
   *
   * @param heading Field relative heading supplier.
   * @return this, for chaining.
   */
  public SwerveInputStream withHeading(Supplier<Angle> heading) {
    headingSupplier = Optional.ofNullable(heading);
    controllerHeadingX = Optional.empty();
    controllerHeadingY = Optional.empty();
    return this;
  }

  /**
   * Face a target pose while enabled. Requires a rotation controller on the {@link SwerveDrive}.
   *
   * @param aimTarget Field relative pose to aim at, null for no target.
   * @param trigger   Aiming is used while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withAim(Supplier<Pose2d> aimTarget, BooleanSupplier trigger) {
    this.aimTarget = Optional.ofNullable(aimTarget);
    aimEnabled = Optional.of(trigger);
    return this;
  }

  /**
   * Aim from where the robot will be after a delay, instead of where it is now. The pose is moved along the robot's
   * field relative velocity by this time before the direction to the target is worked out.
   *
   * <p>A game piece leaves the robot a moment after the aim was calculated: the camera, the loop, the motors and the
   * feed all take time, and the robot keeps moving through all of it. Add those delays together for a starting
   * value, then tune it. It is often 100 to 200 milliseconds.
   *
   * <p>This assumes the robot keeps its current velocity, so it works best while driving in a straight line.
   *
   * @param lookahead How far ahead in time to estimate the robot's position, null for none.
   * @return this, for chaining.
   */
  public SwerveInputStream withAimLookahead(Time lookahead) {
    aimLookahead = Optional.ofNullable(lookahead);
    return this;
  }

  /**
   * Add a feedforward to the aim rotation, so the robot keeps up with a target whose direction is changing. The
   * feedforward is calculated from the robot's current angular velocity to the angular velocity the rotation
   * controller asks for, and its result is added to that angular velocity.
   *
   * @param feedforward Feedforward in radians, null for none.
   * @return this, for chaining.
   */
  public SwerveInputStream withAimFeedforward(SimpleMotorFeedforward feedforward) {
    aimFeedforward = Optional.ofNullable(feedforward);
    return this;
  }

  /**
   * Rotate the aim heading by an offset while enabled, for a shooter that does not point out of the front of the
   * robot.
   *
   * @param offset  Offset added to the heading that faces the target, counter-clockwise positive.
   * @param enabled The offset is applied while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withAimHeadingOffset(Rotation2d offset, BooleanSupplier enabled) {
    aimHeadingOffset = Optional.ofNullable(offset);
    aimHeadingOffsetEnabled = Optional.of(enabled);
    return this;
  }

  /**
   * Always rotate the aim heading by an offset, for a shooter that does not point out of the front of the robot.
   *
   * @param offset Offset added to the heading that faces the target, counter-clockwise positive.
   * @return this, for chaining.
   */
  public SwerveInputStream withAimHeadingOffset(Rotation2d offset) {
    return withAimHeadingOffset(offset, () -> true);
  }

  /**
   * Check if the robot is aiming and facing its aim heading. Only updates while the stream is being read.
   *
   * @param tolerance How far the robot's heading may be from the aim heading.
   * @return True while aiming is enabled and the heading is within the tolerance.
   */
  public boolean isAimLocked(Angle tolerance) {
    return aimEnabled.isPresent()
        && aimEnabled.get().getAsBoolean()
        && aimGoalHeading.isPresent()
        && Math.abs(aimGoalHeading.get().minus(swerveDrive.getGyroRotation3d().toRotation2d()).getRadians())
            <= tolerance.in(Radians);
  }

  /**
   * {@link Trigger} that is true while the robot is aiming and facing its aim heading.
   *
   * @param tolerance How far the robot's heading may be from the aim heading.
   * @return {@link Trigger} for the aim lock.
   */
  public Trigger aimLock(Angle tolerance) {
    return new Trigger(() -> isAimLocked(tolerance));
  }

  /**
   * Get the field relative vector from the robot to a target, from where the robot will be after the
   * {@link #withAimLookahead(Time)} time if there is one. Useful for shooting on the move.
   *
   * @param target Field relative pose of the target.
   * @return Field relative {@link Translation2d} from the robot to the target.
   */
  public Translation2d getTargetVector(Pose2d target) {
    Translation2d robot = swerveDrive.getPose().getTranslation();
    if (aimLookahead.isPresent()) {
      ChassisVelocities fieldVelocity = swerveDrive.getFieldRelativeSpeed();
      double seconds = aimLookahead.get().in(Seconds);
      robot = robot.plus(new Translation2d(fieldVelocity.vx * seconds, fieldVelocity.vy * seconds));
    }
    return target.getTranslation().minus(robot);
  }

  /**
   * Calculate the angular velocity that turns the robot to a heading, with the {@link SwerveDrive}'s rotation
   * controller and the {@link #withAimFeedforward(SimpleMotorFeedforward)} feedforward if there is one.
   *
   * @param target Heading to face, in the same frame as the gyro.
   * @return {@link AngularVelocity} that turns the robot toward the heading.
   */
  public AngularVelocity calculateAngularVelocity(Angle target) {
    double omegaRadiansPerSecond = requireRotationPID(swerveDrive.getConfig())
        .calculate(swerveDrive.getGyroRotation3d().toRotation2d().getRadians(), target.in(Radians));
    if (aimFeedforward.isPresent()) {
      omegaRadiansPerSecond += aimFeedforward.get()
          .calculate(swerveDrive.getRobotRelativeSpeed().omega, omegaRadiansPerSecond);
    }
    return RadiansPerSecond.of(omegaRadiansPerSecond);
  }

  /**
   * Hold the heading the robot had when enabled and only translate. Requires a rotation controller on the
   * {@link SwerveDrive}.
   *
   * @param trigger Translation only control is used while this is true.
   * @return this, for chaining.
   */
  public SwerveInputStream withTranslationOnly(BooleanSupplier trigger) {
    translationOnlyEnabled = Optional.of(trigger);
    return this;
  }

  private SwerveInputMode findMode() {
    if (translationOnlyEnabled.isPresent() && translationOnlyEnabled.get().getAsBoolean()) {
      return SwerveInputMode.TRANSLATION_ONLY;
    } else if (aimEnabled.isPresent() && aimEnabled.get().getAsBoolean()) {
      if (aimTarget.isPresent()) {
        return SwerveInputMode.AIM;
      } else {
        DriverStationErrors.reportError(
            "Attempting to enter AIM mode without target, please use "
                + "SwerveInputStream.withAim to select a target first!",
            false);
      }
    } else if (headingEnabled.isPresent() && headingEnabled.get().getAsBoolean()) {
      if (headingSupplier.isPresent()) {
        return SwerveInputMode.HEADING;
      } else {
        DriverStationErrors.reportError(
            "Attempting to enter HEADING mode without a heading, please use "
                + "SwerveInputStream.withHeading or SwerveInputStream.withControllerHeadingAxis to add one!",
            false);
      }
    } else if (controllerOmega.isEmpty()) {
      DriverStationErrors.reportError(
          "Attempting to enter ANGULAR_VELOCITY mode without a rotation axis, please use "
              + "SwerveInputStream.withControllerRotationAxis to add angular velocity axis!",
          false);
      return SwerveInputMode.TRANSLATION_ONLY;
    }
    return SwerveInputMode.ANGULAR_VELOCITY;
  }

  private void transitionMode(SwerveInputMode newMode) {
    if (currentMode == SwerveInputMode.AIM) {
      aimGoalHeading = Optional.empty();
    }
    switch (currentMode) {
      case TRANSLATION_ONLY -> {
        lockedHeading = Optional.empty();
        break;
      }
      case ANGULAR_VELOCITY -> {
        break;
      }
      case HEADING, AIM -> {
        swerveDrive.resetRotationPID();
        break;
      }
    }

    switch (newMode) {
      case TRANSLATION_ONLY -> {
        lockedHeading = Optional.of(swerveDrive.getGyroRotation3d().toRotation2d());
        swerveDrive.resetRotationPID();
        break;
      }
      case ANGULAR_VELOCITY -> {
        break;
      }
      case HEADING, AIM -> {
        swerveDrive.resetRotationPID();
        break;
      }
    }
  }

  private double applyDeadband(double axisValue) {
    return axisDeadband.map(aDouble -> MathUtil.applyDeadband(axisValue, aDouble)).orElse(axisValue);
  }

  private double applyRotationalScalar(double axisValue) {
    return omegaAxisScale.map(aDouble -> axisValue * aDouble).orElse(axisValue);
  }

  private Translation2d applyTranslationScalar(double xAxis, double yAxis) {
    return translationAxisScale
        .map(aDouble -> SwerveDriveConfig.scaleTranslation(new Translation2d(xAxis, yAxis), aDouble))
        .orElseGet(() -> new Translation2d(xAxis, yAxis));
  }

  private Translation2d applyTranslationCube(Translation2d translation) {
    if (translationCube.isPresent() && translationCube.get().getAsBoolean()) {
      return SwerveDriveConfig.cubeTranslation(translation);
    }
    return translation;
  }

  private double applyOmegaCube(double rotationAxis) {
    if (omegaCube.isPresent() && omegaCube.get().getAsBoolean()) {
      return Math.pow(rotationAxis, 3);
    }
    return rotationAxis;
  }

  private ChassisVelocities applyRobotRelativeTranslation(ChassisVelocities fieldRelativeSpeeds) {
    if (robotRelative.isPresent() && robotRelative.get().getAsBoolean()) {
      return fieldRelativeSpeeds.toFieldRelative(swerveDrive.getGyroRotation3d().toRotation2d());
    }
    return fieldRelativeSpeeds;
  }

  private Translation2d applyAllianceAwareTranslation(Translation2d fieldRelativeTranslation) {
    if (robotRelative.isPresent() && robotRelative.get().getAsBoolean()) {
      return fieldRelativeTranslation;
    }
    if (allianceRelative.isPresent() && allianceRelative.get().getAsBoolean()) {
      if (MatchState.getAlliance().isPresent() && MatchState.getAlliance().get() == Alliance.RED) {
        return fieldRelativeTranslation.rotateBy(Rotation2d.k180deg);
      }
    }
    return fieldRelativeTranslation;
  }

  private ChassisVelocities applyTranslationHeadingOffset(ChassisVelocities speeds) {
    if (translationHeadingOffsetEnabled.isPresent() && translationHeadingOffsetEnabled.get().getAsBoolean()) {
      if (translationHeadingOffset.isPresent()) {
        Translation2d speedsTranslation = new Translation2d(speeds.vx, speeds.vy)
            .rotateBy(translationHeadingOffset.get());
        return new ChassisVelocities(speedsTranslation.getX(), speedsTranslation.getY(), speeds.omega);
      }
    }
    return speeds;
  }

  private static PIDController requireRotationPID(SwerveDriveConfig<?> config) {
    return config.getRotationPID()
        .orElseThrow(() -> new SwerveDriveConfigurationException(
            "No rotation PID controller configured",
            "Heading, aim, and translation only control are unavailable",
            "Use SwerveDriveConfig.withRotationController to configure a rotation PID controller"));
  }

  @Override
  public ChassisVelocities get() {
    var config = swerveDrive.getConfig();
    double maximumChassisVelocity = maximumChassisLinearVelocity.in(MetersPerSecond);
    double maximumChassisRotVelocity = maximumChassisAngularVelocity.in(RadiansPerSecond);
    Translation2d scaledTranslation =
        applyTranslationScalar(applyDeadband(controllerTranslationX.getAsDouble()), applyDeadband(controllerTranslationY.getAsDouble()));
    scaledTranslation = applyTranslationCube(scaledTranslation);
    scaledTranslation = applyAllianceAwareTranslation(scaledTranslation);

    double vxMetersPerSecond = scaledTranslation.getX() * maximumChassisVelocity;
    double vyMetersPerSecond = scaledTranslation.getY() * maximumChassisVelocity;
    double omegaRadiansPerSecond = 0;
    ChassisVelocities speeds = new ChassisVelocities();

    SwerveInputMode newMode = findMode();
    if (currentMode != newMode) {
      transitionMode(newMode);
    }
    switch (newMode) {
      case TRANSLATION_ONLY -> {
        var azimuthPIDs = requireRotationPID(config);
        omegaRadiansPerSecond =
            azimuthPIDs.calculate(
                swerveDrive.getGyroRotation3d().getZ(), lockedHeading.orElseThrow().getRadians());
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
      case ANGULAR_VELOCITY -> {
        omegaRadiansPerSecond =
            applyOmegaCube(applyRotationalScalar(applyDeadband(controllerOmega.orElseThrow().getAsDouble())))
                * maximumChassisRotVelocity;
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
      case HEADING -> {
        var azimuthPIDs = requireRotationPID(config);
        omegaRadiansPerSecond = azimuthPIDs.calculate(
            swerveDrive.getGyroRotation3d().getZ(), headingSupplier.orElseThrow().get().in(Radians));

        if (controllerHeadingX.isPresent()
            && controllerHeadingY.isPresent()
            && axisDeadband.isPresent()
            && Math.abs(controllerHeadingX.get().getAsDouble())
                    + Math.abs(controllerHeadingY.get().getAsDouble())
                < axisDeadband.get()) {
          omegaRadiansPerSecond = 0;
        }
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
      case AIM -> {
        Rotation2d currentHeading = swerveDrive.getGyroRotation3d().toRotation2d();
        Translation2d targetVector = getTargetVector(aimTarget.orElseThrow().get());
        // The vector is field relative. Turn it into a heading in the gyro's frame.
        Rotation2d target = new Rotation2d(targetVector.getX(), targetVector.getY())
            .minus(swerveDrive.getPose().getRotation())
            .plus(currentHeading);
        if (aimHeadingOffset.isPresent()
            && aimHeadingOffsetEnabled.isPresent()
            && aimHeadingOffsetEnabled.get().getAsBoolean()) {
          target = target.plus(aimHeadingOffset.get());
        }
        aimGoalHeading = Optional.of(target);
        omegaRadiansPerSecond = calculateAngularVelocity(target.getMeasure()).in(RadiansPerSecond);
        speeds = new ChassisVelocities(vxMetersPerSecond, vyMetersPerSecond, omegaRadiansPerSecond);
        break;
      }
    }

    currentMode = newMode;
    ChassisVelocities fieldRelativeSpeeds = applyTranslationHeadingOffset(applyRobotRelativeTranslation(speeds));
    telemetry.ifPresent(SwerveInputStreamTelemetry::updateTelemetry);
    return fieldRelativeSpeeds;
  }

  enum SwerveInputMode {
    TRANSLATION_ONLY,
    ANGULAR_VELOCITY,
    HEADING,
    AIM
  }
}