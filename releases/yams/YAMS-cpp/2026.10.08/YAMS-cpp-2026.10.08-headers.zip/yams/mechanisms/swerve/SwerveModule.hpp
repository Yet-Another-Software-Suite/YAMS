// Copyright (c) 2026 Yet Another Software Suite
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once

#include <functional>
#include <optional>
#include <string>
#include <wpi/math/kinematics/SwerveModulePosition.hpp>
#include <wpi/math/kinematics/SwerveModuleVelocity.hpp>
#include <wpi/units/angle.hpp>

#include "yams/mechanisms/config/SwerveModuleConfig.hpp"
#include "yams/motorcontrollers/SmartMotorController.hpp"
#include "yams/telemetry/MechanismTelemetry.hpp"
#include "yams/telemetry/SwerveModuleTelemetry.hpp"

namespace yams::mechanisms::swerve {

/**
 * A single swerve module comprising a drive motor and an azimuth (steering) motor.
 *
 * Each module holds references to two SmartMotorControllers (drive and azimuth) and
 * a SwerveModuleConfig that describes its physical properties and absolute encoder.
 * Modules are normally owned by the subsystem and handed to SwerveDrive by pointer.
 *
 * ### Example usage (inside a subsystem constructor)
 * @code{.cpp}
 * using namespace yams::motorcontrollers;
 * using namespace yams::motorcontrollers::remote;
 * using namespace yams::gearing;
 * using namespace yams::mechanisms::config;
 * using Cfg = SmartMotorControllerConfig;
 *
 * // Declare as subsystem members:
 * //   ctre::phoenix6::hardware::TalonFX     m_driveMotor{1};
 * //   ctre::phoenix6::hardware::TalonFX     m_azimuthMotor{2};
 * //   ctre::phoenix6::hardware::CANcoder    m_encoder{3};
 * //   std::optional<TalonFXWrapper>         m_driveSMC;
 * //   std::optional<TalonFXWrapper>         m_azimuthSMC;
 * //   std::optional<SwerveModule>           m_module;
 *
 * SmartMotorControllerConfig driveCfg;
 * driveCfg.WithSubsystem(this)
 *         .WithMechanismCircumference(wpi::units::meter_t{4.0_in * std::numbers::pi})
 *         .WithFeedback(0.1, 0.0, 0.0)
 *         .WithMotorGearing(MechanismGearing{GearBox::FromStages({"6.75:1"})})
 *         .WithStatorCurrentLimit(40.0_A)
 *         .WithZeroPower(Cfg::MotorMode::BRAKE)
 *         .WithTelemetry("FL_Drive", Cfg::TelemetryVerbosity::HIGH);
 *
 * SmartMotorControllerConfig azimuthCfg;
 * azimuthCfg.WithSubsystem(this)
 *           .WithFeedback(50.0, 0.0, 0.5)
 *           .WithMotorGearing(MechanismGearing{GearBox::FromStages({"21.43:1"})})
 *           .WithStatorCurrentLimit(20.0_A)
 *           .WithClosedLoopMode()
 *           .WithTelemetry("FL_Azimuth", Cfg::TelemetryVerbosity::HIGH);
 *
 * m_driveSMC.emplace(m_driveMotor, wpi::math::DCMotor::KrakenX60(1), driveCfg);
 * m_azimuthSMC.emplace(m_azimuthMotor, wpi::math::DCMotor::KrakenX60(1), azimuthCfg);
 *
 * auto* enc = &m_encoder;
 * SwerveModuleConfig moduleConfig{&m_driveSMC.value(), &m_azimuthSMC.value()};
 * moduleConfig
 *     .WithAbsoluteEncoder([enc]() -> wpi::units::degree_t {
 *       return wpi::units::degree_t{wpi::units::turn_t{enc->GetAbsolutePosition().GetValue()}};
 *     })
 *     .WithAbsoluteEncoderOffset(15.0_deg)
 *     .WithWheelDiameter(4.0_in)
 *     .WithLocation(wpi::units::inch_t{12}, wpi::units::inch_t{12})
 *     .WithOptimization(true)
 *     .WithCosineCompensation(true)
 *     .WithTelemetry("FrontLeft", Cfg::TelemetryVerbosity::HIGH);
 *
 * m_module.emplace(&m_moduleConfig);
 * @endcode
 */
class SwerveModule {
 public:
  /**
   * Construct a SwerveModule from a SwerveModuleConfig.
   *
   * @param config Module configuration.  Must contain a telemetry name and a location.
   * @throws std::invalid_argument if telemetry name or location is not set.
   */
  explicit SwerveModule(config::SwerveModuleConfig* config);

  /**
   * Setup telemetry for the module; the SwerveModuleTelemetry config used is either the one
   * supplied via SwerveModuleConfig::WithTelemetry(name, SwerveModuleTelemetryConfig) or a
   * default built from SwerveModuleConfig::GetTelemetryVerbosity() (defaulting to
   * TelemetryVerbosity::HIGH).
   *
   * @param mechName Telemetry name of the parent SwerveDrive.
   */
  void SetupTelemetry(const std::string& mechName);

  /**
   * Seed the azimuth encoder from the absolute encoder reading (real robot only).
   */
  void SeedAzimuthEncoder();

  /** Get the module name (from telemetry config). */
  std::string GetName() const;

  /** Get the absolute encoder angle without any offsets applied. */
  wpi::units::degree_t GetRawAbsoluteEncoderAngle() const;

  /** Get the module configuration. */
  const config::SwerveModuleConfig& GetConfig() const;

  /**
   * Command the module to a target state.
   *
   * Applies optimization (direction flip, min-velocity clamp, cosine compensation)
   * before setting drive velocity and azimuth position.
   *
   * @param state Target module state.
   */
  void SetSwerveModuleState(wpi::math::SwerveModuleVelocity state);

  /** Get the current measured module state (speed and heading). */
  wpi::math::SwerveModuleVelocity GetState() const;

  /** Get the current measured module position (distance and heading). */
  wpi::math::SwerveModulePosition GetPosition() const;

  /** Publish drive and azimuth motor telemetry to NetworkTables. */
  void UpdateTelemetry();

  /** Advance the simulation model for both drive and azimuth motors. */
  void SimIterate();

  /** Get the drive motor controller. */
  motorcontrollers::SmartMotorController* GetDriveMotorController() const;

  /** Get the azimuth motor controller. */
  motorcontrollers::SmartMotorController* GetAzimuthMotorController() const;

 private:
  config::SwerveModuleConfig* m_config{nullptr};
  /** Used for the loop time only; module state/encoder telemetry lives in m_swerveModuleTelemetry.
   */
  telemetry::MechanismTelemetry m_telemetry;
  std::optional<telemetry::SwerveModuleTelemetry> m_swerveModuleTelemetry;
  std::function<wpi::units::degree_t()> m_azimuthEncoderWithoutOffsets;

 public:
  // Public so SwerveDrive can access them directly (mirrors Java protected fields).
  motorcontrollers::SmartMotorController* m_driveMotorController;
  motorcontrollers::SmartMotorController* m_azimuthMotorController;
};

}  // namespace yams::mechanisms::swerve
